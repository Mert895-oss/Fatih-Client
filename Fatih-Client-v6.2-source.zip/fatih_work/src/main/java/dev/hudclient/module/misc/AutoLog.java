package dev.hudclient.module.misc;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.setting.NumberSetting;
import net.minecraft.network.chat.Component;

/** Disconnects locally when health reaches the configured threshold. */
public final class AutoLog extends Module {
    private final NumberSetting health = num("Health Threshold", 4.0, 1.0, 20.0, 0.5);
    private final NumberSetting delay = num("Cooldown Ticks", 40, 0, 200, 5);
    private int cooldown;

    public AutoLog() {
        super("Auto Log", Category.MISC);
        setDescription("Disconnects from the current world when health reaches the selected threshold.");
    }

    @Override public void onTick() {
        if (mc.player == null || mc.level == null || mc.screen != null) return;
        if (cooldown > 0) { cooldown--; return; }
        if (mc.player.getHealth() <= health.getD()) {
            cooldown = delay.getInt();
            mc.disconnect(Component.literal("Fatih Client Auto Log: health threshold reached"));
        }
    }
}
