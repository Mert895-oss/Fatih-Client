package dev.hudclient.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.phys.Vec3;

/**
 * Camera state for the client-only Freecam and Free Look modules.
 * Freecam uses an unattached marker as the camera target. Free Look keeps the
 * normal player camera target (so the first-person hand remains visible) and
 * overrides only the camera's rendered yaw/pitch.
 */
public final class CameraController {
    private static Entity freecamCamera;
    private static boolean freeLookActive;

    private static Vec3 playerAnchor;
    private static Vec3 playerVelocity;
    private static float playerAnchorYaw;
    private static float playerAnchorPitch;

    private static float freeLookYaw;
    private static float freeLookPitch;

    private CameraController() {}

    public static boolean startFreecam() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || freecamCamera != null) return false;

        Entity camera = EntityType.MARKER.create(mc.level, EntitySpawnReason.COMMAND);
        if (camera == null) return false;

        LocalPlayer player = mc.player;
        playerAnchor = player.position();
        playerVelocity = player.getDeltaMovement();
        playerAnchorYaw = player.getYRot();
        playerAnchorPitch = player.getXRot();

        camera.setNoGravity(true);
        camera.setPos(player.getX(), player.getY() + player.getEyeHeight(), player.getZ());
        camera.setYRot(player.getYRot());
        camera.setXRot(player.getXRot());
        freecamCamera = camera;
        freeLookActive = false;
        mc.setCameraEntity(camera);
        return true;
    }

    public static boolean startFreeLook() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || freecamCamera != null) return false;
        if (freeLookActive) return true;

        freeLookYaw = mc.player.getYRot();
        freeLookPitch = mc.player.getXRot();
        freeLookActive = true;
        // Keep the normal player as the camera entity: this preserves hand,
        // arm and first-person overlays while Camera.setup uses our angles.
        mc.setCameraEntity(mc.player);
        return true;
    }

    /** Called once per client tick by the enabled Freecam module. */
    public static void tickFreecam(double speed) {
        Minecraft mc = Minecraft.getInstance();
        if (freecamCamera == null || mc.player == null || mc.level == null) return;

        freezePlayer(mc.player);
        if (mc.screen != null) return;

        double multiplier = mc.options.keySprint.isDown() ? 2.0 : 1.0;
        double step = Math.max(0.025, Math.min(3.0, speed)) * multiplier;
        float yaw = freecamCamera.getYRot();
        Vec3 forward = Vec3.directionFromRotation(0.0F, yaw);
        Vec3 right = Vec3.directionFromRotation(0.0F, yaw + 90.0F);
        double dx = 0.0;
        double dy = 0.0;
        double dz = 0.0;

        if (mc.options.keyUp.isDown()) {
            dx += forward.x * step;
            dz += forward.z * step;
        }
        if (mc.options.keyDown.isDown()) {
            dx -= forward.x * step;
            dz -= forward.z * step;
        }
        if (mc.options.keyRight.isDown()) {
            dx += right.x * step;
            dz += right.z * step;
        }
        if (mc.options.keyLeft.isDown()) {
            dx -= right.x * step;
            dz -= right.z * step;
        }
        if (mc.options.keyJump.isDown()) dy += step;
        if (mc.options.keyShift.isDown()) dy -= step;

        // Keep diagonal movement at the same speed as straight movement.
        double length = Math.sqrt(dx * dx + dz * dz);
        if (length > step && length > 0.0) {
            dx = dx / length * step;
            dz = dz / length * step;
        }

        freecamCamera.setPos(freecamCamera.getX() + dx,
                freecamCamera.getY() + dy,
                freecamCamera.getZ() + dz);
    }

    /**
     * Intercepts the local player's mouse-look. Returns true when vanilla must
     * be cancelled. For Freecam the deltas are routed to the detached camera;
     * for Free Look they update a separate rendered view rotation.
     */
    public static boolean handlePlayerTurn(Entity turningEntity, double deltaYaw, double deltaPitch) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || turningEntity != mc.player) return false;

        if (freecamCamera != null) {
            freecamCamera.turn(deltaYaw, deltaPitch);
            return true;
        }
        if (freeLookActive) {
            // Entity.turn applies the standard Minecraft mouse sensitivity
            // multiplier (0.15) internally; mirror that for the camera angles.
            freeLookYaw += (float) (deltaYaw * 0.15);
            freeLookPitch = clamp(freeLookPitch + (float) (deltaPitch * 0.15), -90.0F, 90.0F);
            return true;
        }
        return false;
    }

    public static float getFreeLookYaw() {
        return freeLookYaw;
    }

    public static float getFreeLookPitch() {
        return freeLookPitch;
    }

    /** Holds the real local player at the recorded position during Freecam. */
    public static void freezePlayer(LocalPlayer player) {
        if (freecamCamera == null || playerAnchor == null || player == null) return;
        player.setPos(playerAnchor.x, playerAnchor.y, playerAnchor.z);
        player.setDeltaMovement(Vec3.ZERO);
        player.setYRot(playerAnchorYaw);
        player.setXRot(playerAnchorPitch);
    }

    public static void stopFreecam() {
        Minecraft mc = Minecraft.getInstance();
        Entity oldCamera = freecamCamera;
        freecamCamera = null;

        if (mc.player != null && oldCamera != null && mc.getCameraEntity() == oldCamera) {
            mc.setCameraEntity(mc.player);
        }
        if (mc.player != null && playerAnchor != null) {
            mc.player.setPos(playerAnchor.x, playerAnchor.y, playerAnchor.z);
            mc.player.setDeltaMovement(playerVelocity == null ? Vec3.ZERO : playerVelocity);
            mc.player.setYRot(playerAnchorYaw);
            mc.player.setXRot(playerAnchorPitch);
        }
        clearAnchor();
    }

    public static void stopFreeLook() {
        boolean wasFreeLooking = freeLookActive;
        freeLookActive = false;
        Minecraft mc = Minecraft.getInstance();
        if (wasFreeLooking && freecamCamera == null && mc.player != null
                && mc.getCameraEntity() != mc.player) {
            mc.setCameraEntity(mc.player);
        }
    }

    public static void stopAll() {
        stopFreecam();
        stopFreeLook();
    }

    private static void clearAnchor() {
        playerAnchor = null;
        playerVelocity = null;
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    public static boolean isActive() {
        return freecamCamera != null || freeLookActive;
    }

    public static boolean isFreecam() {
        return freecamCamera != null;
    }

    public static boolean isFreeLook() {
        return freeLookActive;
    }
}
