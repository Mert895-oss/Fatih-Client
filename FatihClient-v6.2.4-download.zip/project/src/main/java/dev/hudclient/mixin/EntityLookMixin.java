package dev.hudclient.mixin;

import dev.hudclient.util.CameraController;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Redirects mouse look away from the player body while a camera module is active. */
@Mixin(Entity.class)
public abstract class EntityLookMixin {
    @Inject(method = "turn(DD)V", at = @At("HEAD"), cancellable = true)
    private void fatih$separateCameraLook(double deltaYaw, double deltaPitch, CallbackInfo ci) {
        if (CameraController.handlePlayerTurn((Entity) (Object) this, deltaYaw, deltaPitch)) {
            ci.cancel();
        }
    }
}
