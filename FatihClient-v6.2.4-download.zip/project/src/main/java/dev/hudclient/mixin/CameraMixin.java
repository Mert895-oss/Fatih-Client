package dev.hudclient.mixin;

import dev.hudclient.util.CameraController;
import net.minecraft.client.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

/** Applies independent Free Look angles to Minecraft's actual render camera. */
@Mixin(Camera.class)
public abstract class CameraMixin {
    @ModifyArgs(
            method = "setup(Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/Entity;ZZF)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/Camera;setRotation(FF)V")
    )
    private void fatih$applyFreeLookRotation(Args args) {
        if (!CameraController.isFreeLook()) return;
        args.set(0, CameraController.getFreeLookYaw());
        args.set(1, CameraController.getFreeLookPitch());
    }
}
