package dev.hudclient.module;

/** Sections shown in Fatih Client's approved eight-tab sidebar. */
public enum Category {
    COMBAT("Combat", "⚔"),
    MOVEMENT("Movement", "➤"),
    RENDER("Render", "▣"),
    PLAYER("Player", "♟"),
    WORLD("World", "⬡"),
    MISC("Misc", "⚙"),
    HUD("Hud", "▥"),
    CLIENT("Client", "♛");

    public final String label;
    public final String icon;

    Category(String label, String icon) {
        this.label = label;
        this.icon = icon;
    }
}
