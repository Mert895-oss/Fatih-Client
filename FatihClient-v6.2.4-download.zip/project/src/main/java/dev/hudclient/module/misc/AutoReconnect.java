package dev.hudclient.module.misc;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.setting.NumberSetting;
import net.minecraft.client.gui.screens.ConnectScreen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.multiplayer.resolver.ServerAddress;
import net.minecraft.client.multiplayer.ServerData;

/** Reconnects to the last remote server after a disconnect, with a delay. */
public final class AutoReconnect extends Module {
    private final NumberSetting delay=num("Reconnect Delay (seconds)",10,3,60,1);
    private ServerData lastServer;
    private int cooldown;
    private boolean attempted;

    public AutoReconnect(){super("Auto Reconnect",Category.MISC);setDescription("Remembers the current remote server and retries the connection after disconnecting.");}

    @Override public void onEnable(){captureServer();cooldown=0;attempted=false;}
    @Override public void onTick(){captureServer();if(mc.player!=null){attempted=false;}}

    private void captureServer(){
        if(mc.getCurrentServer()!=null)lastServer=mc.getCurrentServer();
    }

    /** Called by ModuleManager even while the player is disconnected. */
    public void tickDisconnected(){
        if(!isEnabled()||lastServer==null)return;
        if(mc.player!=null){attempted=false;return;}
        if(mc.screen instanceof ConnectScreen)return;
        if(cooldown>0){cooldown--;return;}
        if(attempted){cooldown=delay.getInt()*20;attempted=false;return;}
        attempted=true;
        cooldown=delay.getInt()*20;
        try {
            ConnectScreen.startConnecting(new TitleScreen(),mc,ServerAddress.parseString(lastServer.ip),lastServer,false,null);
        } catch (RuntimeException ex) {
            attempted=false;
        }
    }

    @Override public void onDisable(){lastServer=null;cooldown=0;attempted=false;}
}
