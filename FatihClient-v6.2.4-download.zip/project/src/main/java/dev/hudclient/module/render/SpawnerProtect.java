package dev.hudclient.module.render;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.render.Render3D;
import dev.hudclient.setting.NumberSetting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.chunk.status.ChunkStatus;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/** Marks only air-exposed monster spawners in already-loaded chunks. */
public final class SpawnerProtect extends Module {
    private final NumberSetting radius=num("Radius",16,4,32,2);
    private final List<AABB> blocks=new ArrayList<>();
    private int timer;
    public SpawnerProtect(){super("Spawner Protect",Category.WORLD);setDescription("Highlights air-exposed spawners nearby so you can notice them; it does not change or protect server blocks.");}
    @Override public void onTick(){
        if(timer-->0)return;timer=12;blocks.clear();if(mc.level==null||mc.player==null)return;
        int r=radius.getInt(),px=mc.player.getBlockX(),py=mc.player.getBlockY(),pz=mc.player.getBlockZ();
        for(int x=px-r;x<=px+r;x++)for(int y=Math.max(mc.level.getMinY(),py-r);y<=Math.min(mc.level.getMaxY(),py+r);y++)for(int z=pz-r;z<=pz+r;z++){
            if(mc.level.getChunk(x>>4,z>>4,ChunkStatus.FULL,false)==null)continue;
            BlockPos pos=new BlockPos(x,y,z);if(!mc.level.getBlockState(pos).is(Blocks.SPAWNER))continue;
            for(Direction d:Direction.values())if(mc.level.getBlockState(pos.relative(d)).isAir()){if(hasLineOfSight(pos))blocks.add(new AABB(pos));break;}
        }
    }
    private boolean hasLineOfSight(BlockPos pos) {
        Vec3 eye = mc.player.getEyePosition();
        Vec3 target = Vec3.atCenterOf(pos);
        var hit = mc.level.clip(new ClipContext(eye, target, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, mc.player));
        return hit.getType() == HitResult.Type.BLOCK && pos.equals(hit.getBlockPos());
    }

    @Override public void onRender3D(){for(AABB b:blocks){Render3D.box(b,0x667D37FF);Render3D.outline(b,0.04,0xFFFF4D8D);}}
    @Override public void onDisable(){blocks.clear();}
}
