package dev.hudclient.module.misc;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.setting.BoolSetting;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.phys.BlockHitResult;

/** Selects the fastest tool in the hotbar for the block currently being mined. */
public final class AutoTool extends Module {
    private final BoolSetting restore = bool("Restore Previous Slot", false);
    private int previousSlot = -1;
    private int selectedByModule = -1;

    public AutoTool() {
        super("Auto Tool", Category.PLAYER);
        setDescription("Selects the best tool for the visible block target while the attack button is held.");
    }

    @Override
    public void onTick() {
        LocalPlayer player = mc.player;
        if (player == null || mc.level == null || mc.screen != null) return;
        if (!mc.options.keyAttack.isDown() || !(mc.hitResult instanceof BlockHitResult hit)) {
            restoreIfNeeded(player);
            return;
        }

        var state = mc.level.getBlockState(hit.getBlockPos());
        float bestSpeed = 1.0F;
        int bestSlot = player.getInventory().getSelectedSlot();
        for (int slot = 0; slot < 9; slot++) {
            float speed = player.getInventory().getItem(slot).getDestroySpeed(state);
            if (speed > bestSpeed) {
                bestSpeed = speed;
                bestSlot = slot;
            }
        }
        if (bestSlot != player.getInventory().getSelectedSlot()) {
            if (previousSlot < 0) previousSlot = player.getInventory().getSelectedSlot();
            player.getInventory().setSelectedSlot(bestSlot);
            selectedByModule = bestSlot;
        }
    }

    private void restoreIfNeeded(LocalPlayer player) {
        if (restore.get() && previousSlot >= 0 && selectedByModule >= 0
                && player.getInventory().getSelectedSlot() == selectedByModule) {
            player.getInventory().setSelectedSlot(previousSlot);
        }
        previousSlot = -1;
        selectedByModule = -1;
    }

    @Override
    public void onDisable() {
        if (mc.player != null) restoreIfNeeded(mc.player);
    }
}
