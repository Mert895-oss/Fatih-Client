package dev.hudclient.module.render;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.module.ModuleManager;
import dev.hudclient.util.CameraController;
import org.lwjgl.glfw.GLFW;

/** Independent look rotation. Left Alt is the default hold-to-look bind. */
public final class FreeLook extends Module {
    public FreeLook() {
        super("Free Look", Category.MOVEMENT);
        setDescription("Look around without rotating the player's body. Hold Left Alt by default.");
        setKey(GLFW.GLFW_KEY_LEFT_ALT);
    }

    @Override
    public boolean handlesHoldBind() {
        return true;
    }

    @Override
    public void onBoundKeyState(boolean down) {
        if (down) {
            Freecam freecam = ModuleManager.get(Freecam.class);
            if (freecam != null && freecam.isEnabled()) return;
            if (mc.player != null && mc.level != null) CameraController.startFreeLook();
        } else if (!isEnabled() && CameraController.isFreeLook()) {
            CameraController.stopFreeLook();
        }
    }

    @Override
    public void onEnable() {
        Freecam freecam = ModuleManager.get(Freecam.class);
        if (freecam != null && freecam.isEnabled()) freecam.setEnabled(false);
        if (!CameraController.startFreeLook()) setEnabled(false);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.level == null) setEnabled(false);
    }

    @Override
    public void onDisable() {
        CameraController.stopFreeLook();
    }
}
