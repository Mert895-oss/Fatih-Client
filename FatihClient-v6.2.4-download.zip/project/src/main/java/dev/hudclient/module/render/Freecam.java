package dev.hudclient.module.render;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.module.ModuleManager;
import dev.hudclient.setting.NumberSetting;
import dev.hudclient.util.CameraController;

/** Detached, client-side camera; the local player remains anchored in place. */
public final class Freecam extends Module {
    private final NumberSetting speed = num("Move Speed", 0.45, 0.05, 2.0, 0.05);

    public Freecam() {
        super("Freecam", Category.MOVEMENT);
        setDescription("WASD moves a detached camera; Space and Shift move vertically.");
    }

    @Override
    public void onEnable() {
        FreeLook look = ModuleManager.get(FreeLook.class);
        if (look != null && look.isEnabled()) look.setEnabled(false);
        if (!CameraController.startFreecam()) setEnabled(false);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.level == null) {
            setEnabled(false);
            return;
        }
        CameraController.tickFreecam(speed.getD());
    }

    @Override
    public void onDisable() {
        CameraController.stopFreecam();
    }
}
