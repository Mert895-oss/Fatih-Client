package dev.hudclient.module.misc;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.setting.NumberSetting;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemUseAnimation;
import net.minecraft.world.item.ItemStack;

/** Uses food already present in the hotbar when hunger reaches the selected threshold. */
public final class AutoEat extends Module {
    private final NumberSetting hunger = num("Hunger Threshold", 16, 1, 20, 1);
    private final NumberSetting delay = num("Retry Delay (ticks)", 10, 1, 40, 1);
    private int cooldown;

    public AutoEat() {
        super("Auto Eat", Category.PLAYER);
        setDescription("Uses edible items from the hotbar when hunger is low; does not move items from the inventory.");
    }

    @Override
    public void onTick() {
        LocalPlayer player = mc.player;
        if (player == null || mc.gameMode == null || mc.screen != null) return;
        if (cooldown > 0) { cooldown--; return; }
        if (player.getFoodData().getFoodLevel() > hunger.getInt() || player.isUsingItem()) return;

        for (int slot = 0; slot < 9; slot++) {
            ItemStack stack = player.getInventory().getItem(slot);
            if (stack.isEmpty() || stack.getUseAnimation() != ItemUseAnimation.EAT) continue;
            player.getInventory().setSelectedSlot(slot);
            mc.gameMode.useItem(player, InteractionHand.MAIN_HAND);
            cooldown = delay.getInt();
            return;
        }
    }
}
