FATIH CLIENT v6.2.4 — Minecraft 1.21.11 (Fabric)

Project type: Fabric client mod source (Java 21).
Brand: FATIH CLIENT
Mod id: fatihclient
Target: Minecraft Java 1.21.11 / Fabric Loader 0.18.1+ / Fabric API 0.141.1+1.21.11

DESIGN
- The ClickGUI is a dark, translucent purple interface with a left category rail, module descriptions, search, switches, settings and drag support.
- Categories: Combat, Movement, Render, Player, World, Misc, Hud and Client.
- Right Shift opens the ClickGUI.
- Left click toggles a module; right click or the settings gear opens its settings.
- The window can be dragged by its header/footer. Module entries can be reordered within their category by dragging the leading star.
- The search field filters modules by name, description and category.
- Settings include a Bind row. Select it and press a keyboard key or mouse button; Escape clears the bind.
- Number settings can be adjusted by dragging their value bar; boolean and mode settings are clickable.

HUD
- Upper-left Fatih Client watermark with FPS and ping.
- Circular heading-up radar with N/E/S/W compass labels. Dots are limited to entities already loaded and rendered by the client.
- Potion effects, coordinates and movement speed on the left.
- Original pixel-drawn Fatih Sultan Mehmet-inspired emblem and local time/date at the top centre.
- Active module list at the top-right, plus the server scoreboard when present.
- WASD / Space and LMB / RMB CPS indicators near the bottom-right.
- Crosshair, HUD scale, accent colour and component visibility are configurable from the HUD settings.

CAMERA MODULES
- Freecam is implemented as a client-side detached camera. WASD moves it; Space and Shift move vertically; Sprint increases movement speed.
- The local player is held at the position recorded when Freecam starts. Disabling Freecam restores the player's camera and saved position/rotation/velocity.
- Free Look redirects mouse-look input to a separate camera yaw/pitch while keeping the local player's body rotation unchanged. Its default hold bind is Left Alt; it can also be toggled from the GUI.
- Freecam and Free Look are mutually exclusive.
- The camera mixins use the official Mojang-mapped 1.21.11 method names and descriptors. Both camera modes still require a successful build and in-game testing on desktop and FCL before they can be called verified.

IMPLEMENTED MODULES IN THIS SOURCE
Combat: Auto Totem.
Movement: Sprint, Freecam, Free Look.
Player: Auto Eat, Auto Tool, Key Pearl, Skin Protect.
World: Spawner Chunk Finder, Player Chunk, Amethyst Activity Finder, Anti Trap, Item Snapper, Netherite Finder, Spawner Protect, Hole ESP, Light Finder, Jungle Finder.
Misc: Auto Log, Auto Reconnect, Auto Mine, Auto Clicker, Fast Place, Cord Snapper, Auto Loot.
Render: Player ESP, Storage ESP, Suspicious ESP, Pearl Predict, Target HUD, Jump Circles, Fullbright, Block ESP, Ore Sim, SwingSpeed.
Hud: HUD.

SOON / NOT IMPLEMENTED
- Auto TPA, Elytra Glide, Name Protect.
- Auction Sniper, Auto Sell, Auto Spawner Sell, RTP Base Finder, Auto Shulker Buy, Tunnel Base Finder, Fake Stats, Chunk Finder.
- Seed Chunk Finder and RemLightbox (the original label is ambiguous).
- Proxy Profiles and Config Profiles are catalogue placeholders; the main-menu proxy screen is not implemented.
- These entries are intentionally disabled and are not represented as working modules.

VISIBILITY AND FAIR-PLAY LIMITS
- Player ESP draws only entities already present in the client world; it does not reveal unloaded entities or obtain hidden server data.
- Ore, ancient-debris and spawner marking is limited to directly visible blocks in already-loaded chunks. There is no anti-Xray bypass or hidden-block inference.
- Amethyst activity is only a heuristic; it cannot prove that a player or base is present.

REFERENCE MATERIAL
- The supplied Free Look sample was used to compare the camera-input and render-rotation approach, then adapted to this project's official Mojang mappings.
- Meteor and Anubis were reviewed as feature/behavior references. No Meteor or Anubis Java source, binaries, fonts, textures or other resources are copied into this project.
- Their feature lists are not proof that a similarly named Fatih Client feature has been implemented.

MOBILE / PC
- This is a Java Fabric mod, not a Bedrock add-on.
- It targets Java 21 and Minecraft 1.21.11. Android launchers must provide a compatible Java runtime, Fabric Loader and rendering/input support.
- The GUI uses Minecraft screen mouse events; touch support depends on the launcher translating touch into those events. FCL device testing is still outstanding.

BUILD
- JDK 21, Gradle 9.2.0, Fabric Loom 1.14-SNAPSHOT.
- Run `gradle build` from the folder containing build.gradle.
- The GitHub Actions workflow can build this source ZIP after it is committed to the repository root.
- Expected main output: build/libs/Fatih-Client-6.2.4.jar.

VALIDATION STATUS
- The project source has been statically reviewed in this workspace.
- Gradle and the Minecraft/Fabric dependency cache are not installed in this workspace, and a live game client is not available here.
- This ZIP is source code, not a verified JAR. A successful GitHub Actions build and in-game testing are still required before calling the build verified.
