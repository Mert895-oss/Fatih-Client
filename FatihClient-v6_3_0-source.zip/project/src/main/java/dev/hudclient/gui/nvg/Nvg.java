package dev.hudclient.gui.nvg;

import dev.hudclient.HudClient;
import org.lwjgl.nanovg.NVGColor;
import org.lwjgl.nanovg.NVGPaint;
import org.lwjgl.nanovg.NanoVG;
import org.lwjgl.nanovg.NanoVGGL3;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL14;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;

import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;

/**
 * Thin NanoVG wrapper. Everything is wrapped so that if NanoVG cannot start on this device
 * (for example on a launcher whose GL layer lacks GL3 features) the client falls back to the
 * vanilla-drawn ClickGUI instead of crashing.
 */
public final class Nvg {
    public static final int ALIGN_LEFT = NanoVG.NVG_ALIGN_LEFT | NanoVG.NVG_ALIGN_MIDDLE;
    public static final int ALIGN_CENTER = NanoVG.NVG_ALIGN_CENTER | NanoVG.NVG_ALIGN_MIDDLE;
    public static final int ALIGN_RIGHT = NanoVG.NVG_ALIGN_RIGHT | NanoVG.NVG_ALIGN_MIDDLE;

    private static long ctx;
    private static boolean failed;
    private static int fontRegular = -1;
    private static int fontBold = -1;
    private static ByteBuffer regularData;
    private static ByteBuffer boldData;
    private static NVGColor colorA;
    private static NVGColor colorB;
    private static NVGPaint paint;
    private static final float[] BOUNDS = new float[4];

    private Nvg() {}

    public static boolean isFailed() {
        return failed;
    }

    public static void fail(String why, Throwable t) {
        failed = true;
        HudClient.LOGGER.error("NanoVG disabled: {}", why, t);
    }

    /** Creates the NanoVG context on first use. Returns false if NanoVG is unavailable. */
    public static boolean init() {
        if (failed) return false;
        if (ctx != 0L) return true;
        try {
            ctx = NanoVGGL3.nvgCreate(NanoVGGL3.NVG_ANTIALIAS);
            if (ctx == 0L) {
                fail("nvgCreate returned 0", null);
                return false;
            }
            regularData = loadFont("/assets/fatihclient/font/ui.ttf");
            boldData = loadFont("/assets/fatihclient/font/ui-bold.ttf");
            fontRegular = NanoVG.nvgCreateFontMem(ctx, "ui", regularData, false);
            fontBold = NanoVG.nvgCreateFontMem(ctx, "ui-bold", boldData, false);
            if (fontRegular < 0 || fontBold < 0) {
                fail("font load failed", null);
                return false;
            }
            colorA = NVGColor.malloc();
            colorB = NVGColor.malloc();
            paint = NVGPaint.malloc();
            return true;
        } catch (Throwable t) {
            fail("init exception", t);
            return false;
        }
    }

    private static ByteBuffer loadFont(String path) throws Exception {
        try (InputStream in = Nvg.class.getResourceAsStream(path)) {
            if (in == null) throw new IllegalStateException("Missing font " + path);
            byte[] bytes = in.readAllBytes();
            ByteBuffer buf = MemoryUtil.memAlloc(bytes.length);
            buf.put(bytes).flip();
            return buf;
        }
    }

    // ---------------------------------------------------------------- frame

    /**
     * Runs {@code draw} inside a NanoVG frame. The OpenGL state that Minecraft relies on is
     * captured first and restored afterwards, because NanoVG changes blend, cull, depth,
     * stencil, program, VAO and texture bindings.
     */
    public static void frame(int framebufferW, int framebufferH, float guiScale, Runnable draw) {
        if (!init()) return;
        try (MemoryStack stack = MemoryStack.stackPush()) {
            IntBuffer viewport = stack.mallocInt(4);
            GL11.glGetIntegerv(GL11.GL_VIEWPORT, viewport);
            int program = GL11.glGetInteger(GL20.GL_CURRENT_PROGRAM);
            int vao = GL11.glGetInteger(GL30.GL_VERTEX_ARRAY_BINDING);
            int arrayBuffer = GL11.glGetInteger(GL15.GL_ARRAY_BUFFER_BINDING);
            int activeTexture = GL11.glGetInteger(GL13.GL_ACTIVE_TEXTURE);
            GL13.glActiveTexture(GL13.GL_TEXTURE0);
            int texture0 = GL11.glGetInteger(GL11.GL_TEXTURE_BINDING_2D);
            boolean blend = GL11.glIsEnabled(GL11.GL_BLEND);
            boolean depth = GL11.glIsEnabled(GL11.GL_DEPTH_TEST);
            boolean cull = GL11.glIsEnabled(GL11.GL_CULL_FACE);
            boolean scissor = GL11.glIsEnabled(GL11.GL_SCISSOR_TEST);
            boolean stencil = GL11.glIsEnabled(GL11.GL_STENCIL_TEST);
            int srcRgb = GL11.glGetInteger(GL14.GL_BLEND_SRC_RGB);
            int dstRgb = GL11.glGetInteger(GL14.GL_BLEND_DST_RGB);
            int srcA = GL11.glGetInteger(GL14.GL_BLEND_SRC_ALPHA);
            int dstA = GL11.glGetInteger(GL14.GL_BLEND_DST_ALPHA);
            boolean depthMask = GL11.glGetBoolean(GL11.GL_DEPTH_WRITEMASK);
            int unpackAlign = GL11.glGetInteger(GL11.GL_UNPACK_ALIGNMENT);
            int unpackRow = GL11.glGetInteger(GL11.GL_UNPACK_ROW_LENGTH);

            try {
                GL11.glViewport(0, 0, framebufferW, framebufferH);
                NanoVG.nvgBeginFrame(ctx, framebufferW / guiScale, framebufferH / guiScale, guiScale);
                draw.run();
                NanoVG.nvgEndFrame(ctx);
            } catch (Throwable t) {
                fail("draw exception", t);
            } finally {
                GL20.glUseProgram(program);
                GL30.glBindVertexArray(vao);
                GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, arrayBuffer);
                GL13.glActiveTexture(GL13.GL_TEXTURE0);
                GL11.glBindTexture(GL11.GL_TEXTURE_2D, texture0);
                GL13.glActiveTexture(activeTexture);
                set(GL11.GL_BLEND, blend);
                set(GL11.GL_DEPTH_TEST, depth);
                set(GL11.GL_CULL_FACE, cull);
                set(GL11.GL_SCISSOR_TEST, scissor);
                set(GL11.GL_STENCIL_TEST, stencil);
                GL14.glBlendFuncSeparate(srcRgb, dstRgb, srcA, dstA);
                GL11.glDepthMask(depthMask);
                GL11.glColorMask(true, true, true, true);
                GL11.glPixelStorei(GL11.GL_UNPACK_ALIGNMENT, unpackAlign);
                GL11.glPixelStorei(GL11.GL_UNPACK_ROW_LENGTH, unpackRow);
                GL11.glViewport(viewport.get(0), viewport.get(1), viewport.get(2), viewport.get(3));
            }
        }
    }

    private static void set(int cap, boolean on) {
        if (on) GL11.glEnable(cap);
        else GL11.glDisable(cap);
    }

    // ---------------------------------------------------------------- drawing

    private static void rgba(NVGColor out, int argb) {
        NanoVG.nvgRGBA((byte) (argb >> 16), (byte) (argb >> 8), (byte) argb, (byte) (argb >>> 24), out);
    }

    public static int alpha(int argb, float a) {
        int na = Math.max(0, Math.min(255, Math.round((argb >>> 24) * a)));
        return (na << 24) | (argb & 0xFFFFFF);
    }

    public static int mix(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255, aa = a >>> 24;
        int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255, ba = b >>> 24;
        return (Math.round(aa + (ba - aa) * t) << 24) | (Math.round(ar + (br - ar) * t) << 16)
                | (Math.round(ag + (bg - ag) * t) << 8) | Math.round(ab + (bb - ab) * t);
    }

    public static void rect(float x, float y, float w, float h, float r, int argb) {
        NanoVG.nvgBeginPath(ctx);
        NanoVG.nvgRoundedRect(ctx, x, y, w, h, r);
        rgba(colorA, argb);
        NanoVG.nvgFillColor(ctx, colorA);
        NanoVG.nvgFill(ctx);
    }

    public static void rectGradient(float x, float y, float w, float h, float r, int top, int bottom) {
        NanoVG.nvgBeginPath(ctx);
        NanoVG.nvgRoundedRect(ctx, x, y, w, h, r);
        rgba(colorA, top);
        rgba(colorB, bottom);
        NanoVG.nvgLinearGradient(ctx, x, y, x, y + h, colorA, colorB, paint);
        NanoVG.nvgFillPaint(ctx, paint);
        NanoVG.nvgFill(ctx);
    }

    public static void rectGradientH(float x, float y, float w, float h, float r, int left, int right) {
        NanoVG.nvgBeginPath(ctx);
        NanoVG.nvgRoundedRect(ctx, x, y, w, h, r);
        rgba(colorA, left);
        rgba(colorB, right);
        NanoVG.nvgLinearGradient(ctx, x, y, x + w, y, colorA, colorB, paint);
        NanoVG.nvgFillPaint(ctx, paint);
        NanoVG.nvgFill(ctx);
    }

    public static void outline(float x, float y, float w, float h, float r, float stroke, int argb) {
        NanoVG.nvgBeginPath(ctx);
        NanoVG.nvgRoundedRect(ctx, x, y, w, h, r);
        rgba(colorA, argb);
        NanoVG.nvgStrokeColor(ctx, colorA);
        NanoVG.nvgStrokeWidth(ctx, stroke);
        NanoVG.nvgStroke(ctx);
    }

    /** Soft glow / shadow around a box. */
    public static void glow(float x, float y, float w, float h, float r, float spread, int argb) {
        NanoVG.nvgBeginPath(ctx);
        NanoVG.nvgRect(ctx, x - spread, y - spread, w + spread * 2, h + spread * 2);
        rgba(colorA, argb);
        rgba(colorB, argb & 0x00FFFFFF);
        NanoVG.nvgBoxGradient(ctx, x, y, w, h, r, spread, colorA, colorB, paint);
        NanoVG.nvgFillPaint(ctx, paint);
        NanoVG.nvgFill(ctx);
    }

    public static void circle(float cx, float cy, float r, int argb) {
        NanoVG.nvgBeginPath(ctx);
        NanoVG.nvgCircle(ctx, cx, cy, r);
        rgba(colorA, argb);
        NanoVG.nvgFillColor(ctx, colorA);
        NanoVG.nvgFill(ctx);
    }

    public static void line(float x1, float y1, float x2, float y2, float stroke, int argb) {
        NanoVG.nvgBeginPath(ctx);
        NanoVG.nvgMoveTo(ctx, x1, y1);
        NanoVG.nvgLineTo(ctx, x2, y2);
        rgba(colorA, argb);
        NanoVG.nvgStrokeColor(ctx, colorA);
        NanoVG.nvgStrokeWidth(ctx, stroke);
        NanoVG.nvgStroke(ctx);
    }

    public static void text(String s, float x, float y, float size, int argb, boolean bold, int align) {
        if (s == null || s.isEmpty()) return;
        NanoVG.nvgFontFaceId(ctx, bold ? fontBold : fontRegular);
        NanoVG.nvgFontSize(ctx, size);
        NanoVG.nvgTextAlign(ctx, align);
        rgba(colorA, argb);
        NanoVG.nvgFillColor(ctx, colorA);
        NanoVG.nvgText(ctx, x, y, s);
    }

    public static float textWidth(String s, float size, boolean bold) {
        if (s == null || s.isEmpty() || ctx == 0L) return 0f;
        NanoVG.nvgFontFaceId(ctx, bold ? fontBold : fontRegular);
        NanoVG.nvgFontSize(ctx, size);
        return NanoVG.nvgTextBounds(ctx, 0, 0, s, BOUNDS);
    }

    public static void clip(float x, float y, float w, float h) {
        NanoVG.nvgScissor(ctx, x, y, w, h);
    }

    public static void unclip() {
        NanoVG.nvgResetScissor(ctx);
    }
}
