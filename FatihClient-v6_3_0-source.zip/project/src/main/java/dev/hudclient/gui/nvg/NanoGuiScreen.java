package dev.hudclient.gui.nvg;

import dev.hudclient.HudClient;
import dev.hudclient.config.Config;
import dev.hudclient.gui.ClickGuiScreen;
import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.module.ModuleManager;
import dev.hudclient.setting.BoolSetting;
import dev.hudclient.setting.ModeSetting;
import dev.hudclient.setting.NumberSetting;
import dev.hudclient.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Meteor-style ClickGUI rendered with NanoVG: one draggable window per category, module rows that
 * toggle on left click and expand their settings on right click, in the Fatih Client purple theme.
 * Layout is rebuilt every frame in {@link #render}; the NanoVG drawing itself runs later from
 * GuiRendererMixin (after Minecraft's own GUI pass) so it lands on top of everything.
 */
public final class NanoGuiScreen extends Screen {
    // ---- metrics (GUI-scaled pixels)
    private static final float W = 134f, HEAD = 24f, ROW = 20f, SROW = 17f, GAP = 8f, MARGIN = 10f;

    // ---- theme
    private static final int BG = 0xF00A0912;
    private static final int BG_HEAD_TOP = 0xFF241238;
    private static final int BG_HEAD_BOTTOM = 0xFF140D22;
    private static final int BORDER = 0xFF4E286F;
    private static final int TEXT = 0xFFF2F0F8;
    private static final int MUTED = 0xFF9B96A9;
    private static final int ROW_HOVER = 0x22B45CFF;
    private static final int TRACK = 0xFF1B1428;

    private static final Map<Category, Win> WINDOWS = new HashMap<>();
    private static final List<Win> ORDER = new ArrayList<>();

    private static NanoGuiScreen active;
    private static boolean needsDraw;
    private static int drawnFrames;

    private final List<Item> items = new ArrayList<>();
    private final Map<Module, Float> anim = new HashMap<>();
    private int waitingFrames;
    private long lastNanos = System.nanoTime();
    private int mouseXi, mouseYi;

    private Win draggingWin;
    private float dragOffX, dragOffY;
    private NumberSetting draggingNumber;
    private float numX, numW;
    private Module binding;

    private enum Kind { MODULE, BOOL, NUM, MODE, BIND }

    private static final class Win {
        final Category cat;
        float x = Float.NaN, y;
        float scroll;
        boolean collapsed;
        float contentH, viewH;
        final List<Module> expanded = new ArrayList<>();
        Win(Category cat) { this.cat = cat; }
    }

    private static final class Item {
        Kind kind;
        Win win;
        Module module;
        Setting<?> setting;
        float x, y, w, h;
    }

    public NanoGuiScreen() {
        super(Component.literal("Fatih Client"));
        for (Category c : Category.values()) {
            if (!WINDOWS.containsKey(c)) {
                Win w = new Win(c);
                WINDOWS.put(c, w);
                ORDER.add(w);
            }
        }
    }

    /** Picks the NanoVG GUI, or the vanilla-drawn one when NanoVG is unavailable on this device. */
    public static Screen create() {
        return Nvg.isFailed() ? new ClickGuiScreen() : new NanoGuiScreen();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    protected void init() {
        active = this;
        waitingFrames = 0;
    }

    @Override
    public void removed() {
        if (active == this) active = null;
        needsDraw = false;
        super.removed();
    }

    @Override
    public void onClose() {
        Config.save();
        super.onClose();
    }

    // ------------------------------------------------------------------ frame hook

    /** Called by GuiRendererMixin after the vanilla GUI pass of the same frame. */
    public static void drawIfActive() {
        NanoGuiScreen s = active;
        if (s == null || !needsDraw) return;
        needsDraw = false;
        Minecraft mc = Minecraft.getInstance();
        var window = mc.getWindow();
        Nvg.frame(window.getWidth(), window.getHeight(), (float) window.getGuiScale(), s::drawAll);
        drawnFrames++;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        mouseXi = mouseX;
        mouseYi = mouseY;

        // Fallbacks: NanoVG failed, or the render hook never ran on this version/device.
        if (Nvg.isFailed()) {
            Minecraft.getInstance().setScreen(new ClickGuiScreen());
            return;
        }
        if (drawnFrames == 0 && ++waitingFrames > 30) {
            Nvg.fail("GuiRenderer hook did not run; using the vanilla ClickGUI", null);
            Minecraft.getInstance().setScreen(new ClickGuiScreen());
            return;
        }
        layout();
        needsDraw = true;
    }

    // ------------------------------------------------------------------ layout

    private static List<Module> modulesOf(Category c) {
        List<Module> r = new ArrayList<>();
        for (Module m : ModuleManager.all()) if (m.category == c) r.add(m);
        return r;
    }

    private void layout() {
        items.clear();
        Category[] cats = Category.values();
        int cols = Math.max(1, (int) ((width - MARGIN) / (W + GAP)));
        int rows = (cats.length + cols - 1) / cols;
        float maxH = Math.max(80f, (height - MARGIN * 2 - GAP * (rows - 1)) / rows);

        for (int i = 0; i < cats.length; i++) {
            Win win = WINDOWS.get(cats[i]);
            if (Float.isNaN(win.x)) {
                int col = i % cols, row = i / cols;
                float totalW = Math.min(cols, cats.length) * (W + GAP) - GAP;
                win.x = Math.max(MARGIN, (width - totalW) / 2f) + col * (W + GAP);
                win.y = MARGIN + 14f + row * (maxH + GAP);
            }
        }

        for (Win win : ORDER) {
            win.x = Math.max(2, Math.min(win.x, width - W - 2));
            win.y = Math.max(2, Math.min(win.y, height - HEAD - 2));

            List<Module> mods = modulesOf(win.cat);
            float cy = 0;
            List<Item> local = new ArrayList<>();
            for (Module m : mods) {
                local.add(item(Kind.MODULE, win, m, null, cy, ROW));
                cy += ROW;
                if (win.expanded.contains(m)) {
                    for (Setting<?> s : m.getSettings()) {
                        Kind k = s instanceof BoolSetting ? Kind.BOOL
                                : s instanceof NumberSetting ? Kind.NUM
                                : s instanceof ModeSetting ? Kind.MODE : null;
                        if (k == null) continue;
                        local.add(item(k, win, m, s, cy, SROW));
                        cy += SROW;
                    }
                    local.add(item(Kind.BIND, win, m, null, cy, SROW));
                    cy += SROW + 2;
                }
            }
            win.contentH = cy + 3;
            float availH = Math.max(40f, Math.min(maxH, height - win.y - 4) - HEAD);
            win.viewH = win.collapsed ? 0 : Math.min(win.contentH, availH);
            win.scroll = Math.max(0, Math.min(win.scroll, Math.max(0, win.contentH - win.viewH)));
            for (Item it : local) it.y = win.y + HEAD + it.y - win.scroll + 1;
            if (!win.collapsed) items.addAll(local);
        }
    }

    private Item item(Kind k, Win w, Module m, Setting<?> s, float relY, float h) {
        Item it = new Item();
        it.kind = k;
        it.win = w;
        it.module = m;
        it.setting = s;
        it.x = w.x + 1;
        it.y = relY;
        it.w = W - 2;
        it.h = h;
        return it;
    }

    private static boolean inside(double mx, double my, float x, float y, float w, float h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private boolean itemVisibleAt(Item it, double mx, double my) {
        Win w = it.win;
        float top = w.y + HEAD, bottom = top + w.viewH;
        return inside(mx, my, it.x, it.y, it.w, it.h) && my >= top && my < bottom;
    }

    // ------------------------------------------------------------------ drawing (NanoVG thread)

    private void drawAll() {
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - lastNanos) / 1_000_000_000f);
        lastNanos = now;
        int accent = 0xFF000000 | ModuleManager.accent();

        Nvg.rect(0, 0, width, height, 0, 0x66050309);

        // Title badge
        String title = "FATIH CLIENT";
        float tw = Nvg.textWidth(title, 12f, true) + 56f;
        float tx = (width - tw) / 2f;
        Nvg.glow(tx, 3, tw, 17, 8, 8, Nvg.alpha(accent, 0.25f));
        Nvg.rect(tx, 3, tw, 17, 8, 0xF0120D1D);
        Nvg.outline(tx, 3, tw, 17, 8, 1f, BORDER);
        Nvg.text(title, tx + 10, 11.5f, 11f, accent, true, Nvg.ALIGN_LEFT);
        Nvg.text(HudClient.VERSION, tx + tw - 10, 11.5f, 9f, MUTED, false, Nvg.ALIGN_RIGHT);

        for (Win win : ORDER) drawWindow(win, accent, dt);

        if (binding != null) {
            Nvg.rect(0, 0, width, height, 0, 0x99000000);
            String msg = binding.getName() + " için bir tuş / fare tuşu seç  (ESC: temizle)";
            float w = Nvg.textWidth(msg, 11f, false) + 28f;
            float x = (width - w) / 2f, y = height / 2f - 14f;
            Nvg.rect(x, y, w, 28, 8, 0xFF120D1D);
            Nvg.outline(x, y, w, 28, 8, 1.2f, accent);
            Nvg.text(msg, width / 2f, y + 14.5f, 11f, TEXT, false, Nvg.ALIGN_CENTER);
        }
    }

    private void drawWindow(Win win, int accent, float dt) {
        float h = HEAD + (win.collapsed ? 0 : win.viewH + 3);
        Nvg.glow(win.x, win.y, W, h, 8, 10, Nvg.alpha(accent, 0.20f));
        Nvg.rect(win.x, win.y, W, h, 8, BG);
        Nvg.rectGradient(win.x, win.y, W, HEAD, 8, BG_HEAD_TOP, BG_HEAD_BOTTOM);
        if (!win.collapsed) Nvg.rect(win.x, win.y + HEAD - 8, W, 8, 0, BG_HEAD_BOTTOM);
        Nvg.rectGradientH(win.x + 8, win.y + HEAD - 1.5f, W - 16, 1.5f, 0.7f,
                Nvg.alpha(accent, 0f), accent);
        Nvg.outline(win.x, win.y, W, h, 8, 1f, BORDER);

        Nvg.circle(win.x + 11, win.y + HEAD / 2f, 3f, accent);
        Nvg.text(win.cat.label, win.x + 20, win.y + HEAD / 2f + 0.5f, 12f, TEXT, true, Nvg.ALIGN_LEFT);
        Nvg.text(win.collapsed ? "+" : "–", win.x + W - 10, win.y + HEAD / 2f, 12f, MUTED, true, Nvg.ALIGN_CENTER);

        if (win.collapsed) return;

        float top = win.y + HEAD + 1, vh = win.viewH;
        Nvg.clip(win.x, top, W, vh);
        for (Item it : items) {
            if (it.win != win) continue;
            if (it.y + it.h < top || it.y > top + vh) continue;
            boolean hover = itemVisibleAt(it, mouseXi, mouseYi) && topWindowAt(mouseXi, mouseYi) == win;
            switch (it.kind) {
                case MODULE -> drawModule(it, accent, hover, dt);
                case BOOL -> drawBool(it, accent, hover);
                case NUM -> drawNumber(it, accent, hover);
                case MODE -> drawMode(it, accent, hover);
                case BIND -> drawBind(it, accent, hover);
            }
        }
        Nvg.unclip();

        // scrollbar
        if (win.contentH > win.viewH + 0.5f) {
            float barH = Math.max(14f, vh * (win.viewH / win.contentH));
            float range = win.contentH - win.viewH;
            float barY = top + (vh - barH) * (range <= 0 ? 0 : win.scroll / range);
            Nvg.rect(win.x + W - 4, barY, 2, barH, 1, Nvg.alpha(accent, 0.55f));
        }
    }

    private void drawModule(Item it, int accent, boolean hover, float dt) {
        Module m = it.module;
        float target = m.isEnabled() ? 1f : 0f;
        float a = anim.getOrDefault(m, target);
        a += (target - a) * Math.min(1f, dt * 14f);
        anim.put(m, a);

        if (a > 0.01f) {
            Nvg.rectGradientH(it.x + 2, it.y + 1, it.w - 4, it.h - 2, 4,
                    Nvg.alpha(accent, 0.30f * a), Nvg.alpha(accent, 0.07f * a));
            Nvg.rect(it.x + 2, it.y + 4, 2, it.h - 8, 1, Nvg.alpha(accent, a));
        } else if (hover) {
            Nvg.rect(it.x + 2, it.y + 1, it.w - 4, it.h - 2, 4, ROW_HOVER);
        }

        boolean implemented = m.isImplemented();
        int color = !implemented ? 0xFF6A6478 : Nvg.mix(hover ? TEXT : 0xFFC9C4D6, accent, a);
        Nvg.text(m.getName(), it.x + 9, it.y + it.h / 2f + 0.5f, 11f, color, a > 0.5f, Nvg.ALIGN_LEFT);

        if (!implemented) {
            Nvg.text("yakında", it.x + it.w - 8, it.y + it.h / 2f, 8.5f, 0xFF6A6478, false, Nvg.ALIGN_RIGHT);
        } else if (!m.getSettings().isEmpty() || true) {
            boolean open = it.win.expanded.contains(m);
            Nvg.text(open ? "⌄" : "›", it.x + it.w - 8, it.y + it.h / 2f, 11f,
                    open ? accent : MUTED, false, Nvg.ALIGN_CENTER);
        }
    }

    private void drawBool(Item it, int accent, boolean hover) {
        BoolSetting s = (BoolSetting) it.setting;
        if (hover) Nvg.rect(it.x + 6, it.y, it.w - 8, it.h, 3, ROW_HOVER);
        Nvg.text(s.name, it.x + 13, it.y + it.h / 2f + 0.5f, 10f, s.get() ? TEXT : MUTED, false, Nvg.ALIGN_LEFT);
        float px = it.x + it.w - 26, py = it.y + it.h / 2f - 5f;
        Nvg.rect(px, py, 20, 10, 5, s.get() ? Nvg.alpha(accent, 0.9f) : TRACK);
        Nvg.circle(s.get() ? px + 15 : px + 5, py + 5, 3.6f, s.get() ? 0xFFFFFFFF : 0xFF7A7389);
    }

    private void drawNumber(Item it, int accent, boolean hover) {
        NumberSetting s = (NumberSetting) it.setting;
        float x = it.x + 6, w = it.w - 8;
        Nvg.rect(x, it.y + 1, w, it.h - 2, 3, hover || draggingNumber == s ? 0xFF211833 : TRACK);
        float fw = Math.max(2f, (float) (w * s.fraction()));
        Nvg.rectGradientH(x, it.y + 1, fw, it.h - 2, 3, Nvg.alpha(accent, 0.75f), Nvg.alpha(accent, 0.40f));
        Nvg.text(s.name, x + 6, it.y + it.h / 2f + 0.5f, 9.5f, TEXT, false, Nvg.ALIGN_LEFT);
        Nvg.text(s.display(), x + w - 6, it.y + it.h / 2f + 0.5f, 9.5f, TEXT, false, Nvg.ALIGN_RIGHT);
    }

    private void drawMode(Item it, int accent, boolean hover) {
        ModeSetting s = (ModeSetting) it.setting;
        if (hover) Nvg.rect(it.x + 6, it.y, it.w - 8, it.h, 3, ROW_HOVER);
        Nvg.text(s.name, it.x + 13, it.y + it.h / 2f + 0.5f, 10f, MUTED, false, Nvg.ALIGN_LEFT);
        Nvg.text(s.get(), it.x + it.w - 8, it.y + it.h / 2f + 0.5f, 10f, accent, true, Nvg.ALIGN_RIGHT);
    }

    private void drawBind(Item it, int accent, boolean hover) {
        if (hover) Nvg.rect(it.x + 6, it.y, it.w - 8, it.h, 3, ROW_HOVER);
        Nvg.text("Bind", it.x + 13, it.y + it.h / 2f + 0.5f, 10f, MUTED, false, Nvg.ALIGN_LEFT);
        String label = binding == it.module ? "..." : keyName(it.module.getKey());
        Nvg.text(label, it.x + it.w - 8, it.y + it.h / 2f + 0.5f, 10f, accent, true, Nvg.ALIGN_RIGHT);
    }

    private static String keyName(int key) {
        if (key <= -100) return "MOUSE " + (-key - 99);
        if (key < 0) return "YOK";
        if (key == GLFW.GLFW_KEY_RIGHT_SHIFT) return "RSHIFT";
        if (key == GLFW.GLFW_KEY_LEFT_SHIFT) return "LSHIFT";
        if (key == GLFW.GLFW_KEY_RIGHT_CONTROL) return "RCTRL";
        if (key == GLFW.GLFW_KEY_LEFT_CONTROL) return "LCTRL";
        if (key == GLFW.GLFW_KEY_LEFT_ALT) return "LALT";
        if (key == GLFW.GLFW_KEY_SPACE) return "SPACE";
        String name = GLFW.glfwGetKeyName(key, 0);
        return name == null ? "KEY " + key : name.toUpperCase(Locale.ROOT);
    }

    // ------------------------------------------------------------------ input

    /** Top-most window containing the point (header or visible body), or null. */
    private Win topWindowAt(double mx, double my) {
        for (int i = ORDER.size() - 1; i >= 0; i--) {
            Win w = ORDER.get(i);
            float h = HEAD + (w.collapsed ? 0 : w.viewH + 3);
            if (inside(mx, my, w.x, w.y, W, h)) return w;
        }
        return null;
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        double mx = event.x(), my = event.y();
        int button = event.button();

        if (binding != null) {
            binding.setKey(-100 - button);
            binding = null;
            Config.save();
            return true;
        }

        Win win = topWindowAt(mx, my);
        if (win == null) return super.mouseClicked(event, doubleClick);

        ORDER.remove(win);
        ORDER.add(win);

        if (my < win.y + HEAD) {
            if (button == 0) {
                draggingWin = win;
                dragOffX = (float) mx - win.x;
                dragOffY = (float) my - win.y;
            } else if (button == 1) {
                win.collapsed = !win.collapsed;
            }
            return true;
        }

        layout();
        for (Item it : items) {
            if (it.win != win || !itemVisibleAt(it, mx, my)) continue;
            switch (it.kind) {
                case MODULE -> {
                    if (button == 0) {
                        it.module.toggle();
                        Config.save();
                    } else if (button == 1) {
                        if (!win.expanded.remove(it.module)) win.expanded.add(it.module);
                    }
                }
                case BOOL -> {
                    ((BoolSetting) it.setting).toggle();
                    Config.save();
                }
                case NUM -> {
                    draggingNumber = (NumberSetting) it.setting;
                    numX = it.x + 6;
                    numW = it.w - 8;
                    draggingNumber.setFromFraction((mx - numX) / Math.max(1f, numW));
                }
                case MODE -> {
                    ModeSetting ms = (ModeSetting) it.setting;
                    if (button == 1) ms.prev(); else ms.next();
                    Config.save();
                }
                case BIND -> binding = it.module;
            }
            return true;
        }
        return true;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
        double mx = event.x(), my = event.y();
        if (draggingWin != null) {
            draggingWin.x = (float) mx - dragOffX;
            draggingWin.y = (float) my - dragOffY;
            return true;
        }
        if (draggingNumber != null) {
            draggingNumber.setFromFraction((mx - numX) / Math.max(1f, numW));
            return true;
        }
        return super.mouseDragged(event, dx, dy);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        boolean handled = draggingWin != null || draggingNumber != null;
        if (draggingNumber != null) Config.save();
        draggingWin = null;
        draggingNumber = null;
        return handled || super.mouseReleased(event);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        Win win = topWindowAt(mouseX, mouseY);
        if (win == null || win.collapsed) return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
        win.scroll = Math.max(0, Math.min(win.scroll - (float) verticalAmount * 22f,
                Math.max(0, win.contentH - win.viewH)));
        return true;
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        int key = event.key();
        if (binding != null) {
            binding.setKey(key == GLFW.GLFW_KEY_ESCAPE ? -1 : key);
            binding = null;
            Config.save();
            return true;
        }
        if (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            onClose();
            return true;
        }
        return super.keyPressed(event);
    }

    @Override
    public boolean charTyped(CharacterEvent event) {
        return binding != null || super.charTyped(event);
    }
}
