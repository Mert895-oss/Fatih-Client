package dev.hudclient.module.combat;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.setting.BoolSetting;
import dev.hudclient.setting.NumberSetting;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.EntityHitResult;

/** Attacks only when the crosshair is already on a valid target. */
public final class TriggerBot extends Module {
    private final BoolSetting players = bool("Players", true);
    private final BoolSetting mobs = bool("Mobs", true);
    private final NumberSetting cooldown = num("Cooldown %", 95, 50, 100, 1);

    public TriggerBot() {
        super("TriggerBot", Category.COMBAT);
        setDescription("Nişangah hedefin üstündeyken, saldırı hazır olunca vurur.");
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.level == null || mc.gameMode == null || mc.screen != null) return;
        if (!(mc.hitResult instanceof EntityHitResult hit)) return;
        Entity e = hit.getEntity();
        if (!(e instanceof LivingEntity living) || !living.isAlive() || e == mc.player) return;
        boolean ok = (e instanceof Player && players.get() && !e.isSpectator()) || (e instanceof Mob && mobs.get());
        if (!ok) return;
        if (mc.player.getAttackStrengthScale(0.5F) < cooldown.getD() / 100.0) return;
        mc.gameMode.attack(mc.player, e);
        mc.player.swing(InteractionHand.MAIN_HAND);
    }
}
