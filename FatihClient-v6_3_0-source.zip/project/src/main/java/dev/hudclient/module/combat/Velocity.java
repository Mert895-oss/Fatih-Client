package dev.hudclient.module.combat;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.setting.NumberSetting;

/** Scales knockback received from server motion packets (see ClientPacketListenerMixin). */
public final class Velocity extends Module {
    public final NumberSetting horizontal = num("Yatay %", 0, 0, 100, 1);
    public final NumberSetting vertical = num("Dikey %", 0, 0, 100, 1);

    public Velocity() {
        super("Velocity", Category.COMBAT);
        setDescription("Aldığın geri tepmeyi (knockback) azaltır.");
    }
}
