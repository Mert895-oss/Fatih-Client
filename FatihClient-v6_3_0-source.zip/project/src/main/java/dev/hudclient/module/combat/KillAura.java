package dev.hudclient.module.combat;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.setting.BoolSetting;
import dev.hudclient.setting.NumberSetting;
import dev.hudclient.util.Targets;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/** Attacks the nearest valid target in range once the attack cooldown has recharged. */
public final class KillAura extends Module {
    private final NumberSetting range = num("Range", 3.6, 1.0, 6.0, 0.1);
    private final BoolSetting players = bool("Players", true);
    private final BoolSetting mobs = bool("Mobs", false);
    private final BoolSetting rotate = bool("Rotate", true);
    private final NumberSetting cooldown = num("Cooldown %", 95, 50, 100, 1);

    public KillAura() {
        super("KillAura", Category.COMBAT);
        setDescription("Yakındaki hedefe, saldırı süresi dolunca otomatik vurur.");
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.level == null || mc.gameMode == null || mc.screen != null) return;
        if (mc.player.isUsingItem()) return;
        if (mc.player.getAttackStrengthScale(0.5F) < cooldown.getD() / 100.0) return;

        LivingEntity target = Targets.nearest(mc, range.getD(), players.get(), mobs.get());
        if (target == null) return;

        if (rotate.get()) {
            Vec3 aim = target.getBoundingBox().getCenter();
            float[] rot = Targets.rotationTo(mc.player.getEyePosition(), aim);
            mc.player.setYRot(rot[0]);
            mc.player.setXRot(Math.max(-90.0F, Math.min(90.0F, rot[1])));
        }
        mc.gameMode.attack(mc.player, target);
        mc.player.swing(InteractionHand.MAIN_HAND);
    }
}
