package dev.hudclient.module.combat;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.setting.NumberSetting;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;

/** Raises the client-side entity interaction range. Servers still enforce their own limit. */
public final class Reach extends Module {
    private static final double VANILLA = 3.0;
    private final NumberSetting distance = num("Mesafe", 3.5, 3.0, 6.0, 0.1);

    public Reach() {
        super("Reach", Category.COMBAT);
        setDescription("Vuruş menzilini istemci tarafında uzatır (sunucu kendi sınırını uygular).");
    }

    @Override
    public void onTick() {
        AttributeInstance a = attr();
        if (a != null && a.getBaseValue() != distance.getD()) a.setBaseValue(distance.getD());
    }

    @Override
    public void onDisable() {
        AttributeInstance a = attr();
        if (a != null) a.setBaseValue(VANILLA);
    }

    private AttributeInstance attr() {
        return mc.player == null ? null : mc.player.getAttribute(Attributes.ENTITY_INTERACTION_RANGE);
    }
}
