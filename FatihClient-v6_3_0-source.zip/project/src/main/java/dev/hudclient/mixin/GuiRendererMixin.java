package dev.hudclient.mixin;

import dev.hudclient.gui.nvg.NanoGuiScreen;
import net.minecraft.client.gui.render.GuiRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Draws the NanoVG ClickGUI after Minecraft has finished its own GUI pass for the frame. */
@Mixin(GuiRenderer.class)
public abstract class GuiRendererMixin {
    @Inject(method = "render", at = @At("TAIL"))
    private void fatih$drawNanoGui(CallbackInfo ci) {
        NanoGuiScreen.drawIfActive();
    }
}
