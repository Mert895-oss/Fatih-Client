package dev.hudclient.mixin;

import dev.hudclient.util.CameraController;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Free Look: instead of hooking Camera#setRotation (whose signature changes between versions),
 * the local player's rotation is swapped for the free-look angles only while Camera#setup runs,
 * then restored. The body/movement rotation is therefore never touched.
 */
@Mixin(Camera.class)
public abstract class CameraMixin {
    @Unique private boolean fatih$swapped;
    @Unique private float fatih$yRot;
    @Unique private float fatih$xRot;
    @Unique private float fatih$yRotO;
    @Unique private float fatih$xRotO;

    @Inject(method = "setup", at = @At("HEAD"))
    private void fatih$beginFreeLook(CallbackInfo ci) {
        fatih$swapped = false;
        if (!CameraController.isFreeLook()) return;
        LocalPlayer p = Minecraft.getInstance().player;
        if (p == null) return;
        fatih$yRot = p.getYRot();
        fatih$xRot = p.getXRot();
        fatih$yRotO = p.yRotO;
        fatih$xRotO = p.xRotO;
        p.setYRot(CameraController.getFreeLookYaw());
        p.setXRot(CameraController.getFreeLookPitch());
        p.yRotO = CameraController.getFreeLookYaw();
        p.xRotO = CameraController.getFreeLookPitch();
        fatih$swapped = true;
    }

    @Inject(method = "setup", at = @At("TAIL"))
    private void fatih$endFreeLook(CallbackInfo ci) {
        if (!fatih$swapped) return;
        fatih$swapped = false;
        LocalPlayer p = Minecraft.getInstance().player;
        if (p == null) return;
        p.setYRot(fatih$yRot);
        p.setXRot(fatih$xRot);
        p.yRotO = fatih$yRotO;
        p.xRotO = fatih$xRotO;
    }
}
