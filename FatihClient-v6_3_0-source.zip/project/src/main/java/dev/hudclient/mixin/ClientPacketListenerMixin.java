package dev.hudclient.mixin;

import dev.hudclient.module.ModuleManager;
import dev.hudclient.module.combat.Velocity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPacketListener.class)
public abstract class ClientPacketListenerMixin {
    @Unique private Vec3 fatih$before;

    @Inject(method = "handleSetEntityMotion", at = @At("HEAD"))
    private void fatih$motionBefore(CallbackInfo ci) {
        LocalPlayer p = Minecraft.getInstance().player;
        fatih$before = p == null ? null : p.getDeltaMovement();
    }

    /** If the packet changed our own motion, keep only the configured share of that change. */
    @Inject(method = "handleSetEntityMotion", at = @At("RETURN"))
    private void fatih$motionAfter(CallbackInfo ci) {
        Velocity v = ModuleManager.get(Velocity.class);
        LocalPlayer p = Minecraft.getInstance().player;
        if (v == null || !v.isEnabled() || p == null || fatih$before == null) return;
        Vec3 after = p.getDeltaMovement();
        if (after.equals(fatih$before)) return;
        double h = v.horizontal.getD() / 100.0;
        double y = v.vertical.getD() / 100.0;
        p.setDeltaMovement(fatih$before.x + (after.x - fatih$before.x) * h,
                fatih$before.y + (after.y - fatih$before.y) * y,
                fatih$before.z + (after.z - fatih$before.z) * h);
        fatih$before = null;
    }
}
