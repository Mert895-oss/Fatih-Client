package dev.hudclient.gui;

import dev.hudclient.config.Config;
import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.module.ModuleManager;
import dev.hudclient.module.hud.HudModule;
import dev.hudclient.setting.BoolSetting;
import dev.hudclient.setting.ModeSetting;
import dev.hudclient.setting.NumberSetting;
import dev.hudclient.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Fatih Client's compact purple/black sidebar ClickGUI. */
public final class ClickGuiScreen extends Screen {
    private static final int HEAD = 54;
    private static final int FOOT = 38;
    private static final int SETTINGS_ROW = 43;
    private static final int MODULE_ROW = 38;

    private final int[] moduleScroll = new int[Category.values().length];
    private final int[] settingScroll = new int[Category.values().length + 1];
    private Category selected = Category.COMBAT;
    private Module open;
    private Module binding;
    private NumberSetting draggingNumber;
    private int numberX, numberW;
    private boolean draggingWindow;
    private boolean draggingScrollbar;
    private Module dragCandidate;
    private boolean reorderingModule;
    private int dragStartX, dragStartY;
    private int reorderTargetIndex;
    private int dragOffsetX, dragOffsetY;
    private int scrollbarGrabY;
    private int panelX = Integer.MIN_VALUE;
    private int panelY;
    private int panelW;
    private int panelH;
    private int navW;
    private boolean minimized;
    private boolean globalSettings;

    private static final int ACCENT = 0xFFB45CFF;
    private static final int ACCENT_DARK = 0xFF7036B8;
    private static final int TEXT = 0xFFF2F0F8;
    private static final int MUTED = 0xFF9B96A9;
    private static final int PANEL = 0xF20A0912;
    private static final int PANEL_2 = 0xEF100D1B;
    private static final int PANEL_3 = 0xFF191426;
    private static final int BORDER = 0xFF4E286F;

    public ClickGuiScreen() {
        super(Component.literal("Fatih Client"));
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void onClose() {
        Config.save();
        super.onClose();
    }

    private void layout() {
        panelW = Math.max(286, Math.min(462, width - 16));
        panelH = minimized ? HEAD : Math.max(260, Math.min(412, height - 16));
        navW = Math.max(112, Math.min(184, (int) (panelW * 0.39)));
        if (panelX == Integer.MIN_VALUE) {
            panelX = Math.max(8, width - panelW - Math.max(8, (int) (width * 0.16)));
            panelY = Math.max(8, (height - panelH) / 2 - 40);
        }
        panelX = Math.max(4, Math.min(panelX, Math.max(4, width - panelW - 4)));
        panelY = Math.max(4, Math.min(panelY, Math.max(4, height - panelH - 4)));
    }

    private int contentTop() { return panelY + HEAD + 5; }
    private int contentBottom() { return panelY + panelH - FOOT - SETTINGS_ROW; }
    private int contentHeight() { return Math.max(1, contentBottom() - contentTop()); }
    private int moduleX() { return panelX + navW + 1; }
    private int moduleRight() { return panelX + panelW - 1; }
    private int rowVisible() { return Math.max(1, contentHeight() / MODULE_ROW); }

    private static List<Module> modulesOf(Category category) {
        List<Module> result = new ArrayList<>();
        for (Module module : ModuleManager.all()) {
            if (module.category == category) result.add(module);
        }
        return result;
    }

    private static String keyName(int key) {
        if (key <= -100) return "MOUSE " + (-key - 99);
        if (key < 0) return "NONE";
        if (key == GLFW.GLFW_KEY_RIGHT_SHIFT) return "RSHIFT";
        if (key == GLFW.GLFW_KEY_LEFT_SHIFT) return "LSHIFT";
        if (key == GLFW.GLFW_KEY_RIGHT_CONTROL) return "RCTRL";
        if (key == GLFW.GLFW_KEY_LEFT_CONTROL) return "LCTRL";
        if (key == GLFW.GLFW_KEY_SPACE) return "SPACE";
        String name = GLFW.glfwGetKeyName(key, 0);
        return name == null ? "KEY " + key : name.toUpperCase(Locale.ROOT);
    }

    private static String trim(Minecraft mc, String value, int maxWidth) {
        if (maxWidth <= 0) return "";
        if (mc.font.width(value) <= maxWidth) return value;
        String result = value;
        while (!result.isEmpty() && mc.font.width(result + "…") > maxWidth) {
            result = result.substring(0, result.length() - 1);
        }
        return result + "…";
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        layout();
        super.render(g, mouseX, mouseY, delta);
        captureBindKey();
        drawBackdrop(g);
        drawWindow(g, mouseX, mouseY);
        if (binding != null) {
            String prompt = "BIR TUS VEYA FARE TUSU SEC...  (ESC: IPTAL)";
            g.fill(0, 0, width, height, 0x77000000);
            int w = Math.min(panelW - 20, font.width(prompt) + 28);
            int x = (width - w) / 2;
            int y = height / 2 - 18;
            rounded(g, x, y, w, 38, 0xFF120D1D, ACCENT);
            g.drawCenteredString(font, trim(Minecraft.getInstance(), prompt, w - 20), x + w / 2, y + 14, TEXT);
        }
    }

    private void drawBackdrop(GuiGraphics g) {
        g.fill(0, 0, width, height, 0x50000000);
    }

    private void drawWindow(GuiGraphics g, int mouseX, int mouseY) {
        int right = panelX + panelW;
        int bottom = panelY + panelH;
        // Soft outer glow and near-black body.
        rounded(g, panelX - 3, panelY - 3, panelW + 6, panelH + 6, 0x553F1C5D, ACCENT_DARK);
        rounded(g, panelX, panelY, panelW, panelH, PANEL, BORDER);
        rounded(g, panelX + 1, panelY + 1, panelW - 2, HEAD, PANEL_3, BORDER);

        // Header: stylised F mark, title and window actions.
        g.fill(panelX + 15, panelY + 11, panelX + 43, panelY + 39, 0xFF26123A);
        g.drawString(font, "F", panelX + 20, panelY + 13, ACCENT, true);
        g.drawString(font, "Fatih Client", panelX + 52, panelY + 18, TEXT, true);
        int actionY = panelY + 20;
        int closeX = right - 29;
        int minimizeX = right - 57;
        g.drawString(font, "×", closeX, actionY - 2, 0xFFD7BCEB, true);
        g.drawString(font, minimized ? "□" : "−", minimizeX, actionY, MUTED, false);
        g.fill(panelX + 1, panelY + HEAD, right - 1, panelY + HEAD + 1, BORDER);

        if (minimized) return;

        // Left category rail.
        int left = panelX + 1;
        int navRight = panelX + navW;
        g.fill(left, panelY + HEAD + 1, navRight, bottom - FOOT - 1, 0xCC0D0A16);
        g.fill(navRight, panelY + HEAD + 1, navRight + 1, bottom - FOOT - 1, 0xFF342044);
        int tabTop = contentTop() + 6;
        int tabH = Math.min(47, Math.max(38, contentHeight() / Category.values().length));
        Category[] categories = Category.values();
        for (int i = 0; i < categories.length; i++) {
            Category category = categories[i];
            int y = tabTop + i * tabH;
            if (y + tabH > contentBottom()) break;
            boolean active = selected == category && !globalSettings;
            if (active) {
                rounded(g, panelX + 8, y + 2, navW - 17, tabH - 5, 0xFF32164B, ACCENT_DARK);
                g.fill(panelX + 9, y + 8, panelX + 12, y + tabH - 9, ACCENT);
            }
            int iconColor = active ? ACCENT : 0xFFB2A9C2;
            g.drawCenteredString(font, category.icon, panelX + 31, y + (tabH - font.lineHeight) / 2, iconColor);
            g.drawString(font, category.label, panelX + 50, y + (tabH - font.lineHeight) / 2, active ? TEXT : 0xFFD0CADB, active);
        }

        // Right module list or the selected module's settings.
        if (open != null || globalSettings) drawSettings(g, mouseX, mouseY);
        else drawModules(g, mouseX, mouseY);

        // Global settings row, matching the supplied layout.
        int settingsY = bottom - FOOT - SETTINGS_ROW;
        g.fill(navRight + 1, settingsY, right - 1, settingsY + SETTINGS_ROW, 0xE3110D1A);
        g.fill(navRight + 1, settingsY, right - 1, settingsY + 1, 0xFF39224A);
        g.drawString(font, "⚙", navRight + 17, settingsY + 13, 0xFFD0C4E2);
        g.drawString(font, "Ayarlar", navRight + 42, settingsY + 13, TEXT, false);
        g.drawString(font, "›", right - 24, settingsY + 10, ACCENT, true);

        // Footer is also a drag handle for touch users.
        int footerY = bottom - FOOT;
        g.fill(panelX + 1, footerY, right - 1, bottom - 1, 0xF00D0916);
        g.fill(panelX + 1, footerY, right - 1, footerY + 1, 0xFF39224A);
        g.drawCenteredString(font, "✥  Sürükleyerek taşı", panelX + panelW / 2, footerY + 14, ACCENT);
    }

    private void drawModules(GuiGraphics g, int mouseX, int mouseY) {
        int x = moduleX() + 13;
        int right = moduleRight() - 12;
        int top = contentTop() + 6;
        int rowH = Math.min(MODULE_ROW, Math.max(32, contentHeight() / 6));
        List<Module> modules = modulesOf(selected);
        int visible = Math.max(1, (contentHeight() - 15) / rowH);
        int maxScroll = Math.max(0, modules.size() - visible);
        moduleScroll[selected.ordinal()] = clamp(moduleScroll[selected.ordinal()], 0, maxScroll);
        int start = moduleScroll[selected.ordinal()];
        int shown = Math.min(visible, modules.size() - start);

        for (int i = 0; i < shown; i++) {
            Module module = modules.get(start + i);
            int y = top + i * rowH;
            if (y + rowH > contentBottom()) break;
            boolean hover = mouseX >= x && mouseX < right && mouseY >= y && mouseY < y + rowH;
            if (hover) rounded(g, x - 4, y + 1, right - x + 8, rowH - 3, 0x773A2852, 0x553A2852);

            // Small neutral feature glyph, with a purple indicator for active modules.
            int cy = y + rowH / 2;
            g.fill(x + 1, cy - 8, x + 17, cy + 8, module.isEnabled() ? 0xFF2B1741 : 0xFF211C2A);
            g.drawCenteredString(font, moduleGlyph(module), x + 9, cy - 4, module.isEnabled() ? ACCENT : 0xFFB9B2C6);
            int labelColor = !module.isImplemented() ? 0xFF777184 : module.isEnabled() ? TEXT : 0xFFD1CBDC;
            g.drawString(font, trim(Minecraft.getInstance(), module.getName(), Math.max(38, right - x - 77)), x + 26, cy - 4, labelColor, false);

            // Settings shortcut supports touch: tapping this small gear is equivalent to RMB.
            int gearX = right - 43;
            g.drawCenteredString(font, "⚙", gearX, cy - 4, 0xFF9387A7);
            drawSwitch(g, right - 24, cy - 7, module.isImplemented() && module.isEnabled(), module.isImplemented());
            if (!module.isImplemented()) {
                g.drawString(font, "SOON", right - 49, y + 3, 0xFF716A7A, false);
            }
        }

        if (reorderingModule && dragCandidate != null) {
            int markerY = top + clamp(reorderTargetIndex - start, 0, Math.max(0, shown)) * rowH;
            g.fill(x - 4, markerY - 1, right + 3, markerY + 1, ACCENT);
        }

        // Scroll thumb is directly draggable (not wheel-only).
        if (modules.size() > visible) drawScrollbar(g, top, contentHeight() - 8, visible, modules.size(), moduleScroll[selected.ordinal()], maxScroll);
    }

    private void drawSettings(GuiGraphics g, int mouseX, int mouseY) {
        int x = moduleX() + 12;
        int right = moduleRight() - 12;
        int top = contentTop() + 6;
        int rowH = Math.min(36, Math.max(30, contentHeight() / 7));
        Module target = globalSettings ? ModuleManager.get(HudModule.class) : open;
        if (target == null) return;

        g.drawString(font, "‹", x, top - 1, ACCENT, true);
        g.drawString(font, globalSettings ? "GENEL AYARLAR" : target.getName().toUpperCase(Locale.ROOT), x + 19, top, TEXT, true);
        int bindY = top + rowH + 2;
        rounded(g, x, bindY, right - x, rowH - 3, 0xFF20172C, 0xFF4B2C68);
        g.drawString(font, "Bind", x + 9, bindY + 8, TEXT, false);
        String bindText = binding == target ? "TUS BEKLENIYOR..." : keyName(target.getKey());
        g.drawString(font, bindText, right - font.width(bindText) - 9, bindY + 8, ACCENT, false);

        List<Setting<?>> settings = target.getSettings();
        int start = settingScroll[globalSettings ? Category.values().length : selected.ordinal()];
        int firstY = bindY + rowH + 5;
        int rows = Math.max(1, (contentBottom() - firstY - 3) / rowH);
        int maxScroll = Math.max(0, settings.size() - rows);
        start = clamp(start, 0, maxScroll);
        settingScroll[globalSettings ? Category.values().length : selected.ordinal()] = start;
        for (int i = start; i < Math.min(settings.size(), start + rows); i++) {
            Setting<?> setting = settings.get(i);
            int y = firstY + (i - start) * rowH;
            rounded(g, x, y, right - x, rowH - 3, 0xB91A1424, 0x552F2441);
            if (setting instanceof BoolSetting bool) {
                g.drawString(font, trim(Minecraft.getInstance(), bool.name, right - x - 58), x + 9, y + 8, TEXT, false);
                g.drawString(font, bool.get() ? "ON" : "OFF", right - 37, y + 8, bool.get() ? ACCENT : MUTED, true);
            } else if (setting instanceof NumberSetting number) {
                g.drawString(font, trim(Minecraft.getInstance(), number.name + ": " + number.display(), right - x - 10), x + 9, y + 7, TEXT, false);
                int barX = x + 9;
                int barW = right - x - 18;
                g.fill(barX, y + rowH - 7, barX + barW, y + rowH - 4, 0xFF352B44);
                g.fill(barX, y + rowH - 7, barX + (int) (barW * number.fraction()), y + rowH - 4, ACCENT);
            } else if (setting instanceof ModeSetting mode) {
                g.drawString(font, trim(Minecraft.getInstance(), mode.name, right - x - 100), x + 9, y + 8, TEXT, false);
                String value = "‹ " + mode.get() + " ›";
                g.drawString(font, value, right - font.width(value) - 8, y + 8, ACCENT, false);
            } else {
                g.drawString(font, setting.name, x + 9, y + 8, TEXT, false);
            }
        }
        if (settings.size() > rows) drawScrollbar(g, firstY, contentBottom() - firstY - 5, rows, settings.size(), start, maxScroll);
    }

    private void drawScrollbar(GuiGraphics g, int y, int h, int visible, int total, int offset, int maxScroll) {
        int x = moduleRight() - 5;
        int thumbH = Math.max(18, h * visible / Math.max(1, total));
        int travel = Math.max(1, h - thumbH);
        int thumbY = y + (int) Math.round(travel * (offset / (double) Math.max(1, maxScroll)));
        g.fill(x, y, x + 2, y + h, 0xFF372B44);
        rounded(g, x - 1, thumbY, 4, thumbH, ACCENT, ACCENT_DARK);
    }

    private static String moduleGlyph(Module module) {
        String name = module.getName().toLowerCase(Locale.ROOT);
        if (name.contains("free") || name.contains("sprint") || name.contains("jump")) return "➤";
        if (name.contains("esp") || name.contains("finder") || name.contains("radar")) return "◎";
        if (name.contains("auto") || name.contains("totem")) return "✧";
        if (name.contains("hud") || name.contains("click")) return "▦";
        return "◇";
    }

    private static void drawSwitch(GuiGraphics g, int x, int y, boolean enabled, boolean implemented) {
        int track = !implemented ? 0xFF28242F : enabled ? ACCENT_DARK : 0xFF3A3444;
        rounded(g, x, y, 23, 14, track, implemented && enabled ? ACCENT : 0xFF51485B);
        int knobX = enabled ? x + 12 : x + 2;
        g.fill(knobX, y + 2, knobX + 9, y + 12, 0xFFF5F0FA);
    }

    private static void rounded(GuiGraphics g, int x, int y, int w, int h, int fill, int border) {
        if (w <= 0 || h <= 0) return;
        g.fill(x + 2, y, x + w - 2, y + h, fill);
        g.fill(x + 1, y + 1, x + w - 1, y + h - 1, fill);
        g.fill(x, y + 2, x + w, y + h - 2, fill);
        if (border != 0) {
            g.fill(x + 3, y, x + w - 3, y + 1, border);
            g.fill(x + 3, y + h - 1, x + w - 3, y + h, border);
            g.fill(x, y + 3, x + 1, y + h - 3, border);
            g.fill(x + w - 1, y + 3, x + w, y + h - 3, border);
        }
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private void captureBindKey() {
        if (binding == null) return;
        long window = Minecraft.getInstance().getWindow().handle();
        for (int key = GLFW.GLFW_KEY_SPACE; key <= GLFW.GLFW_KEY_LAST; key++) {
            if (GLFW.glfwGetKey(window, key) == GLFW.GLFW_PRESS) {
                binding.setKey(key == GLFW.GLFW_KEY_ESCAPE ? -1 : key);
                binding = null;
                Config.save();
                return;
            }
        }
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        layout();
        int mx = (int) event.x();
        int my = (int) event.y();
        int button = event.button();
        int right = panelX + panelW;
        int bottom = panelY + panelH;

        if (binding != null) {
            binding.setKey(-100 - button);
            binding = null;
            Config.save();
            return true;
        }

        // Header actions and drag handle.
        if (my >= panelY && my < panelY + HEAD) {
            if (mx >= right - 38) {
                onClose();
                return true;
            }
            if (mx >= right - 68) {
                minimized = !minimized;
                layout();
                return true;
            }
            draggingWindow = true;
            dragOffsetX = mx - panelX;
            dragOffsetY = my - panelY;
            return true;
        }
        if (minimized) return true;

        // Footer drag handle, usable by mouse and touch.
        if (my >= bottom - FOOT) {
            draggingWindow = true;
            dragOffsetX = mx - panelX;
            dragOffsetY = my - panelY;
            return true;
        }

        int settingsY = bottom - FOOT - SETTINGS_ROW;
        if (my >= settingsY && my < settingsY + SETTINGS_ROW && mx >= panelX + navW) {
            globalSettings = true;
            open = null;
            settingScroll[Category.values().length] = 0;
            return true;
        }

        // Sidebar category selection.
        if (mx >= panelX && mx < panelX + navW && my >= contentTop()) {
            int tabTop = contentTop() + 6;
            int tabH = Math.min(47, Math.max(38, contentHeight() / Category.values().length));
            int index = (my - tabTop) / tabH;
            if (index >= 0 && index < Category.values().length && my < tabTop + Category.values().length * tabH) {
                selected = Category.values()[index];
                globalSettings = false;
                open = null;
                return true;
            }
        }

        int contentTop = contentTop() + 6;
        if (mx >= moduleX() && mx < moduleRight() && my >= contentTop && my < contentBottom()) {
            if (open != null || globalSettings) {
                Module target = globalSettings ? ModuleManager.get(HudModule.class) : open;
                if (target == null) return true;
                int rowH = Math.min(36, Math.max(30, contentHeight() / 7));
                int top = contentTop;
                // Back arrow.
                if (mx < moduleX() + 37 && my < top + rowH) {
                    open = null;
                    globalSettings = false;
                    return true;
                }
                int bindY = top + rowH + 2;
                if (my >= bindY && my < bindY + rowH) {
                    binding = target;
                    return true;
                }
                List<Setting<?>> settings = target.getSettings();
                int firstY = bindY + rowH + 5;
                int startIndex = settingScroll[globalSettings ? Category.values().length : selected.ordinal()];
                int rows = Math.max(1, (contentBottom() - firstY - 3) / rowH);
                for (int i = startIndex; i < Math.min(settings.size(), startIndex + rows); i++) {
                    int y = firstY + (i - startIndex) * rowH;
                    if (my < y || my >= y + rowH - 3) continue;
                    Setting<?> setting = settings.get(i);
                    if (setting instanceof BoolSetting bool) {
                        bool.toggle();
                        Config.save();
                    } else if (setting instanceof NumberSetting number) {
                        draggingNumber = number;
                        numberX = moduleX() + 12;
                        numberW = moduleRight() - 24;
                        number.setFromFraction((mx - numberX) / (double) numberW);
                    } else if (setting instanceof ModeSetting mode) {
                        if (button == 1 || mx < moduleX() + 40) mode.prev(); else mode.next();
                        Config.save();
                    }
                    return true;
                }
                return true;
            }

            List<Module> modules = modulesOf(selected);
            int rowH = Math.min(MODULE_ROW, Math.max(32, contentHeight() / 6));
            int top = contentTop;
            int visible = Math.max(1, (contentHeight() - 15) / rowH);
            int index = moduleScroll[selected.ordinal()] + Math.max(0, (my - top) / rowH);
            if (index < modules.size() && my < top + visible * rowH) {
                Module module = modules.get(index);
                int gearX = moduleRight() - 55;
                if (button == 1 || mx >= gearX && mx < gearX + 24) {
                    if (module.isImplemented()) {
                        open = module;
                        globalSettings = false;
                        settingScroll[selected.ordinal()] = 0;
                    }
                } else if (mx < moduleX() + 23) {
                    // Drag the small leading icon to reorder modules; a simple tap still toggles.
                    dragCandidate = module;
                    dragStartX = mx;
                    dragStartY = my;
                    reorderTargetIndex = index;
                    reorderingModule = false;
                } else {
                    module.toggle();
                    Config.save();
                }
                return true;
            }

            // Scrollbar drag starts on the visible track at the right edge.
            if (mx >= moduleRight() - 9) {
                draggingScrollbar = true;
                scrollbarGrabY = my;
                return true;
            }
        }
        return true;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        layout();
        int step = verticalAmount < 0 ? 2 : -2;
        if (open != null || globalSettings) {
            int key = globalSettings ? Category.values().length : selected.ordinal();
            Module target = globalSettings ? ModuleManager.get(HudModule.class) : open;
            if (target != null) {
                int rowH = Math.min(36, Math.max(30, contentHeight() / 7));
                int rows = Math.max(1, (contentBottom() - (contentTop() + 6 + rowH * 2 + 7)) / rowH);
                settingScroll[key] = clamp(settingScroll[key] + step, 0, Math.max(0, target.getSettings().size() - rows));
            }
            return true;
        }
        List<Module> modules = modulesOf(selected);
        int visible = Math.max(1, (contentHeight() - 15) / Math.min(MODULE_ROW, Math.max(32, contentHeight() / 6)));
        moduleScroll[selected.ordinal()] = clamp(moduleScroll[selected.ordinal()] + step, 0, Math.max(0, modules.size() - visible));
        return true;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dragXAmount, double dragYAmount) {
        layout();
        int mx = (int) event.x();
        int my = (int) event.y();
        if (draggingWindow) {
            panelX = mx - dragOffsetX;
            panelY = my - dragOffsetY;
            layout();
            return true;
        }
        if (dragCandidate != null) {
            if (!reorderingModule && Math.abs(mx - dragStartX) + Math.abs(my - dragStartY) >= 5) {
                reorderingModule = true;
            }
            if (reorderingModule) {
                int rowH = Math.min(MODULE_ROW, Math.max(32, contentHeight() / 6));
                int top = contentTop() + 6;
                int visible = Math.max(1, (contentHeight() - 15) / rowH);
                int relative = clamp((my - top) / rowH, 0, visible);
                reorderTargetIndex = moduleScroll[selected.ordinal()] + relative;
                reorderTargetIndex = clamp(reorderTargetIndex, 0, modulesOf(selected).size() - 1);
            }
            return true;
        }
        if (draggingNumber != null) {
            draggingNumber.setFromFraction((mx - numberX) / (double) Math.max(1, numberW));
            return true;
        }
        if (draggingScrollbar) {
            int rowH = Math.min(MODULE_ROW, Math.max(32, contentHeight() / 6));
            List<Module> modules = modulesOf(selected);
            int visible = Math.max(1, (contentHeight() - 15) / rowH);
            int maxScroll = Math.max(0, modules.size() - visible);
            int movement = my - scrollbarGrabY;
            moduleScroll[selected.ordinal()] = clamp(moduleScroll[selected.ordinal()] + (movement > 0 ? 1 : movement < 0 ? -1 : 0), 0, maxScroll);
            scrollbarGrabY = my;
            return true;
        }
        return super.mouseDragged(event, dragXAmount, dragYAmount);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        boolean handled = draggingWindow || draggingScrollbar || draggingNumber != null || dragCandidate != null;
        if (dragCandidate != null) {
            if (reorderingModule) {
                ModuleManager.moveWithinCategory(dragCandidate, reorderTargetIndex);
            } else {
                dragCandidate.toggle();
            }
            Config.save();
        }
        draggingWindow = false;
        draggingScrollbar = false;
        draggingNumber = null;
        dragCandidate = null;
        reorderingModule = false;
        if (handled) return true;
        return super.mouseReleased(event);
    }
}
