package dev.hudclient.module;

/** Categories shown by the Fatih Client compact sidebar. */
public enum Category {
    COMBAT("Combat", "⚔"),
    MOVEMENT("Movement", "➤"),
    RENDER("Render", "▣"),
    MISC("Misc", "⚙"),
    HUD("Hud", "▥");

    public final String label;
    public final String icon;

    Category(String label, String icon) {
        this.label = label;
        this.icon = icon;
    }
}
