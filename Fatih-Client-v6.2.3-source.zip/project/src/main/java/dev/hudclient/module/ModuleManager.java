package dev.hudclient.module;

import dev.hudclient.HudClient;
import dev.hudclient.gui.ClickGuiScreen;
import dev.hudclient.module.catalog.CatalogModule;
import dev.hudclient.module.chunk.AmethystActivityFinder;
import dev.hudclient.module.chunk.PlayerChunk;
import dev.hudclient.module.chunk.SpawnerChunkFinder;
import dev.hudclient.module.combat.AutoTotem;
import dev.hudclient.module.combat.Sprint;
import dev.hudclient.module.hud.HudModule;
import dev.hudclient.module.misc.AutoEat;
import dev.hudclient.module.misc.AutoLoot;
import dev.hudclient.module.misc.SkinProtect;
import dev.hudclient.module.misc.AutoTool;
import dev.hudclient.module.misc.Fullbright;
import dev.hudclient.module.misc.KeyPearl;
import dev.hudclient.module.misc.HoleEsp;
import dev.hudclient.module.misc.LightFinder;
import dev.hudclient.module.misc.AutoLog;
import dev.hudclient.module.misc.AutoReconnect;
import dev.hudclient.module.misc.AutoMine;
import dev.hudclient.module.misc.AutoClicker;
import dev.hudclient.module.misc.FastPlace;
import dev.hudclient.module.render.SpawnerProtect;
import dev.hudclient.module.misc.CordSnapper;
import dev.hudclient.module.misc.AntiTrap;
import dev.hudclient.module.render.ItemSnapper;
import dev.hudclient.module.render.NetheriteFinder;
import dev.hudclient.module.render.OreSim;
import dev.hudclient.module.render.SuspiciousEsp;
import dev.hudclient.module.chunk.JungleFinder;
import dev.hudclient.module.render.PearlPredict;
import dev.hudclient.module.render.PlayerEsp;
import dev.hudclient.module.render.StorageEsp;
import dev.hudclient.module.render.TargetHud;
import dev.hudclient.module.render.JumpCircles;
import dev.hudclient.module.render.BlockEsp;
import dev.hudclient.module.render.Freecam;
import dev.hudclient.module.render.FreeLook;
import dev.hudclient.module.render.SwingSpeed;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ModuleManager {
    private static final List<Module> MODULES = new ArrayList<>();
    private static boolean guiKeyWasDown;
    private static boolean initialized;

    private ModuleManager() {
    }

    private static void addPreview(Category category, String... namesAndDescriptions) {
        for (int i = 0; i + 1 < namesAndDescriptions.length; i += 2) {
            MODULES.add(new CatalogModule(namesAndDescriptions[i], category, namesAndDescriptions[i + 1]));
        }
    }

    public static void init() {
        if (initialized) return;
        initialized = true;

        // COMBAT — defensive inventory utility only. Weapon-automation features are not part of this build.
        MODULES.add(new AutoTotem());

        // MOVEMENT, MISC and discovery utilities are grouped into the five sidebar categories shown in the approved design.
        // Sprint and the camera modules are placed in Movement; Donut / basefinding utilities remain under Misc / Render.
        MODULES.add(new Sprint());
        MODULES.add(new AutoEat());
        MODULES.add(new AutoTool());
        MODULES.add(new KeyPearl());
        MODULES.add(new AutoLog());
        MODULES.add(new CordSnapper());
        MODULES.add(new AutoClicker());
        MODULES.add(new AutoMine());
        MODULES.add(new FastPlace());
        MODULES.add(new AutoReconnect());
        MODULES.add(new SkinProtect());
        MODULES.add(new AutoLoot());
        addPreview(Category.MISC,
                "Auto TPA", "Not implemented: requires a configurable player target and server command.",
                "Elytra Glide", "Not implemented: flight behavior varies by server and needs in-game validation.",
                "Name Protect", "Not implemented: name replacement needs chat and nametag hooks.");

        // DONUT — only client-visible chunk inspection is currently active.
        MODULES.add(new SpawnerChunkFinder());
        MODULES.add(new PlayerChunk());
        MODULES.add(new AmethystActivityFinder());
        MODULES.add(new AntiTrap());
        MODULES.add(new ItemSnapper());
        MODULES.add(new NetheriteFinder());
        MODULES.add(new SpawnerProtect());
        addPreview(Category.MISC,
                "Auction Sniper", "Not implemented: auction GUI and price rules are server-specific.",
                "Auto Sell", "Not implemented: server trading commands and confirmations vary.",
                "Auto Spawner Sell", "Not implemented: spawner sale flow requires server-specific confirmation handling.",
                "RTP Base Finder", "Not implemented: random teleport and base evaluation is server-specific.",
                "Auto Shulker Buy", "Not implemented: requires server auction UI parsing and a user price limit.",
                "Tunnel Base Finder", "Not implemented: no hidden-base inference or anti-xray bypass is provided.",
                "Fake Stats", "Not implemented: scoreboard spoofing is not included.",
                "Chunk Finder", "Not implemented: generic base detection is unreliable without server-authorized data.");

        // BASEFINDING — only visible loaded-world geometry is inspected.
        MODULES.add(new HoleEsp());
        MODULES.add(new LightFinder());
        MODULES.add(new JungleFinder());
        addPreview(Category.RENDER,
                "Seed Chunk Finder", "Not implemented: requires a known world seed; seed recovery is not provided.");

        // RENDER — working visual modules and HUD, followed by the screenshot's module catalogue.
        MODULES.add(new PlayerEsp());
        MODULES.add(new Freecam());
        MODULES.add(new FreeLook());
        MODULES.add(new StorageEsp());
        MODULES.add(new SuspiciousEsp());
        MODULES.add(new PearlPredict());
        MODULES.add(new TargetHud());
        MODULES.add(new JumpCircles());
        MODULES.add(new HudModule());
        MODULES.add(new Fullbright());
        MODULES.add(new BlockEsp());
        MODULES.add(new OreSim());
        MODULES.add(new SwingSpeed());
        addPreview(Category.RENDER,
                "RemLightbox", "Not implemented: the screenshot label is ambiguous; implementation needs the intended feature definition.");
    }

    public static List<Module> all() {
        return Collections.unmodifiableList(MODULES);
    }

    /** Reorders a module within its current category; category membership stays unchanged. */
    public static void moveWithinCategory(Module moving, int newIndex) {
        if (moving == null || !MODULES.contains(moving)) return;
        List<Module> sameCategory = new ArrayList<>();
        for (Module module : MODULES) {
            if (module.category == moving.category && module != moving) sameCategory.add(module);
        }
        int target = Math.max(0, Math.min(newIndex, sameCategory.size()));
        MODULES.remove(moving);
        int insertAt;
        if (target >= sameCategory.size()) {
            Module last = sameCategory.isEmpty() ? null : sameCategory.get(sameCategory.size() - 1);
            insertAt = last == null ? MODULES.size() : MODULES.indexOf(last) + 1;
        } else {
            insertAt = MODULES.indexOf(sameCategory.get(target));
        }
        MODULES.add(Math.max(0, Math.min(insertAt, MODULES.size())), moving);
    }

    @SuppressWarnings("unchecked")
    public static <T extends Module> T get(Class<T> type) {
        for (Module m : MODULES) {
            if (type.isInstance(m)) return (T) m;
        }
        return null;
    }

    /** Accent color (RGB) taken from the HUD module color. */
    public static int accent() {
        HudModule hud = get(HudModule.class);
        return hud == null ? 0xB35CFF : hud.color.rgb();
    }

    public static void tick(Minecraft mc) {
        if (mc.player == null || mc.level == null) {
            AutoReconnect reconnect = get(AutoReconnect.class);
            if (reconnect != null) reconnect.tickDisconnected();
            // Do not retain an old camera reference after leaving a world or server.
            if (dev.hudclient.util.CameraController.isActive()) {
                dev.hudclient.util.CameraController.stop();
                for (Module module : MODULES) {
                    if (module instanceof Freecam || module instanceof FreeLook) module.setEnabled(false);
                }
            }
            return;
        }
        handleKeys(mc);
        if (dev.hudclient.util.CameraController.isActive()
                && !dev.hudclient.util.CameraController.isFreecam()) {
            dev.hudclient.util.CameraController.tick(0.0);
        }
        for (Module m : MODULES) {
            if (!m.isEnabled() || !m.isImplemented()) continue;
            try {
                m.onTick();
            } catch (RuntimeException e) {
                HudClient.LOGGER.error("Error in {} tick", m.getName(), e);
            }
        }
    }

    public static void render3D() {
        for (Module m : MODULES) {
            if (!m.isEnabled() || !m.isImplemented()) continue;
            try {
                m.onRender3D();
            } catch (RuntimeException e) {
                HudClient.LOGGER.error("Error in {} render", m.getName(), e);
            }
        }
    }

    public static void renderHud(GuiGraphics graphics) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        for (Module m : MODULES) {
            if (!m.isEnabled() || !m.isImplemented()) continue;
            try {
                m.onRenderHud(graphics);
            } catch (RuntimeException e) {
                HudClient.LOGGER.error("Error in {} hud", m.getName(), e);
            }
        }
    }

    private static void handleKeys(Minecraft mc) {
        long window = mc.getWindow().handle();
        if (mc.screen != null) {
            // Always release hold-style actions when a screen opens, preventing stuck cameras.
            for (Module m : MODULES) {
                if (m.handlesHoldBind() && m.keyWasDown) {
                    m.onBoundKeyState(false);
                    m.keyWasDown = false;
                }
            }
            guiKeyWasDown = false;
            return;
        }

        boolean guiDown = GLFW.glfwGetKey(window, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
        if (guiDown && !guiKeyWasDown) mc.setScreen(new ClickGuiScreen());
        guiKeyWasDown = guiDown;

        for (Module m : MODULES) {
            int key = m.getKey();
            if (key == -1 || !m.isImplemented()) continue;
            boolean down;
            if (key <= -100) {
                int mouseButton = -100 - key;
                down = GLFW.glfwGetMouseButton(window, mouseButton) == GLFW.GLFW_PRESS;
            } else {
                down = GLFW.glfwGetKey(window, key) == GLFW.GLFW_PRESS;
            }

            if (m.handlesHoldBind()) {
                if (down != m.keyWasDown) m.onBoundKeyState(down);
                m.keyWasDown = down;
                continue;
            }

            if (down && !m.keyWasDown) {
                if (m.handlesBindPress()) m.onBoundKeyPressed();
                else m.toggle();
            }
            m.keyWasDown = down;
        }
    }
}
