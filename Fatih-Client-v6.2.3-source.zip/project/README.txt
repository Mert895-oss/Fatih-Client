FATIH CLIENT v6.2.3 — Minecraft 1.21.11 (Fabric)

Project type: Fabric client mod source (Java 21).
Brand: FATIH CLIENT
Mod id: fatihclient
Target: Minecraft Java 1.21.11 / Fabric Loader 0.18.1+ / Fabric API 0.141.1+1.21.11

APPROVED INTERFACE DESIGN
- The ClickGUI has the exact five-section layout from the supplied Fatih Client design: Combat, Movement, Render, Misc and Hud.
- Purple neon accents, near-black translucent panels, compact module rows, an F logo, a draggable window and a separate settings view.
- Right Shift opens the menu. Left click toggles a module. Right click or the small gear shortcut opens that module's settings.
- The module list has mouse-wheel scrolling and a draggable scroll thumb. Drag a module's leading icon to reorder it inside its category. The whole window can be dragged by its header or footer.
- Settings include a Bind row; choose it and press a keyboard or mouse button. Escape clears the bind.
- On touch launchers, tapping the gear opens module settings. Touch scrolling depends on the launcher forwarding swipe gestures as Minecraft scroll events.

HUD DESIGN
- Top-left crown watermark with Fatih Client v6.2.3 and FPS / ping.
- Circular heading-up radar in the upper-left with N / E / S / W labels that rotate with the player; dots are based only on entities already present in the client world.
- Active potion effects below the radar; coordinates and movement speed follow below the effects.
- A small original pixel-drawn Ottoman bust emblem and local time/date at the top-centre.
- Active module list at the top-right, plus the server scoreboard when present.
- WASD / Space, LMB / RMB CPS and crosshair remain configurable.
- HUD scale, accent colour and component visibility are configurable through the HUD module settings.

IMPLEMENTED MODULES IN THIS SOURCE
Combat: Auto Totem.
Movement: Sprint, Freecam, Free Look.
Misc: Auto Eat, Auto Tool, Key Pearl, Auto Log, Auto Reconnect, Auto Mine, Auto Clicker, Fast Place, Cord Snapper, Anti Trap, Skin Protect, Auto Loot, Spawner Chunk Finder, Player Chunk, Amethyst Activity Finder, Item Snapper, Netherite Finder, Spawner Protect.
Render: Player ESP, Storage ESP, Suspicious ESP, Pearl Predict, Target HUD, Jump Circles, Fullbright, Block ESP, Ore Sim, SwingSpeed, Hole ESP, Light Finder, Jungle Finder.
Hud: HUD.

CAMERA / VISIBILITY LIMITS
- Freecam uses a client-side detached camera; the local player is held at the recorded client position. WASD moves the camera, Space / Shift move vertically, and Sprint increases speed.
- Free Look separates camera rotation from the local player's body rotation. It can be held with a key bind or enabled from the GUI.
- Camera modules have not yet been verified in-game on every server or launcher. Test them in a disposable singleplayer world first.
- Player ESP can draw entities that the client has already received. It does not reveal unloaded entities or obtain hidden server data.
- Ore, ancient-debris and spawner marking is limited to directly visible blocks in already-loaded chunks. There is no anti-Xray bypass or hidden-block inference.
- Amethyst activity is only a heuristic; it cannot prove that a player or base is present.

SOON / NOT IMPLEMENTED
- Auto TPA, Elytra Glide, Name Protect.
- Auction Sniper, Auto Sell, Auto Spawner Sell, RTP Base Finder, Auto Shulker Buy, Tunnel Base Finder, Fake Stats, Chunk Finder.
- Seed Chunk Finder and RemLightbox (the original label is ambiguous).
- Proxy settings screen and main-menu button are planned but are not part of this source update. A proxy only changes the network route; it does not grant offline/cracked account authentication.
- These are catalogue entries, not working modules. No unfinished feature is shown as enabled.

ANUBIS REFERENCE REVIEW
- Anubis Beta 0.9.9.1 was inspected as a Minecraft 1.21.11 feature checklist. Its defaults contain ideas such as hotkeys, nametags, zoom, Spotify HUD, custom crosshair and visual effects.
- The supplied Anubis archive identifies itself as GPL-3.0-only. No Anubis Java source, binaries, fonts, textures or other resources were copied into Fatih Client. This project remains an independent implementation; the Anubis feature list is used only as design research.
- Candidate ideas for a later independent pass include Nametags, Zoom, Hotkeys, Spotify HUD, Custom FOV, Motion Blur and Time Changer. They are not silently marked as implemented in this build.

MOBILE / PC
- This is a Java Fabric mod, not a Bedrock add-on. It can be tested on desktop Java and Android launchers that provide Java 21 + Fabric 1.21.11.
- The GUI uses Minecraft screen mouse events, so standard touch-to-click mapping should work in compatible launchers. Dedicated on-screen keybind controls and real-device FCL testing are still outstanding.

BUILD
- JDK 21, Gradle 9.2.0, Fabric Loom 1.14-SNAPSHOT.
- Run `gradle build` from the folder containing build.gradle.
- On GitHub Actions, push the project folder or upload a source ZIP at repository root and run the workflow manually.
- Expected main output: build/libs/Fatih-Client-6.2.3.jar.

VALIDATION STATUS
- Java 21 is available in the current workspace, but Gradle and cached Minecraft/Fabric dependencies are not installed and network access is unavailable here.
- Therefore this source update has been statically reviewed but has NOT been compiled or run in Minecraft in this workspace. A successful GitHub Actions build and an in-game test are required before calling the JAR verified.
