package dev.hudclient.gui;

import dev.hudclient.config.Config;
import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.module.ModuleManager;
import dev.hudclient.setting.BoolSetting;
import dev.hudclient.setting.ModeSetting;
import dev.hudclient.setting.NumberSetting;
import dev.hudclient.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Dark, compact five-column Fatih Client ClickGUI. Uses Minecraft's GUI renderer. */
public final class ClickGuiScreen extends Screen {
    private static final int TOP = 35;
    private static final int HEAD = 21;
    private static final int ROW = 16;
    private static final int GAP = 5;
    private static final int MIN_PANEL = 76;
    private static final int MAX_PANEL = 154;
    private static final int SETTINGS_COL = 174;

    private final int[] scrollOffsets = new int[Category.values().length];
    private Module open;
    private Module binding;
    private NumberSetting dragging;
    private int dragX0;
    private int dragX1;
    private int px, py, pw, ph, rowsPerCol;

    public ClickGuiScreen() {
        super(Component.literal("Fatih Client"));
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void onClose() {
        Config.save();
        super.onClose();
    }

    private static List<Module> modulesOf(Category category) {
        List<Module> result = new ArrayList<>();
        for (Module module : ModuleManager.all()) {
            if (module.category == category) result.add(module);
        }
        return result;
    }

    private int panelWidth() {
        int available = Math.max(MIN_PANEL * Category.values().length, width - 20);
        return Math.max(MIN_PANEL, Math.min(MAX_PANEL,
                (available - (Category.values().length - 1) * GAP) / Category.values().length));
    }

    private int catX(int index) {
        int w = panelWidth();
        int total = Category.values().length * w + (Category.values().length - 1) * GAP;
        return Math.max(8, (width - total) / 2) + index * (w + GAP);
    }

    private int bodyHeight() {
        return Math.max(ROW * 5, height - TOP - 27);
    }

    private int visibleRows() {
        return Math.max(1, (bodyHeight() - HEAD - 5) / ROW);
    }

    private static String keyName(int key) {
        if (key <= -100) return "MOUSE" + (-key - 99);
        if (key < 0) return "";
        if (key == GLFW.GLFW_KEY_RIGHT_SHIFT) return "RSHIFT";
        if (key == GLFW.GLFW_KEY_LEFT_SHIFT) return "LSHIFT";
        if (key == GLFW.GLFW_KEY_RIGHT_CONTROL) return "RCTRL";
        if (key == GLFW.GLFW_KEY_LEFT_CONTROL) return "LCTRL";
        if (key == GLFW.GLFW_KEY_RIGHT_ALT) return "RALT";
        if (key == GLFW.GLFW_KEY_LEFT_ALT) return "LALT";
        if (key == GLFW.GLFW_KEY_SPACE) return "SPACE";
        if (key == GLFW.GLFW_KEY_TAB) return "TAB";
        String name = GLFW.glfwGetKeyName(key, 0);
        return name == null ? "K" + key : name.toUpperCase(Locale.ROOT);
    }

    private static String trim(String text, int maxWidth) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.font.width(text) <= maxWidth) return text;
        String suffix = "…";
        String s = text;
        while (!s.isEmpty() && mc.font.width(s + suffix) > maxWidth) s = s.substring(0, s.length() - 1);
        return s + suffix;
    }

    private void layoutSettings() {
        if (open == null) return;
        int count = Math.max(1, open.getSettings().size());
        int max = Math.max(3, (height - 82 - HEAD) / ROW);
        int cols = (count + max - 1) / max;
        rowsPerCol = (count + cols - 1) / cols;
        pw = Math.min(cols * SETTINGS_COL + 12, Math.max(190, width - 16));
        ph = Math.min(height - 16, HEAD + ROW + rowsPerCol * ROW + 16);
        px = (width - pw) / 2;
        py = Math.max(8, (height - ph) / 2);
    }

    private int settingX(int index) { return px + 6 + (index / rowsPerCol) * SETTINGS_COL; }
    private int settingY(int index) { return py + HEAD + ROW + 8 + (index % rowsPerCol) * ROW; }
    private int settingW() { return Math.max(80, Math.min(SETTINGS_COL - 8, pw - 12)); }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        super.render(g, mouseX, mouseY, delta);
        pollBindKey();

        int accent = 0xFF000000 | ModuleManager.accent();
        int active = 0;
        int supported = 0;
        for (Module module : ModuleManager.all()) {
            if (module.isImplemented()) supported++;
            if (module.isEnabled()) active++;
        }

        g.fill(0, 0, width, height, 0x74040710);
        g.fill(8, 7, width - 8, 29, 0xF00C101B);
        g.fill(8, 7, 11, 29, accent);
        g.drawString(font, "FATIH", 17, 14, 0xFFFFFFFF, true);
        g.drawString(font, "CLIENT  /  1.21.11", 60, 14, 0xFF8B96AA, false);
        String count = active + " ACTIVE   " + supported + "/" + ModuleManager.all().size() + " READY";
        g.drawString(font, count, width - font.width(count) - 17, 14, accent, false);

        Category[] categories = Category.values();
        int panelW = panelWidth();
        int panelBottom = TOP + bodyHeight();
        for (int i = 0; i < categories.length; i++) {
            int x = catX(i);
            int y = TOP;
            List<Module> modules = modulesOf(categories[i]);
            int shown = Math.min(modules.size(), visibleRows());
            int h = HEAD + visibleRows() * ROW + 5;

            g.fill(x - 1, y - 1, x + panelW + 1, y + h + 1, 0x66000000);
            g.fill(x, y, x + panelW, y + h, 0xE90B101B);
            g.fill(x, y, x + panelW, y + HEAD, 0xFF171E2B);
            g.fill(x, y + HEAD - 1, x + panelW, y + HEAD, accent);
            g.drawString(font, categories[i].label.toUpperCase(Locale.ROOT), x + 6, y + 7, 0xFFE8ECF5, true);
            String total = modules.size() + "";
            g.drawString(font, total, x + panelW - font.width(total) - 6, y + 7, 0xFF8792A7, false);

            int maxScroll = Math.max(0, modules.size() - visibleRows());
            scrollOffsets[i] = Math.max(0, Math.min(scrollOffsets[i], maxScroll));
            int start = scrollOffsets[i];
            for (int j = 0; j < shown; j++) {
                int index = start + j;
                if (index >= modules.size()) break;
                Module module = modules.get(index);
                int ry = y + HEAD + j * ROW;
                boolean hover = open == null && mouseX >= x && mouseX < x + panelW
                        && mouseY >= ry && mouseY < ry + ROW;
                if (hover) g.fill(x + 2, ry, x + panelW - 2, ry + ROW - 1, 0x263A4A65);

                if (module.isEnabled()) g.fill(x + 2, ry + 2, x + 4, ry + ROW - 3, accent);
                int labelColor = !module.isImplemented() ? 0xFF70798A
                        : module.isEnabled() ? accent : 0xFFC1C8D5;
                String name = trim(module.getName(), Math.max(26, panelW - 39));
                g.drawString(font, name, x + 7, ry + 4, labelColor, false);

                if (!module.isImplemented()) {
                    String preview = "SOON";
                    g.drawString(font, preview, x + panelW - font.width(preview) - 5,
                            ry + 4, 0xFF697487, false);
                } else {
                    int sx = x + panelW - 18;
                    int sy = ry + 4;
                    g.fill(sx, sy, sx + 12, sy + 7, module.isEnabled() ? accent : 0xFF465064);
                    int knobX = module.isEnabled() ? sx + 7 : sx + 1;
                    g.fill(knobX, sy + 1, knobX + 4, sy + 6, 0xFFF3F5FA);
                }
                if (module == binding) g.drawString(font, "...", x + panelW - 28, ry + 4, accent, true);
                else if (module.getKey() != -1) {
                    String k = keyName(module.getKey());
                    if (module.isImplemented()) g.drawString(font, trim(k, 22), x + panelW - 42, ry + 4, 0xFF8491A5, false);
                }
            }

            // Small scroll position indicator.
            if (modules.size() > visibleRows()) {
                int trackX = x + panelW - 2;
                int trackY = y + HEAD + 2;
                int trackH = visibleRows() * ROW - 4;
                int thumbH = Math.max(12, trackH * visibleRows() / modules.size());
                int travel = Math.max(1, trackH - thumbH);
                int thumbY = trackY + (int) Math.round(travel * (scrollOffsets[i] / (double) maxScroll));
                g.fill(trackX, trackY, trackX + 1, trackY + trackH, 0x66535D70);
                g.fill(trackX, thumbY, trackX + 1, thumbY + thumbH, accent);
            }
        }

        if (open != null) drawSettings(g, mouseX, mouseY, accent);
        String footer = "LMB TOGGLE   RMB SETTINGS   WHEEL SCROLL   ESC CLOSE";
        g.drawString(font, footer, Math.max(8, (width - font.width(footer)) / 2), height - 13, 0xFF8792A7, false);
    }

    private void drawSettings(GuiGraphics g, int mouseX, int mouseY, int accent) {
        layoutSettings();
        g.fill(0, 0, width, height, 0x9903070D);
        g.fill(px - 2, py - 2, px + pw + 2, py + ph + 2, 0x77000000);
        g.fill(px, py, px + pw, py + ph, 0xF00D121E);
        g.fill(px, py, px + pw, py + HEAD, 0xFF1B2434);
        g.fill(px, py + HEAD - 1, px + pw, py + HEAD, accent);
        g.drawString(font, open.getName().toUpperCase(Locale.ROOT), px + 7, py + 7, 0xFFFFFFFF, true);
        g.drawString(font, "MODULE SETTINGS", px + 7 + font.width(open.getName().toUpperCase(Locale.ROOT)) + 9,
                py + 7, 0xFF8491A8, false);

        int bindY = py + HEAD + 4;
        int bindW = pw - 12;
        g.fill(px + 6, bindY, px + 6 + bindW, bindY + ROW - 2, 0x77232C3D);
        g.drawString(font, "BIND", px + 11, bindY + 4, 0xFFE1E6EF, true);
        String bindText = binding == open ? "PRESS KEY / MOUSE..." : keyName(open.getKey()).isEmpty() ? "NONE" : keyName(open.getKey());
        g.drawString(font, bindText, px + pw - font.width(bindText) - 11, bindY + 4,
                binding == open ? accent : 0xFFB5BED0, false);

        List<Setting<?>> settings = open.getSettings();
        for (int i = 0; i < settings.size(); i++) {
            Setting<?> setting = settings.get(i);
            int x = settingX(i);
            int y = settingY(i);
            int w = settingW();
            if (y + ROW > py + ph - 3) continue;
            g.fill(x, y, x + w, y + ROW - 2, 0x77232C3D);
            if (setting instanceof BoolSetting bool) {
                g.drawString(font, bool.name, x + 5, y + 4, 0xFFE1E6EF, false);
                String value = bool.get() ? "ON" : "OFF";
                g.drawString(font, value, x + w - font.width(value) - 5, y + 4,
                        bool.get() ? accent : 0xFF7C8799, true);
            } else if (setting instanceof NumberSetting number) {
                int barW = (int) Math.round(number.fraction() * (w - 2));
                g.fill(x + 1, y + ROW - 4, x + w - 1, y + ROW - 2, 0xFF30394A);
                g.fill(x + 1, y + ROW - 4, x + 1 + barW, y + ROW - 2, accent);
                g.drawString(font, number.name + ": " + number.display(), x + 5, y + 3, 0xFFE1E6EF, false);
            } else if (setting instanceof ModeSetting mode) {
                g.drawString(font, mode.name, x + 5, y + 4, 0xFFE1E6EF, false);
                String value = "< " + mode.get() + " >";
                g.drawString(font, value, x + w - font.width(value) - 5, y + 4, accent, false);
            } else {
                g.drawString(font, setting.name, x + 5, y + 4, 0xFFE1E6EF, false);
            }
        }
    }

    private void pollBindKey() {
        if (binding == null) return;
        long window = Minecraft.getInstance().getWindow().handle();
        for (int key = GLFW.GLFW_KEY_SPACE; key <= GLFW.GLFW_KEY_LAST; key++) {
            if (GLFW.glfwGetKey(window, key) == GLFW.GLFW_PRESS) {
                binding.setKey(key == GLFW.GLFW_KEY_ESCAPE ? -1 : key);
                binding = null;
                Config.save();
                return;
            }
        }
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        double mx = event.x();
        double my = event.y();
        int button = event.button();

        // While binding, the next mouse click becomes the selected module's bind.
        if (binding != null) {
            binding.setKey(-100 - button);
            binding = null;
            Config.save();
            return true;
        }

        if (open != null) {
            layoutSettings();
            if (mx < px || mx > px + pw || my < py || my > py + ph) {
                open = null;
                Config.save();
                return true;
            }
            int bindY = py + HEAD + 4;
            if (mx >= px + 6 && mx < px + pw - 6 && my >= bindY && my < bindY + ROW - 2) {
                binding = open;
                return true;
            }
            List<Setting<?>> settings = open.getSettings();
            for (int i = 0; i < settings.size(); i++) {
                int x = settingX(i), y = settingY(i), w = settingW();
                if (mx < x || mx >= x + w || my < y || my >= y + ROW) continue;
                Setting<?> setting = settings.get(i);
                if (setting instanceof BoolSetting bool) {
                    bool.toggle();
                    Config.save();
                } else if (setting instanceof NumberSetting number) {
                    dragging = number;
                    dragX0 = x;
                    dragX1 = x + w;
                    number.setFromFraction((mx - x) / (double) w);
                } else if (setting instanceof ModeSetting mode) {
                    if (button == 1) mode.prev(); else mode.next();
                    Config.save();
                }
                return true;
            }
            return true;
        }

        Category[] categories = Category.values();
        for (int i = 0; i < categories.length; i++) {
            int x = catX(i);
            int rowY = TOP + HEAD;
            List<Module> modules = modulesOf(categories[i]);
            int start = scrollOffsets[i];
            int shown = Math.min(modules.size() - start, visibleRows());
            for (int j = 0; j < shown; j++) {
                Module module = modules.get(start + j);
                if (mx >= x && mx < x + panelWidth() && my >= rowY && my < rowY + ROW) {
                    if (button == 0) {
                        module.toggle();
                        Config.save();
                    } else if (button == 1 && module.isImplemented()) {
                        open = module;
                    }
                    return true;
                }
                rowY += ROW;
            }
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        for (int i = 0; i < Category.values().length; i++) {
            int x = catX(i);
            int y = TOP;
            if (mouseX >= x && mouseX < x + panelWidth() && mouseY >= y && mouseY < y + bodyHeight()) {
                int max = Math.max(0, modulesOf(Category.values()[i]).size() - visibleRows());
                scrollOffsets[i] = Math.max(0, Math.min(max, scrollOffsets[i] + (verticalAmount < 0 ? 3 : -3)));
                return true;
            }
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dragXAmount, double dragYAmount) {
        if (dragging != null) {
            dragging.setFromFraction((event.x() - dragX0) / (double) (dragX1 - dragX0));
            return true;
        }
        return super.mouseDragged(event, dragXAmount, dragYAmount);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (dragging != null) {
            dragging = null;
            Config.save();
            return true;
        }
        return super.mouseReleased(event);
    }
}
