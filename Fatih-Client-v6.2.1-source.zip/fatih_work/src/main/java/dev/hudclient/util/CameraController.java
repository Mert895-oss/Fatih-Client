package dev.hudclient.util;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.phys.Vec3;

/**
 * Client-only detached camera shared by Freecam and Free Look.
 * The marker entity is never added to the world or sent to the server.
 */
public final class CameraController {
    private static Entity camera;
    private static boolean detached;
    private static Vec3 anchorPos;
    private static float anchorYaw;
    private static float anchorPitch;

    private CameraController() {}

    public static boolean start(boolean freecam) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return false;

        if (camera == null) {
            camera = EntityType.MARKER.create(mc.level, EntitySpawnReason.COMMAND);
            if (camera == null) return false;
            camera.setNoGravity(true);
            camera.setPos(mc.player.getX(), mc.player.getY() + mc.player.getEyeHeight(), mc.player.getZ());
            camera.setYRot(mc.player.getYRot());
            camera.setXRot(mc.player.getXRot());
        }
        if (freecam) {
            anchorPos = mc.player.position();
            anchorYaw = mc.player.getYRot();
            anchorPitch = mc.player.getXRot();
        }
        detached = freecam;
        mc.setCameraEntity(camera);
        return true;
    }

    public static void tick(double speed) {
        Minecraft mc = Minecraft.getInstance();
        if (camera == null || mc.player == null || mc.level == null) return;

        if (!detached) {
            // Free Look: follow the player position while retaining the camera's own rotation.
            camera.setPos(mc.player.getX(), mc.player.getY() + mc.player.getEyeHeight(), mc.player.getZ());
            return;
        }

        // Freecam: WASD moves relative to the detached camera's yaw. Jump/sneak move vertically.
        double multiplier = mc.options.keySprint.isDown() ? 2.0 : 1.0;
        double step = Math.max(0.05, speed) * multiplier;
        float yaw = camera.getYRot();
        Vec3 forward = Vec3.directionFromRotation(0.0F, yaw);
        Vec3 right = Vec3.directionFromRotation(0.0F, yaw + 90.0F);
        double dx = 0.0, dy = 0.0, dz = 0.0;

        if (mc.options.keyUp.isDown()) {
            dx += forward.x * step;
            dz += forward.z * step;
        }
        if (mc.options.keyDown.isDown()) {
            dx -= forward.x * step;
            dz -= forward.z * step;
        }
        if (mc.options.keyRight.isDown()) {
            dx += right.x * step;
            dz += right.z * step;
        }
        if (mc.options.keyLeft.isDown()) {
            dx -= right.x * step;
            dz -= right.z * step;
        }
        if (mc.options.keyJump.isDown()) dy += step;
        if (mc.options.keyShift.isDown()) dy -= step;

        double horizontal = Math.sqrt(dx * dx + dz * dz);
        if (horizontal > step) {
            dx = dx / horizontal * step;
            dz = dz / horizontal * step;
        }
        camera.setPos(camera.getX() + dx, camera.getY() + dy, camera.getZ() + dz);
    }

    public static void stop() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && mc.getCameraEntity() == camera) mc.setCameraEntity(mc.player);
        if (mc.player != null && anchorPos != null) {
            mc.player.setPos(anchorPos.x, anchorPos.y, anchorPos.z);
            mc.player.setDeltaMovement(Vec3.ZERO);
            mc.player.setYRot(anchorYaw);
            mc.player.setXRot(anchorPitch);
        }
        camera = null;
        detached = false;
        anchorPos = null;
    }

    /** Re-centres the real local player before movement packets are considered. */
    public static void freezePlayer(net.minecraft.client.player.LocalPlayer player) {
        if (!isFreecam() || anchorPos == null || player == null) return;
        player.setPos(anchorPos.x, anchorPos.y, anchorPos.z);
        player.setDeltaMovement(Vec3.ZERO);
        player.setYRot(anchorYaw);
        player.setXRot(anchorPitch);
    }

    public static boolean isActive() {
        return camera != null;
    }

    public static boolean isFreecam() {
        return camera != null && detached;
    }
}
