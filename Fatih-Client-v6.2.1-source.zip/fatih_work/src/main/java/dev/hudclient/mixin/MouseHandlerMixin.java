package dev.hudclient.mixin;

import dev.hudclient.util.CameraController;
import net.minecraft.client.Minecraft;
import net.minecraft.client.MouseHandler;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/** Routes mouse-look to the detached client camera while Freecam / Free Look is active. */
@Mixin(MouseHandler.class)
public abstract class MouseHandlerMixin {
    @Redirect(
            method = "turnPlayer(D)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/player/LocalPlayer;turn(DD)V"
            )
    )
    private void fatih$redirectCameraLook(LocalPlayer player, double yaw, double pitch) {
        if (CameraController.isActive()) {
            Entity camera = Minecraft.getInstance().getCameraEntity();
            if (camera != null && camera != player) {
                camera.turn(yaw, pitch);
                return;
            }
        }
        player.turn(yaw, pitch);
    }
}
