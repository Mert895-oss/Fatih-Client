package dev.hudclient.mixin;

import dev.hudclient.module.ModuleManager;
import dev.hudclient.module.render.SwingSpeed;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {
    @Inject(method = "getCurrentSwingDuration()I", at = @At("HEAD"), cancellable = true)
    private void fatih$changeLocalSwingDuration(CallbackInfoReturnable<Integer> cir) {
        if (!((Object) this instanceof LocalPlayer)) return;
        SwingSpeed module = ModuleManager.get(SwingSpeed.class);
        if (module != null && module.isEnabled()) cir.setReturnValue(module.getSwingTicks());
    }
}
