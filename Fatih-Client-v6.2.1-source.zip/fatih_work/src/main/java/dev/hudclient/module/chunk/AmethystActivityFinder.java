package dev.hudclient.module.chunk;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;

/**
 * Marks already-loaded client chunks containing unusually mature amethyst geodes.
 *
 * This is a heuristic, not proof of an AFK player or a base. Natural geodes can
 * look mature, and a player can be AFK without keeping a chunk loaded. It only
 * reads block states that the client has already received; it does not inspect
 * hidden server data or bypass anti-xray.
 */
public final class AmethystActivityFinder extends ChunkFinder {
    private final dev.hudclient.setting.NumberSetting minClusters =
            num("Minimum Clusters", 5, 1, 32, 1);
    private final dev.hudclient.setting.NumberSetting maturityPercent =
            num("Maturity Percent", 65, 25, 100, 5);
    private final dev.hudclient.setting.BoolSetting detectSparseClusters =
            bool("Detect Mostly-Grown Geodes", true);
    private final dev.hudclient.setting.BoolSetting detectHarvested =
            bool("Detect Bud-Heavy Geodes", true);
    private final dev.hudclient.setting.NumberSetting minYoungBuds =
            num("Minimum Young Buds", 8, 2, 64, 1);

    public AmethystActivityFinder() {
        super("Sus Chunk Finder", 90, 255, 130);
        setDescription("Heuristically marks loaded chunks with mature or bud-heavy amethyst geodes. It cannot confirm an AFK player or a base.");
    }

    @Override
    protected boolean matches(LevelChunk chunk, int cx, int cz) {
        int clusters = 0;
        int buds = 0;
        int buddingBlocks = 0;

        for (LevelChunkSection section : chunk.getSections()) {
            if (section.hasOnlyAir()) continue;
            if (!section.maybeHas(state ->
                    state.is(Blocks.AMETHYST_CLUSTER)
                    || state.is(Blocks.SMALL_AMETHYST_BUD)
                    || state.is(Blocks.MEDIUM_AMETHYST_BUD)
                    || state.is(Blocks.LARGE_AMETHYST_BUD)
                    || state.is(Blocks.BUDDING_AMETHYST))) continue;

            for (int y = 0; y < 16; y++) {
                for (int z = 0; z < 16; z++) {
                    for (int x = 0; x < 16; x++) {
                        var state = section.getBlockState(x, y, z);
                        if (state.is(Blocks.AMETHYST_CLUSTER)) clusters++;
                        else if (state.is(Blocks.SMALL_AMETHYST_BUD)
                                || state.is(Blocks.MEDIUM_AMETHYST_BUD)
                                || state.is(Blocks.LARGE_AMETHYST_BUD)) buds++;
                        else if (state.is(Blocks.BUDDING_AMETHYST)) buddingBlocks++;
                    }
                }
            }
        }

        int totalGrowth = clusters + buds;
        if (totalGrowth == 0 || buddingBlocks == 0) return false;
        int maturity = (int) Math.round(clusters * 100.0 / totalGrowth);
        boolean mostlyGrown = detectSparseClusters.get()
                && clusters >= minClusters.getInt()
                && maturity >= maturityPercent.getInt();
        boolean budHeavy = detectHarvested.get()
                && buds >= minYoungBuds.getInt()
                && clusters <= Math.max(1, minClusters.getInt() / 4);
        return mostlyGrown || budHeavy;
    }
}
