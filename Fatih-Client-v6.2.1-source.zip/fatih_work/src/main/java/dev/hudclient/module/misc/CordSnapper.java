package dev.hudclient.module.misc;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import net.minecraft.client.gui.GuiGraphics;

/** Saves the current coordinates when its bind is pressed and displays the waypoint. */
public final class CordSnapper extends Module {
    private double x, y, z;
    private boolean saved;

    public CordSnapper() {
        super("Cord Snapper", Category.MISC);
        setDescription("Press the bind to save your current coordinates; the waypoint remains on the HUD.");
    }

    @Override public boolean handlesBindPress() { return true; }

    @Override public void onBoundKeyPressed() {
        if (mc.player == null || mc.level == null) return;
        x = mc.player.getX(); y = mc.player.getY(); z = mc.player.getZ(); saved = true;
    }

    @Override public void onRenderHud(GuiGraphics g) {
        if (!saved || mc.player == null) return;
        double dx=x-mc.player.getX(), dy=y-mc.player.getY(), dz=z-mc.player.getZ();
        double distance=Math.sqrt(dx*dx+dy*dy+dz*dz);
        String text=String.format(java.util.Locale.ROOT,"WAYPOINT  %.0f %.0f %.0f  |  %.1fm",x,y,z,distance);
        g.fill(8, 52, 8+mc.font.width(text)+10, 66, 0xB90B101B);
        g.drawString(mc.font,text,13,55,0xFFE6D5FF,true);
    }
}
