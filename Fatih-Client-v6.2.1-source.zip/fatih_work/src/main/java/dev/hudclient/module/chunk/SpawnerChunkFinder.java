package dev.hudclient.module.chunk;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;

/** Marks chunks that contain a monster spawner. */
public class SpawnerChunkFinder extends ChunkFinder {
    public SpawnerChunkFinder() {
        super("Spawner Finder", 170, 70, 255);
    }

    @Override
    protected boolean matches(LevelChunk chunk, int cx, int cz) {
        for (LevelChunkSection section : chunk.getSections()) {
            if (section.hasOnlyAir()) {
                continue;
            }
            if (section.maybeHas(s -> s.is(Blocks.SPAWNER))) {
                return true;
            }
        }
        return false;
    }
}
