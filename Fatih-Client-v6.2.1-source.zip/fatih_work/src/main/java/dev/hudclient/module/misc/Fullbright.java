package dev.hudclient.module.misc;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import net.minecraft.client.Minecraft;

/** Sets the vanilla brightness option to its maximum while enabled, then restores it. */
public final class Fullbright extends Module {
    private double previousGamma = 1.0;
    private boolean captured;

    public Fullbright() {
        super("Fullbright", Category.RENDER);
        setDescription("Raises the vanilla brightness slider to maximum and restores the previous value when disabled.");
    }

    @Override
    public void onEnable() {
        if (mc.options != null) {
            previousGamma = mc.options.gamma().get();
            captured = true;
            mc.options.gamma().set(1.0);
        }
    }

    @Override
    public void onTick() {
        if (mc.options != null) mc.options.gamma().set(1.0);
    }

    @Override
    public void onDisable() {
        if (captured && mc.options != null) mc.options.gamma().set(previousGamma);
        captured = false;
    }
}
