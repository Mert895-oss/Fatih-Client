package dev.hudclient.module.misc;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.Item;

/** Base for opt-in item hotkeys. It uses items already in the hotbar. */
public abstract class KeyItemUse extends Module {
    private final Item item;

    protected KeyItemUse(String name, Item item) {
        super(name, Category.MISC);
        this.item = item;
        setDescription("When enabled, the assigned bind selects and uses this item from the hotbar.");
    }

    @Override
    public final boolean handlesBindPress() {
        return true;
    }

    @Override
    public final void onBoundKeyPressed() {
        LocalPlayer player = mc.player;
        if (!isEnabled() || player == null || mc.gameMode == null || mc.screen != null) return;
        for (int slot = 0; slot < 9; slot++) {
            if (player.getInventory().getItem(slot).is(item)) {
                player.getInventory().setSelectedSlot(slot);
                mc.gameMode.useItem(player, InteractionHand.MAIN_HAND);
                return;
            }
        }
    }
}
