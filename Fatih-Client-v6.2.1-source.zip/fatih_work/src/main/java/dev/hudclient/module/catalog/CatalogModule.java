package dev.hudclient.module.catalog;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;

/**
 * A clearly-labelled catalogue entry for a feature that is not implemented yet.
 * It is visible in ClickGUI but cannot be enabled, so the client never pretends
 * that a non-working feature is active.
 */
public final class CatalogModule extends Module {
    public CatalogModule(String name, Category category, String description) {
        super(name, category);
        setDescription(description);
        setImplemented(false);
    }
}
