package dev.hudclient.module.render;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.setting.ColorSetting;
import dev.hudclient.setting.NumberSetting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.EntityHitResult;

import java.util.Locale;

/** Compact target information card for the entity currently under the crosshair. */
public final class TargetHud extends Module {
    private final ColorSetting color = color("Accent", 179, 92, 255);
    private final NumberSetting width = num("Width", 150, 110, 220, 5);

    public TargetHud() {
        super("Target HUD", Category.RENDER);
        setDescription("Displays the name, distance and health of a living entity under the crosshair.");
    }

    @Override
    public void onRenderHud(GuiGraphics g) {
        if (!(mc.hitResult instanceof EntityHitResult hit) || !(hit.getEntity() instanceof LivingEntity target)
                || mc.player == null || !target.isAlive()) return;

        int w = width.getInt();
        int h = 42;
        int x = (mc.getWindow().getGuiScaledWidth() - w) / 2;
        int y = mc.getWindow().getGuiScaledHeight() - 56;
        int accent = 0xFF000000 | color.rgb();

        g.fill(x, y, x + w, y + h, 0xD9090D17);
        g.fill(x, y, x + w, y + 2, accent);
        String name = target.getName().getString();
        int nameMax = w - 12;
        while (!name.isEmpty() && mc.font.width(name) > nameMax) name = name.substring(0, name.length() - 1);
        g.drawString(mc.font, name, x + 6, y + 7, 0xFFF0F2F8, true);
        double distance = Math.sqrt(mc.player.distanceToSqr(target));
        String stats = String.format(Locale.ROOT, "%.1f HP   %.1f m", target.getHealth(), distance);
        g.drawString(mc.font, stats, x + 6, y + 21, 0xFFB5BED0, false);

        int barX = x + 6;
        int barY = y + 34;
        int barW = w - 12;
        g.fill(barX, barY, barX + barW, barY + 4, 0xFF343A49);
        float ratio = target.getMaxHealth() <= 0 ? 0 : Math.max(0, Math.min(1, target.getHealth() / target.getMaxHealth()));
        g.fill(barX, barY, barX + Math.round(barW * ratio), barY + 4, ratio > 0.5f ? 0xFF55D68A : 0xFFFF9A55);
    }
}
