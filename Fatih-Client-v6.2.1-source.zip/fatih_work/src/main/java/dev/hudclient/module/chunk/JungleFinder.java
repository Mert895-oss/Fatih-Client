package dev.hudclient.module.chunk;

import net.minecraft.core.BlockPos;
import net.minecraft.tags.BiomeTags;
import net.minecraft.world.level.chunk.LevelChunk;

/** Marks already-loaded chunks with a jungle biome at surface height. */
public final class JungleFinder extends ChunkFinder {
    public JungleFinder(){super("Jungle Finder",55,190,95);setDescription("Marks loaded chunks where the surface biome is tagged as jungle; it does not load distant chunks.");}
    @Override protected boolean matches(LevelChunk chunk,int cx,int cz){
        if(mc.level==null)return false;
        int baseX=cx<<4,baseZ=cz<<4;
        for(int x=0;x<16;x+=3)for(int z=0;z<16;z+=3){
            int wx=baseX+x,wz=baseZ+z;
            int y=mc.level.getHeight(net.minecraft.world.level.levelgen.Heightmap.Types.WORLD_SURFACE,wx,wz);
            if(y<=mc.level.getMinY())continue;
            if(mc.level.getBiome(new BlockPos(wx,y-1,wz)).is(BiomeTags.IS_JUNGLE))return true;
        }
        return false;
    }
}
