package dev.hudclient.module.render;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.setting.NumberSetting;

/** Changes only the local first-person hand swing animation duration. */
public final class SwingSpeed extends Module {
    private final NumberSetting swingTicks = num("Swing Ticks", 2, 1, 6, 1);

    public SwingSpeed() {
        super("SwingSpeed", Category.RENDER);
        setDescription("Changes the local hand swing animation length only; it does not change attack cooldown or server hit rate.");
    }

    public int getSwingTicks() {
        return swingTicks.getInt();
    }
}
