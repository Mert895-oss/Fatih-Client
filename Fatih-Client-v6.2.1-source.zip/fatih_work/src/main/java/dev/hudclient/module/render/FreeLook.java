package dev.hudclient.module.render;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.module.ModuleManager;
import dev.hudclient.util.CameraController;

/** Hold-to-look module: view rotation is separated from the player's body rotation. */
public final class FreeLook extends Module {
    public FreeLook() {
        super("Free Look", Category.RENDER);
        setDescription("Hold the assigned bind to look around without turning the player's body. Also supports GUI toggle.");
    }

    @Override
    public boolean handlesHoldBind() {
        return true;
    }

    @Override
    public void onBoundKeyState(boolean down) {
        if (down) {
            Freecam freecam = ModuleManager.get(Freecam.class);
            if (freecam != null && freecam.isEnabled()) return;
            if (mc.player != null && mc.level != null) CameraController.start(false);
        } else if (!isEnabled()) {
            CameraController.stop();
        }
    }

    @Override
    public void onEnable() {
        Freecam freecam = ModuleManager.get(Freecam.class);
        if (freecam != null && freecam.isEnabled()) freecam.setEnabled(false);
        if (!CameraController.start(false)) setEnabled(false);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.level == null) setEnabled(false);
    }

    @Override
    public void onDisable() {
        CameraController.stop();
    }
}
