package dev.hudclient.module.misc;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.setting.NumberSetting;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;

/** Repeats the user's held left-click against the current crosshair target. */
public final class AutoClicker extends Module {
    private final NumberSetting cps=num("Clicks Per Second",8,1,20,1);
    private int cooldown;
    public AutoClicker(){super("Auto Clicker",Category.MISC);setDescription("Repeats attacks only while the physical attack key is held; respects server/game hit rules.");}
    @Override public void onTick(){
        if(mc.player==null||mc.level==null||mc.gameMode==null||mc.screen!=null)return;
        if(!mc.options.keyAttack.isDown()){cooldown=0;return;}
        if(cooldown>0){cooldown--;return;}
        cooldown=Math.max(1,20/cps.getInt());
        if(mc.hitResult instanceof EntityHitResult hit)mc.gameMode.attack(mc.player,hit.getEntity());
        else if(mc.hitResult instanceof BlockHitResult hit){
            if(mc.gameMode.isDestroying())mc.gameMode.continueDestroyBlock(hit.getBlockPos(),hit.getDirection());
            else mc.gameMode.startDestroyBlock(hit.getBlockPos(),hit.getDirection());
        }
    }
}
