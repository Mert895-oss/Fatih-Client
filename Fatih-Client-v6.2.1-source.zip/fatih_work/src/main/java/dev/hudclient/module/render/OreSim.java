package dev.hudclient.module.render;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.render.Render3D;
import dev.hudclient.setting.NumberSetting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.chunk.status.ChunkStatus;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/** Marks air-exposed ore blocks in the loaded area, not ore hidden behind stone. */
public final class OreSim extends Module {
    private final NumberSetting radius=num("Radius",12,4,24,1);
    private final List<AABB> ores=new ArrayList<>();
    private int timer;
    private static final Block[] ORES={Blocks.COAL_ORE,Blocks.DEEPSLATE_COAL_ORE,Blocks.IRON_ORE,Blocks.DEEPSLATE_IRON_ORE,Blocks.GOLD_ORE,Blocks.DEEPSLATE_GOLD_ORE,Blocks.COPPER_ORE,Blocks.DEEPSLATE_COPPER_ORE,Blocks.LAPIS_ORE,Blocks.DEEPSLATE_LAPIS_ORE,Blocks.REDSTONE_ORE,Blocks.DEEPSLATE_REDSTONE_ORE,Blocks.DIAMOND_ORE,Blocks.DEEPSLATE_DIAMOND_ORE,Blocks.EMERALD_ORE,Blocks.DEEPSLATE_EMERALD_ORE,Blocks.NETHER_QUARTZ_ORE,Blocks.NETHER_GOLD_ORE,Blocks.ANCIENT_DEBRIS};
    public OreSim(){super("Ore Sim",Category.RENDER);setDescription("Highlights ores only when directly exposed to air in client-loaded chunks.");}
    @Override public void onTick(){if(timer-->0)return;timer=12;ores.clear();if(mc.level==null||mc.player==null)return;
        int r=radius.getInt(),px=mc.player.getBlockX(),py=mc.player.getBlockY(),pz=mc.player.getBlockZ();
        for(int x=px-r;x<=px+r;x++)for(int y=Math.max(mc.level.getMinY(),py-r);y<=Math.min(mc.level.getMaxY(),py+r);y++)for(int z=pz-r;z<=pz+r;z++){
            if(mc.level.getChunk(x>>4,z>>4,ChunkStatus.FULL,false)==null)continue;
            BlockPos p=new BlockPos(x,y,z);var state=mc.level.getBlockState(p);boolean ore=false;for(Block b:ORES)if(state.is(b)){ore=true;break;}if(!ore)continue;
            for(Direction d:Direction.values())if(mc.level.getBlockState(p.relative(d)).isAir()){if(hasLineOfSight(p))ores.add(new AABB(p));break;}
        }
    }
    private boolean hasLineOfSight(BlockPos pos) {
        Vec3 eye = mc.player.getEyePosition();
        Vec3 target = Vec3.atCenterOf(pos);
        var hit = mc.level.clip(new ClipContext(eye, target, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, mc.player));
        return hit.getType() == HitResult.Type.BLOCK && pos.equals(hit.getBlockPos());
    }

    @Override public void onRender3D(){for(AABB b:ores){Render3D.box(b,0x553CB5FF);Render3D.outline(b,0.025,0xFF50C2FF);}}
    @Override public void onDisable(){ores.clear();}
}
