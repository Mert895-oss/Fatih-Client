package dev.hudclient.module.render;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.render.Render3D;
import dev.hudclient.setting.NumberSetting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.chunk.status.ChunkStatus;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/** Finds only air-exposed ancient debris in currently loaded chunks. */
public final class NetheriteFinder extends Module {
    private final NumberSetting radius=num("Radius",16,4,32,2);
    private final List<AABB> found=new ArrayList<>();
    private int timer;
    public NetheriteFinder(){super("Netherite Finder",Category.DONUT);setDescription("Marks only air-exposed ancient debris in already-loaded chunks; no x-ray or anti-xray bypass.");}
    @Override public void onTick(){
        if(timer-->0)return; timer=10; found.clear();
        if(mc.level==null||mc.player==null)return;
        int r=radius.getInt(), px=mc.player.getBlockX(),py=mc.player.getBlockY(),pz=mc.player.getBlockZ();
        for(int x=px-r;x<=px+r;x++)for(int y=Math.max(mc.level.getMinY(),py-r);y<=Math.min(mc.level.getMaxY(),py+r);y++)for(int z=pz-r;z<=pz+r;z++){
            if(mc.level.getChunk(x>>4,z>>4,ChunkStatus.FULL,false)==null)continue;
            BlockPos p=new BlockPos(x,y,z);
            if(!mc.level.getBlockState(p).is(Blocks.ANCIENT_DEBRIS))continue;
            boolean exposed=false;
            for(Direction d:Direction.values())if(mc.level.getBlockState(p.relative(d)).isAir()){exposed=true;break;}
            if(exposed && hasLineOfSight(p))found.add(new AABB(p));
        }
    }
    private boolean hasLineOfSight(BlockPos pos) {
        Vec3 eye = mc.player.getEyePosition();
        Vec3 target = Vec3.atCenterOf(pos);
        var hit = mc.level.clip(new ClipContext(eye, target, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, mc.player));
        return hit.getType() == HitResult.Type.BLOCK && pos.equals(hit.getBlockPos());
    }

    @Override public void onRender3D(){for(AABB b:found){Render3D.box(b,0x6647D7FF);Render3D.outline(b,0.035,0xFF47D7FF);}}
    @Override public void onDisable(){found.clear();}
}
