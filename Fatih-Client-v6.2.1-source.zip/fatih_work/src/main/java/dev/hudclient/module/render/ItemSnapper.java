package dev.hudclient.module.render;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.render.Render3D;
import dev.hudclient.setting.NumberSetting;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.phys.AABB;

/** Highlights dropped item entities already tracked by the client. */
public final class ItemSnapper extends Module {
    private final NumberSetting range=num("Range",32,4,96,2);
    public ItemSnapper(){ super("Item Snapper", Category.DONUT); setDescription("Highlights nearby dropped item entities that the client has already received."); }
    @Override public void onRender3D(){
        if(mc.level==null||mc.player==null)return;
        double r=range.getD();
        for(ItemEntity item:mc.level.getEntitiesOfClass(ItemEntity.class,mc.player.getBoundingBox().inflate(r))){
            if(item.isRemoved()||item.getItem().isEmpty())continue;
            AABB b=item.getBoundingBox().inflate(0.08);
            Render3D.box(b,0x553BE8FF); Render3D.outline(b,0.025,0xFF3BE8FF);
        }
    }
}
