package dev.hudclient.module.render;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.render.Render3D;
import dev.hudclient.setting.ColorSetting;
import dev.hudclient.setting.NumberSetting;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Expanding ring drawn at the player's landing point after a jump. */
public final class JumpCircles extends Module {
    private record Ring(double x, double y, double z, int age) {
        Ring next() { return new Ring(x, y, z, age + 1); }
    }

    private final ColorSetting color = color("Color", 179, 92, 255);
    private final NumberSetting lifetime = num("Lifetime", 24, 8, 60, 1);
    private final NumberSetting maxRadius = num("Max Radius", 1.8, 0.5, 4.0, 0.1);
    private final NumberSetting lineWidth = num("Line Width", 0.035, 0.01, 0.12, 0.005);
    private final List<Ring> rings = new ArrayList<>();
    private boolean wasGrounded;

    public JumpCircles() {
        super("Jump Circles", Category.RENDER);
        setDescription("Draws a short expanding ring where the player lands after a jump.");
    }

    @Override
    public void onEnable() {
        rings.clear();
        wasGrounded = mc.player != null && mc.player.onGround();
    }

    @Override
    public void onDisable() {
        rings.clear();
    }

    @Override
    public void onTick() {
        LocalPlayer player = mc.player;
        if (player == null) {
            rings.clear();
            return;
        }
        boolean grounded = player.onGround();
        if (grounded && !wasGrounded) {
            rings.add(new Ring(player.getX(), player.getY() + 0.035, player.getZ(), 0));
            if (rings.size() > 12) rings.remove(0);
        }
        wasGrounded = grounded;

        for (int i = 0; i < rings.size(); i++) rings.set(i, rings.get(i).next());
        rings.removeIf(r -> r.age() >= lifetime.getInt());
    }

    @Override
    public void onRender3D() {
        if (rings.isEmpty()) return;
        int rgb = color.rgb();
        int duration = lifetime.getInt();
        for (Ring ring : rings) {
            double t = Math.min(1.0, ring.age() / (double) Math.max(1, duration));
            double radius = 0.25 + maxRadius.getD() * t;
            int alpha = (int) Math.round(220 * (1.0 - t));
            int argb = (alpha << 24) | rgb;
            Vec3 previous = null;
            for (int i = 0; i <= 40; i++) {
                double angle = (Math.PI * 2.0 * i) / 40.0;
                Vec3 current = new Vec3(ring.x() + Math.cos(angle) * radius, ring.y(), ring.z() + Math.sin(angle) * radius);
                if (previous != null) Render3D.line(previous, current, lineWidth.getD(), argb);
                previous = current;
            }
        }
    }
}
