package dev.hudclient.module.misc;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;

/** Detects a tight block enclosure around the local player and shows a warning. */
public final class AntiTrap extends Module {
    private boolean trapped;
    private int checked;
    public AntiTrap() {
        super("Anti Trap", Category.DONUT);
        setDescription("Warns when solid blocks enclose the player on most sides; detection only, no server automation.");
    }
    @Override public void onTick() {
        if (mc.player == null || mc.level == null || checked++ % 5 != 0) return;
        BlockPos feet = mc.player.blockPosition();
        int blocked=0;
        for (Direction d : Direction.Plane.HORIZONTAL) {
            BlockPos p=feet.relative(d);
            if (!mc.level.getBlockState(p).getCollisionShape(mc.level,p).isEmpty()
                    && !mc.level.getBlockState(p.above()).getCollisionShape(mc.level,p.above()).isEmpty()) blocked++;
        }
        boolean roof=!mc.level.getBlockState(feet.above(2)).getCollisionShape(mc.level,feet.above(2)).isEmpty();
        trapped=blocked>=3 && roof;
    }
    @Override public void onRenderHud(GuiGraphics g) {
        if (!trapped) return;
        String t="TRAP WARNING";
        int x=(mc.getWindow().getGuiScaledWidth()-mc.font.width(t)-18)/2;
        g.fill(x,8,x+mc.font.width(t)+18,25,0xD9B02030);
        g.drawString(mc.font,t,x+9,13,0xFFFFFFFF,true);
    }
}
