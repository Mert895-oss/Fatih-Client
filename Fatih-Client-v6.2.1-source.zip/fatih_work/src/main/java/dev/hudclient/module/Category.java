package dev.hudclient.module;

public enum Category {
    COMBAT("Combat"),
    MISC("Misc"),
    DONUT("Donut"),
    BASEFINDING("Basefinding"),
    RENDER("Render");

    public final String label;

    Category(String label) {
        this.label = label;
    }
}
