package dev.hudclient.module.misc;

import net.minecraft.world.item.Items;

public final class KeyPearl extends KeyItemUse {
    public KeyPearl() { super("Key Pearl", Items.ENDER_PEARL); }
}
