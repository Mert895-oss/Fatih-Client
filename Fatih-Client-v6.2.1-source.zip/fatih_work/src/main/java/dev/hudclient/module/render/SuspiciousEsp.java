package dev.hudclient.module.render;

/** Highlights visible storage blocks and block entities with the Storage ESP renderer. */
public final class SuspiciousEsp extends StorageEsp {
    public SuspiciousEsp(){super("Suspicious ESP");}
}
