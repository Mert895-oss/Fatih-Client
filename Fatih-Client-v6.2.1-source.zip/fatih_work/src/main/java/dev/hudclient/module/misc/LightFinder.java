package dev.hudclient.module.misc;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.render.Render3D;
import dev.hudclient.setting.NumberSetting;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.AABB;

import java.util.ArrayList;
import java.util.List;

/** Highlights blocks which visibly emit light in the client-loaded area. */
public final class LightFinder extends Module {
    private final NumberSetting radius = num("Radius", 12, 4, 24, 1);
    private final NumberSetting verticalRange = num("Vertical Range", 6, 2, 16, 1);
    private final List<AABB> sources = new ArrayList<>();
    private int cooldown;

    public LightFinder() {
        super("Light Finder", Category.BASEFINDING);
        setDescription("Highlights visible light-emitting blocks in the loaded client area; does not infer hidden blocks or light packets.");
    }

    @Override
    public void onTick() {
        if (cooldown-- > 0) return;
        cooldown = 15;
        sources.clear();
        if (mc.level == null || mc.player == null) return;

        int r = radius.getInt();
        int vr = verticalRange.getInt();
        int px = mc.player.getBlockX();
        int py = mc.player.getBlockY();
        int pz = mc.player.getBlockZ();
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();

        for (int x = px - r; x <= px + r; x++) {
            for (int z = pz - r; z <= pz + r; z++) {
                for (int y = py - vr; y <= py + vr; y++) {
                    pos.set(x, y, z);
                    var state = mc.level.getBlockState(pos);
                    if (state.getLightEmission() > 0) {
                        sources.add(new AABB(x, y, z, x + 1, y + 1, z + 1));
                    }
                }
            }
        }
    }

    @Override
    public void onRender3D() {
        for (AABB box : sources) {
            Render3D.box(box, 0x445BCBFF);
            Render3D.outline(box, 0.025, 0xFF79D7FF);
        }
    }

    @Override
    public void onDisable() { sources.clear(); }
}
