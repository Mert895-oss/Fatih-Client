package dev.hudclient.module.render;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.render.Render3D;
import dev.hudclient.setting.BoolSetting;
import dev.hudclient.setting.NumberSetting;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;

/** Highlights the block currently targeted by the player's crosshair. */
public final class BlockEsp extends Module {
    private final BoolSetting fill = bool("Fill", false);
    private final NumberSetting alpha = num("Fill Alpha", 55, 0, 180, 5);
    private final NumberSetting lineWidth = num("Line Width", 0.035, 0.01, 0.12, 0.005);

    public BlockEsp() {
        super("Block ESP", Category.RENDER);
        setDescription("Outlines only the block currently targeted by the crosshair.");
    }

    @Override
    public void onRender3D() {
        if (mc.level == null || !(mc.hitResult instanceof BlockHitResult hit)) return;
        BlockPos pos = hit.getBlockPos();
        var shape = mc.level.getBlockState(pos).getShape(mc.level, pos);
        AABB box = shape.isEmpty() ? new AABB(pos) : shape.bounds().move(pos);
        if (fill.get()) Render3D.box(box, (alpha.getInt() << 24) | 0x8B65FF);
        Render3D.outline(box, lineWidth.getD(), 0xFFB58BFF);
    }
}
