package dev.hudclient.module.misc;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.render.Render3D;
import dev.hudclient.setting.NumberSetting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.phys.AABB;

import java.util.ArrayList;
import java.util.List;

/** Marks simple 1x1 holes using only block states already visible to the client. */
public final class HoleEsp extends Module {
    private final NumberSetting radius = num("Radius", 8, 2, 16, 1);
    private final NumberSetting vertical = num("Vertical Range", 2, 1, 6, 1);
    private final List<AABB> holes = new ArrayList<>();
    private int refresh;

    public HoleEsp() {
        super("Hole ESP", Category.BASEFINDING);
        setDescription("Highlights simple 1x1 holes in loaded client chunks; does not inspect hidden server data.");
    }

    @Override
    public void onTick() {
        if (refresh-- > 0) return;
        refresh = 12;
        holes.clear();
        if (mc.level == null || mc.player == null) return;
        int r = radius.getInt();
        int baseY = mc.player.blockPosition().getY();
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (int x = mc.player.getBlockX() - r; x <= mc.player.getBlockX() + r; x++) {
            for (int z = mc.player.getBlockZ() - r; z <= mc.player.getBlockZ() + r; z++) {
                for (int y = baseY - vertical.getInt(); y <= baseY + vertical.getInt(); y++) {
                    pos.set(x, y, z);
                    if (!mc.level.getBlockState(pos).isAir()) continue;
                    if (!solid(pos.below())) continue;
                    boolean enclosed = true;
                    for (Direction dir : Direction.Plane.HORIZONTAL) {
                        if (!solid(pos.relative(dir))) { enclosed = false; break; }
                    }
                    if (enclosed) holes.add(new AABB(x, y, z, x + 1, y + 1, z + 1));
                }
            }
        }
    }

    private boolean solid(BlockPos pos) {
        var state = mc.level.getBlockState(pos);
        return !state.isAir() && !state.getCollisionShape(mc.level, pos).isEmpty();
    }

    @Override
    public void onRender3D() {
        for (AABB box : holes) {
            Render3D.box(box, 0x385D9BFF);
            Render3D.outline(box, 0.025, 0xFF78B8FF);
        }
    }

    @Override
    public void onDisable() { holes.clear(); }
}
