package dev.hudclient.module.misc;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import net.minecraft.client.gui.screens.inventory.ContainerScreen;
import net.minecraft.client.gui.screens.inventory.ShulkerBoxScreen;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;

/** Quick-moves loot from an opened chest-like container into the player's inventory. */
public final class AutoLoot extends Module {
    private int delay;

    public AutoLoot() {
        super("Auto Loot", Category.MISC);
        setDescription("Shift-clicks one non-empty chest or shulker slot at a time into your inventory. It does not open containers itself.");
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.gameMode == null) return;
        if (!(mc.screen instanceof ContainerScreen) && !(mc.screen instanceof ShulkerBoxScreen)) return;
        if (delay-- > 0) return;
        delay = 3;

        AbstractContainerMenu menu = mc.player.containerMenu;
        // Chest and shulker menus end with the player's 36 inventory slots.
        int containerSlotCount = Math.max(0, menu.slots.size() - 36);
        for (int i = 0; i < containerSlotCount; i++) {
            Slot slot = menu.slots.get(i);
            if (slot != null && slot.hasItem() && slot.mayPickup(mc.player)) {
                mc.gameMode.handleInventoryMouseClick(menu.containerId, i, 0, ClickType.QUICK_MOVE, mc.player);
                return;
            }
        }
    }

    @Override
    public void onDisable() {
        delay = 0;
    }
}
