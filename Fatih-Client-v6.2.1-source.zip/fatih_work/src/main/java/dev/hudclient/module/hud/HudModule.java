package dev.hudclient.module.hud;

import dev.hudclient.HudClient;
import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.module.ModuleManager;
import dev.hudclient.setting.BoolSetting;
import dev.hudclient.setting.ColorSetting;
import dev.hudclient.setting.ModeSetting;
import dev.hudclient.setting.NumberSetting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FontDescription;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.scores.DisplaySlot;
import net.minecraft.world.scores.Objective;
import net.minecraft.world.scores.PlayerScoreEntry;
import org.lwjgl.glfw.GLFW;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** Compact Fatih Client HUD, designed to stay readable at desktop and phone GUI scales. */
public class HudModule extends Module {
    public final ColorSetting color = color("Accent", 178, 91, 255);
    private final ModeSetting font = mode("Font", "Default", "Default", "Uniform", "Alt", "Illager");
    private final NumberSetting uiScale = num("HUD Scale", 0.90, 0.65, 1.20, 0.05);
    private final BoolSetting watermark = bool("Watermark", true);
    private final BoolSetting metrics = bool("FPS / Ping", true);
    private final BoolSetting coords = bool("Coordinates", true);
    private final BoolSetting speed = bool("Speed", true);
    private final BoolSetting moduleList = bool("Active Modules", true);
    private final BoolSetting radar = bool("Circular Radar", true);
    private final NumberSetting radarSize = num("Radar Size", 88, 64, 132, 4);
    private final NumberSetting radarRange = num("Radar Range", 40, 10, 128, 2);
    private final BoolSetting radarMobs = bool("Radar Mobs", false);
    private final BoolSetting compass = bool("Compass", true);
    private final BoolSetting potionEffects = bool("Potion Effects", true);
    private final BoolSetting scoreboard = bool("Scoreboard", true);
    private final BoolSetting clock = bool("Clock", true);
    private final BoolSetting keystrokes = bool("WASD / Space", true);
    private final BoolSetting cps = bool("LMB / RMB / CPS", true);
    private final BoolSetting crosshair = bool("Custom Crosshair", true);

    private int frames;
    private int fpsValue;
    private long fpsStamp = System.currentTimeMillis();
    private boolean wasLeft;
    private boolean wasRight;
    private final ArrayDeque<Long> leftClicks = new ArrayDeque<>();
    private final ArrayDeque<Long> rightClicks = new ArrayDeque<>();

    private static final int PANEL = 0xD90A0D16;
    private static final int PANEL_SOFT = 0xB90A0D16;
    private static final int TEXT = 0xFFF0F1F7;
    private static final int MUTED = 0xFF9CA4B5;
    private static final int FAINT = 0x665F687B;

    public HudModule() {
        super("HUD", Category.RENDER);
        setDescription("Compact Fatih Client HUD with a circular radar, compact stats, scoreboard and input display.");
        setEnabled(true);
    }

    private int accent() {
        return 0xFF000000 | color.rgb();
    }

    private Style textStyle() {
        String f = font.get();
        String path = switch (f) {
            case "Uniform" -> "uniform";
            case "Alt" -> "alt";
            case "Illager" -> "illageralt";
            default -> null;
        };
        return path == null ? Style.EMPTY : Style.EMPTY.withFont(new FontDescription.Resource(Identifier.withDefaultNamespace(path)));
    }

    private Component styled(String value, Style style) {
        return Component.literal(value).withStyle(style);
    }

    private int currentFps() {
        frames++;
        long now = System.currentTimeMillis();
        if (now - fpsStamp >= 1000L) {
            fpsValue = frames;
            frames = 0;
            fpsStamp = now;
        }
        return fpsValue;
    }

    private int ping(LocalPlayer player) {
        try {
            var connection = mc.getConnection();
            var info = connection == null ? null : connection.getPlayerInfo(player.getUUID());
            return info == null ? -1 : info.getLatency();
        } catch (RuntimeException ignored) {
            return -1;
        }
    }

    @Override
    public void onRenderHud(GuiGraphics g) {
        LocalPlayer player = mc.player;
        if (player == null || mc.level == null) return;

        float scale = (float) uiScale.getD();
        g.pose().pushMatrix();
        g.pose().scale(scale, scale);
        int sw = (int) Math.ceil(mc.getWindow().getGuiScaledWidth() / scale);
        int sh = (int) Math.ceil(mc.getWindow().getGuiScaledHeight() / scale);
        int accent = accent();
        Style style = textStyle();

        if (watermark.get()) drawWatermark(g, style, accent, 7, 7);
        if (metrics.get()) drawMetrics(g, style, accent, player, 7, 38);
        if (coords.get()) drawCoordinates(g, style, accent, player, 7, 64);
        if (speed.get()) drawSpeed(g, style, accent, player, 7, coords.get() ? 89 : 64);
        if (compass.get()) drawCompass(g, style, accent, player, sw);
        if (moduleList.get()) drawModuleList(g, style, accent, sw);
        if (scoreboard.get()) drawScoreboard(g, style, accent, sw, sh);
        if (potionEffects.get()) drawEffects(g, style, accent, player, sh);
        if (radar.get()) drawCircularRadar(g, player, accent, sh);
        if (keystrokes.get() || cps.get()) drawInputPanel(g, accent, sw, sh);
        if (clock.get()) drawClock(g, accent, sw, sh);
        if (crosshair.get()) drawCrosshair(g, sw, sh, accent);

        g.pose().popMatrix();
    }

    private void panel(GuiGraphics g, int x, int y, int w, int h, int accent) {
        // Pixel-rounded corners keep the cards soft without a native rendering dependency.
        g.fill(x + 2, y, x + w - 2, y + h, PANEL);
        g.fill(x + 1, y + 1, x + w - 1, y + h - 1, PANEL);
        g.fill(x, y + 2, x + w, y + h - 2, PANEL);
        g.fill(x + 3, y, x + w - 3, y + 1, accent);
        g.fill(x + 3, y + h - 1, x + w - 3, y + h, 0x554B5262);
    }

    private void drawWatermark(GuiGraphics g, Style style, int accent, int x, int y) {
        panel(g, x, y, 128, 25, accent);
        g.fill(x + 5, y + 4, x + 23, y + 21, accent);
        g.drawCenteredString(mc.font, styled("K", style), x + 14, y + 8, 0xFFFFFFFF);
        g.drawString(mc.font, styled("FATIH", style), x + 29, y + 5, TEXT, false);
        g.drawString(mc.font, styled(HudClient.VERSION + "  •  FABRIC", style), x + 29, y + 15, MUTED, false);
        g.fill(x + 112, y + 8, x + 118, y + 14, 0xFF66E0A3);
    }

    private void drawMetrics(GuiGraphics g, Style style, int accent, LocalPlayer player, int x, int y) {
        int[] widths = {48, 52, 56};
        String[] labels = {"FPS", "PING", "DIM"};
        int currentPing = ping(player);
        String[] values = {
                Integer.toString(currentFps()),
                currentPing < 0 ? "--" : currentPing + "ms",
                mc.level.dimension() == Level.NETHER ? "NETHER" : mc.level.dimension() == Level.OVERWORLD ? "OVER" : "END"
        };
        int cursor = x;
        for (int i = 0; i < labels.length; i++) {
            panel(g, cursor, y, widths[i], 22, accent);
            g.drawString(mc.font, styled(labels[i], style), cursor + 5, y + 3, MUTED, false);
            g.drawString(mc.font, styled(values[i], style), cursor + 5, y + 12, TEXT, false);
            cursor += widths[i] + 4;
        }
    }

    private void drawCoordinates(GuiGraphics g, Style style, int accent, LocalPlayer p, int x, int y) {
        String xyz = String.format(Locale.ROOT, "XYZ  %.1f  /  %.1f  /  %.1f", p.getX(), p.getY(), p.getZ());
        int w = Math.max(128, mc.font.width(xyz) + 12);
        panel(g, x, y, w, 18, accent);
        g.drawString(mc.font, styled("⌖", style), x + 5, y + 5, accent, false);
        g.drawString(mc.font, styled(xyz, style), x + 17, y + 5, TEXT, false);
    }

    private void drawSpeed(GuiGraphics g, Style style, int accent, LocalPlayer p, int x, int y) {
        double dx = p.getX() - p.xo;
        double dz = p.getZ() - p.zo;
        String value = String.format(Locale.ROOT, "SPEED  %.2f blocks/s", Math.sqrt(dx * dx + dz * dz) * 20.0);
        int w = mc.font.width(value) + 12;
        panel(g, x, y, w, 18, accent);
        g.drawString(mc.font, styled(value, style), x + 6, y + 5, TEXT, false);
    }

    private void drawCompass(GuiGraphics g, Style style, int accent, LocalPlayer p, int sw) {
        int w = Math.min(142, Math.max(92, sw / 3));
        int x = Math.max(7, (sw - w) / 2);
        int y = 7;
        panel(g, x, y, w, 25, accent);
        String[] dirs = {"S", "SW", "W", "NW", "N", "NE", "E", "SE"};
        int index = Math.floorMod(Math.round(p.getYRot() / 45.0f), 8);
        String heading = dirs[index];
        g.drawCenteredString(mc.font, styled("◂", style), x + 13, y + 8, MUTED);
        g.drawCenteredString(mc.font, styled(heading, style), x + w / 2, y + 7, accent);
        g.drawCenteredString(mc.font, styled("▸", style), x + w - 13, y + 8, MUTED);
        g.fill(x + w / 2 - 17, y + 21, x + w / 2 + 17, y + 22, 0x997C8292);
        g.fill(x + w / 2 - 1, y + 19, x + w / 2 + 1, y + 23, accent);
    }

    private void drawModuleList(GuiGraphics g, Style style, int accent, int sw) {
        List<Module> active = new ArrayList<>();
        for (Module module : ModuleManager.all()) {
            if (module != this && module.isEnabled() && module.isImplemented()) active.add(module);
        }
        active.sort(Comparator.comparingInt((Module module) -> -mc.font.width(module.getName())));
        int visible = Math.min(7, active.size());
        int widest = 76;
        for (int i = 0; i < visible; i++) widest = Math.max(widest, mc.font.width(active.get(i).getName()) + 17);
        int w = Math.min(138, widest + 10);
        int h = 17 + visible * 12 + (active.size() > visible ? 11 : 0);
        int x = sw - w - 7;
        int y = sw < 400 ? 38 : 7;
        panel(g, x, y, w, h, accent);
        g.drawString(mc.font, styled("ACTIVE  " + active.size(), style), x + 6, y + 5, accent, false);
        for (int i = 0; i < visible; i++) {
            Module module = active.get(i);
            int rowY = y + 17 + i * 12;
            g.fill(x + 6, rowY + 4, x + 9, rowY + 7, accent);
            String name = trim(module.getName(), w - 22);
            g.drawString(mc.font, styled(name, style), x + 14, rowY + 1, TEXT, false);
        }
        if (active.size() > visible) {
            g.drawString(mc.font, styled("+" + (active.size() - visible) + " more", style), x + 14, y + h - 11, MUTED, false);
        }
    }

    private void drawScoreboard(GuiGraphics g, Style style, int accent, int sw, int sh) {
        try {
            var scoreboardData = mc.level.getScoreboard();
            Objective objective = scoreboardData.getDisplayObjective(DisplaySlot.SIDEBAR);
            if (objective == null) return;
            List<PlayerScoreEntry> rows = scoreboardData.listPlayerScores(objective).stream()
                    .filter(entry -> !entry.isHidden())
                    .sorted(Comparator.comparingInt(PlayerScoreEntry::value).reversed())
                    .limit(7).toList();
            int w = 138;
            int rowLimit = Math.max(0, Math.min(7, (sh - 154) / 12));
            if (rowLimit == 0) return;
            List<PlayerScoreEntry> visibleRows = rows.stream().limit(rowLimit).toList();
            int h = 19 + visibleRows.size() * 12;
            int x = sw - w - 7;
            int y = Math.max(42, sh - 91 - h - 7);
            panel(g, x, y, w, h, accent);
            String title = trim(objective.getDisplayName().getString(), w - 12);
            g.drawString(mc.font, styled(title, style), x + 6, y + 4, accent, false);
            for (int i = 0; i < visibleRows.size(); i++) {
                PlayerScoreEntry entry = visibleRows.get(i);
                int rowY = y + 17 + i * 12;
                String name = trim(entry.owner(), w - 42);
                String score = Integer.toString(entry.value());
                g.drawString(mc.font, styled(name, style), x + 6, rowY, TEXT, false);
                g.drawString(mc.font, score, x + w - mc.font.width(score) - 6, rowY, MUTED, false);
            }
        } catch (RuntimeException ignored) {
            // Some servers send incomplete scoreboard entries while updating; skip one frame.
        }
    }

    private void drawEffects(GuiGraphics g, Style style, int accent, LocalPlayer p, int sh) {
        var effects = p.getActiveEffects();
        if (effects.isEmpty()) return;
        int rows = Math.min(4, effects.size());
        int w = 122;
        int h = 18 + rows * 12;
        int x = 7;
        int radarD = radar.get() ? radarSize.getInt() : 0;
        int y = sh - radarD - h - 14;
        if (y < 112) y = 112;
        panel(g, x, y, w, h, accent);
        g.drawString(mc.font, styled("POTION EFFECTS", style), x + 6, y + 4, accent, false);
        int index = 0;
        for (var effect : effects) {
            if (index++ >= rows) break;
            int rowY = y + 17 + (index - 1) * 12;
            String name = trim(effect.getEffect().value().getDisplayName().getString(), 76);
            int ticks = effect.getDuration();
            String time = ticks < 0 ? "∞" : String.format(Locale.ROOT, "%d:%02d", (ticks / 20) / 60, (ticks / 20) % 60);
            g.drawString(mc.font, styled(name, style), x + 6, rowY, TEXT, false);
            g.drawString(mc.font, time, x + w - mc.font.width(time) - 6, rowY, MUTED, false);
        }
    }

    /** Draws a true circular radar using clipped scanlines, so it stays round on every GUI scale. */
    private void drawCircularRadar(GuiGraphics g, LocalPlayer player, int accent, int sh) {
        int diameter = radarSize.getInt();
        int radius = diameter / 2 - 2;
        int x = 7;
        int y = sh - diameter - 7;
        int cx = x + diameter / 2;
        int cy = y + diameter / 2;

        for (int dy = -radius; dy <= radius; dy++) {
            int half = (int) Math.floor(Math.sqrt(radius * radius - dy * dy));
            g.fill(cx - half, cy + dy, cx + half + 1, cy + dy + 1, PANEL_SOFT);
            int innerRadius = radius - 1;
            if (Math.abs(dy) <= innerRadius) {
                int inner = (int) Math.floor(Math.sqrt(innerRadius * innerRadius - dy * dy));
                g.fill(cx - half, cy + dy, cx - inner, cy + dy + 1, accent);
                g.fill(cx + inner + 1, cy + dy, cx + half + 1, cy + dy + 1, accent);
            }
        }

        // Cardinal cross and two range rings, each clipped to the circular boundary.
        g.fill(cx - 1, cy - radius + 3, cx + 1, cy + radius - 2, 0x447F8798);
        g.fill(cx - radius + 3, cy - 1, cx + radius - 2, cy + 1, 0x447F8798);
        drawRadarRing(g, cx, cy, radius * 2 / 3, 0x557F8798);
        drawRadarRing(g, cx, cy, radius / 3, 0x557F8798);

        double yaw = Math.toRadians(player.getYRot());
        double sin = Math.sin(yaw);
        double cos = Math.cos(yaw);
        double maxRadius = radius - 6;
        double scale = maxRadius / radarRange.getD();
        for (Entity entity : mc.level.entitiesForRendering()) {
            if (entity == player) continue;
            int dot;
            if (entity instanceof Player) dot = 0xFFFF6677;
            else if (radarMobs.get() && entity instanceof Mob) dot = entity instanceof Enemy ? 0xFFFFB45E : 0xFF67D89A;
            else continue;
            double dx = entity.getX() - player.getX();
            double dz = entity.getZ() - player.getZ();
            double forward = dx * -sin + dz * cos;
            double right = dx * -cos + dz * -sin;
            double pxOffset = right * scale;
            double pyOffset = -forward * scale;
            if (pxOffset * pxOffset + pyOffset * pyOffset > maxRadius * maxRadius) continue;
            int px = (int) Math.round(cx + pxOffset);
            int py = (int) Math.round(cy + pyOffset);
            g.fill(px - 2, py - 2, px + 3, py + 3, dot);
            g.fill(px - 1, py - 1, px + 2, py + 2, 0xDDFFFFFF);
        }
        g.fill(cx - 2, cy - 2, cx + 2, cy + 2, 0xFFFFFFFF);
        g.drawCenteredString(mc.font, "N", cx, y + 3, accent);
    }

    private void drawRadarRing(GuiGraphics g, int cx, int cy, int radius, int color) {
        if (radius < 2) return;
        for (int dy = -radius; dy <= radius; dy++) {
            int half = (int) Math.round(Math.sqrt(Math.max(0, radius * radius - dy * dy)));
            g.fill(cx - half, cy + dy, cx - half + 1, cy + dy + 1, color);
            g.fill(cx + half, cy + dy, cx + half + 1, cy + dy + 1, color);
        }
    }

    private void updateClicks() {
        long now = System.currentTimeMillis();
        boolean left = false;
        boolean right = false;
        try {
            long window = mc.getWindow().handle();
            left = GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_1) == GLFW.GLFW_PRESS;
            right = GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_2) == GLFW.GLFW_PRESS;
        } catch (Throwable ignored) {
            // Touch-only launchers may not expose GLFW mouse-button state. WASD remains usable.
        }
        if (left && !wasLeft) leftClicks.addLast(now);
        if (right && !wasRight) rightClicks.addLast(now);
        wasLeft = left;
        wasRight = right;
        while (!leftClicks.isEmpty() && now - leftClicks.peekFirst() > 1000L) leftClicks.removeFirst();
        while (!rightClicks.isEmpty() && now - rightClicks.peekFirst() > 1000L) rightClicks.removeFirst();
    }

    private void drawInputPanel(GuiGraphics g, int accent, int sw, int sh) {
        updateClicks();
        int x = sw - 91;
        int y = sh - 91;
        if (keystrokes.get()) {
            panel(g, x - 4, y - 4, 78, 68, accent);
            drawKey(g, x + 24, y, 20, 17, "W", mc.options.keyUp.isDown(), accent);
            drawKey(g, x, y + 19, 20, 17, "A", mc.options.keyLeft.isDown(), accent);
            drawKey(g, x + 24, y + 19, 20, 17, "S", mc.options.keyDown.isDown(), accent);
            drawKey(g, x + 48, y + 19, 20, 17, "D", mc.options.keyRight.isDown(), accent);
            drawKey(g, x, y + 38, 68, 14, "SPACE", mc.options.keyJump.isDown(), accent);
        }
        if (cps.get()) {
            int base = keystrokes.get() ? y + 68 : y;
            panel(g, x - 4, base, 78, 23, accent);
            drawKey(g, x, base + 3, 32, 17, "L " + leftClicks.size(), wasLeft, accent);
            drawKey(g, x + 36, base + 3, 32, 17, "R " + rightClicks.size(), wasRight, accent);
        }
    }

    private void drawKey(GuiGraphics g, int x, int y, int w, int h, String label, boolean pressed, int accent) {
        g.fill(x, y, x + w, y + h, pressed ? 0xEE39265A : 0xCC111521);
        g.fill(x, y, x + w, y + 1, pressed ? accent : FAINT);
        g.drawCenteredString(mc.font, label, x + w / 2, y + (h - mc.font.lineHeight) / 2, pressed ? 0xFFFFFFFF : MUTED);
    }

    private void drawClock(GuiGraphics g, int accent, int sw, int sh) {
        String time = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"));
        int w = mc.font.width(time) + 16;
        int x = sw - w - 7;
        int y = sh - 25;
        panel(g, x, y, w, 18, accent);
        g.drawCenteredString(mc.font, time, x + w / 2, y + 5, TEXT);
    }

    private void drawCrosshair(GuiGraphics g, int sw, int sh, int accent) {
        int cx = sw / 2;
        int cy = sh / 2;
        // Small four-piece reticle; the center is left open to keep targets visible.
        g.fill(cx - 7, cy, cx - 3, cy + 1, 0xCCFFFFFF);
        g.fill(cx + 4, cy, cx + 8, cy + 1, 0xCCFFFFFF);
        g.fill(cx, cy - 7, cx + 1, cy - 3, 0xCCFFFFFF);
        g.fill(cx, cy + 4, cx + 1, cy + 8, 0xCCFFFFFF);
        g.fill(cx - 1, cy - 1, cx + 2, cy + 2, accent);
    }

    private String trim(String text, int maxWidth) {
        if (mc.font.width(text) <= maxWidth) return text;
        String shortened = text;
        while (!shortened.isEmpty() && mc.font.width(shortened + "…") > maxWidth) {
            shortened = shortened.substring(0, shortened.length() - 1);
        }
        return shortened + "…";
    }
}
