package dev.hudclient.module.misc;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import net.minecraft.world.phys.BlockHitResult;

/** Continuously mines the currently targeted block using normal game-mode interactions. */
public final class AutoMine extends Module {
    public AutoMine(){super("Auto Mine",Category.MISC);setDescription("Continuously mines the block under the crosshair using normal game-mode breaking rules.");}
    @Override public void onTick(){
        if(mc.player==null||mc.level==null||mc.gameMode==null||mc.screen!=null)return;
        if(!(mc.hitResult instanceof BlockHitResult hit)){mc.gameMode.stopDestroyBlock();return;}
        if(mc.level.getBlockState(hit.getBlockPos()).isAir()){mc.gameMode.stopDestroyBlock();return;}
        if(!mc.gameMode.isDestroying()) mc.gameMode.startDestroyBlock(hit.getBlockPos(),hit.getDirection());
        else mc.gameMode.continueDestroyBlock(hit.getBlockPos(),hit.getDirection());
    }
    @Override public void onDisable(){if(mc.gameMode!=null)mc.gameMode.stopDestroyBlock();}
}
