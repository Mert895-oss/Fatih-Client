package dev.hudclient.module.misc;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import net.minecraft.world.entity.player.PlayerModelPart;

import java.util.EnumMap;
import java.util.Map;

/** Keeps all local skin overlay layers enabled and restores the user's original choices on disable. */
public final class SkinProtect extends Module {
    private final Map<PlayerModelPart, Boolean> previous = new EnumMap<>(PlayerModelPart.class);

    public SkinProtect() {
        super("Skin Protect", Category.MISC);
        setDescription("Keeps your own hat, jacket, sleeves, pants and cape skin layers visible. Restores their previous state when disabled.");
    }

    @Override
    public void onEnable() {
        previous.clear();
        for (PlayerModelPart part : PlayerModelPart.values()) {
            boolean enabled = mc.options.isModelPartEnabled(part);
            previous.put(part, enabled);
            mc.options.setModelPart(part, true);
        }
        mc.options.save();
    }

    @Override
    public void onTick() {
        for (PlayerModelPart part : PlayerModelPart.values()) {
            if (!mc.options.isModelPartEnabled(part)) mc.options.setModelPart(part, true);
        }
    }

    @Override
    public void onDisable() {
        for (Map.Entry<PlayerModelPart, Boolean> entry : previous.entrySet()) {
            mc.options.setModelPart(entry.getKey(), entry.getValue());
        }
        mc.options.save();
        previous.clear();
    }
}
