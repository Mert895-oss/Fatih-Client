package dev.hudclient.module.misc;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.setting.NumberSetting;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.phys.BlockHitResult;

/** Repeats normal block-use while the player holds right click. */
public final class FastPlace extends Module {
    private final NumberSetting delay=num("Repeat Delay (ticks)",2,1,10,1);
    private int cooldown;
    public FastPlace(){super("Fast Place",Category.MISC);setDescription("Repeats vanilla block-use while right-click is held; the server still controls placement acceptance and rate.");}
    @Override public void onTick(){
        if(mc.player==null||mc.level==null||mc.gameMode==null||mc.screen!=null||!mc.options.keyUse.isDown()){cooldown=0;return;}
        if(cooldown>0){cooldown--;return;}
        if(mc.hitResult instanceof BlockHitResult hit){
            mc.gameMode.useItemOn(mc.player,InteractionHand.MAIN_HAND,hit);
            cooldown=delay.getInt();
        }
    }
}
