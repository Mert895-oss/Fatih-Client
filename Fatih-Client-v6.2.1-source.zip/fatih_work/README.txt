FATIH CLIENT v6.2 — Minecraft 1.21.11 (Fabric)

Project type: Fabric client mod source (Java 21).
Brand: FATIH CLIENT
Mod id: fatihclient
Config: config/fatih-client.json

HUD / CLICKGUI
- Dark compact UI with five category columns and medium-size module rows.
- Circular radar with range rings; it is not square.
- Watermark, FPS/ping, coordinates, speed, compass, active module array, server sidebar, potion effects, clock, WASD/Space, LMB/RMB/CPS and crosshair.
- HUD scale and component toggles are configurable.
- Right-click an implemented module to open settings. Click BIND, then press a keyboard key or mouse button to assign it. Escape clears a key bind.
- Left-click toggles modules; mouse wheel scrolls categories; Right Shift opens the GUI.

IMPLEMENTED MODULES IN THIS SOURCE
Combat: Auto Totem.
Misc: Sprint, Auto Eat, Auto Tool, Key Pearl, Auto Log, Auto Reconnect, Auto Mine, Auto Clicker, Fast Place, Cord Snapper, Anti Trap, Skin Protect, Auto Loot.
Donut / chunk: Spawner Chunk Finder, Player Chunk, Amethyst Activity Finder, Item Snapper, Netherite Finder (visible line-of-sight only), Spawner Protect (visible line-of-sight only).
Basefinding: Hole ESP, Light Finder, Jungle Finder.
Render: Player ESP (loaded players through walls), Freecam, Free Look, Storage ESP, Suspicious ESP, Pearl Predict, Target HUD, Jump Circles, HUD, Fullbright, Block ESP, Ore Sim (visible line-of-sight only), SwingSpeed.

CAMERA / WALL VISIBILITY
- Freecam detaches the local camera. WASD moves relative to camera rotation; Space and Shift move up/down; Sprint increases speed. The local player is held at the original client position. Freecam has not been validated against every server or every launcher.
- Free Look can be configured as a hold bind (recommended) or toggled from the GUI. Mouse look is separated from player body rotation.
- Player ESP renders already-loaded player entities with a no-depth-test pass, so those players can be outlined through walls. It cannot reveal unloaded/hidden players or hidden block data.
- No anti-Xray bypass, hidden-block inference, anti-cheat evasion, seed recovery, or server-side data extraction is included.
- Ore / ancient-debris / spawner marking is restricted to blocks that are already in client-loaded chunks and are directly visible from the player's current position.
- Amethyst activity is only a weak heuristic; it cannot prove an AFK player or base.

NOT IMPLEMENTED / SERVER-SPECIFIC ENTRIES STILL SHOWN AS SOON
- Auto TPA, Elytra Glide, Name Protect.
- Auction Sniper, Auto Sell, Auto Spawner Sell, RTP Base Finder, Auto Shulker Buy, Tunnel Base Finder, Fake Stats, Chunk Finder.
- Seed Chunk Finder.
- RemLightbox (the source screenshot's label is ambiguous).
These depend on server-specific commands, UI flows, known world data, or a clearer feature definition. They are deliberately not represented as working features. In particular, Tunnel Base Finder / Seed Chunk Finder are not implemented as hidden-content or anti-Xray bypasses.

MOBILE / PC
- This is a Java Fabric mod for Minecraft Java 1.21.11. It can be tried on desktop Java and Android launchers that support Java 21 + Fabric 1.21.11.
- Touch support depends on the launcher translating screen touches / virtual controls into the normal Minecraft mouse and keyboard events. This project does not yet provide a dedicated on-screen touch joystick or touch-only keybind editor. PC keyboard/mouse controls are the primary tested design target; mobile has not been device-tested.

BUILD
- Minecraft 1.21.11, Fabric Loader 0.18.1+, Fabric API 0.141.1+1.21.11, Java 21, Loom 1.14-SNAPSHOT, Gradle 9.2.0.
- Open the folder containing build.gradle and run: gradle build
- Or push this project to GitHub and run Actions. The workflow also accepts the source ZIP named Fatih-Client-v6.2-source.zip at the repository root.
- Expected main output name: build/libs/fatih-client-v6-6.2.0.jar (and a sources JAR).

VALIDATION
- The current environment does not have Gradle or cached Minecraft/Fabric dependencies, and remote dependency downloads are unavailable. The JAR could not be compiled here. The changes have been statically reviewed, but a successful GitHub Actions build and in-game test are still required before calling the JAR verified.
- Test Freecam / Free Look first in a disposable singleplayer world. Multiplayer behavior is controlled by the server and the server may restrict client mods.

REFERENCE / LICENSING
- Meteor Client is GPL-3.0. Its public module architecture was consulted as a design reference; no Meteor Java source files were copied into this project. This project is not affiliated with Meteor Development.
- Reference: https://github.com/MeteorDevelopment/meteor-client
