package dev.hudclient.mixin;

import dev.hudclient.util.CameraController;
import net.minecraft.client.player.LocalPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Keeps the real player anchored while the detached camera is active. */
@Mixin(LocalPlayer.class)
public abstract class LocalPlayerMixin {
    @Inject(method = "sendPosition()V", at = @At("HEAD"))
    private void fatih$keepPlayerAnchoredBeforePacket(CallbackInfo ci) {
        CameraController.freezePlayer((LocalPlayer) (Object) this);
    }
}
