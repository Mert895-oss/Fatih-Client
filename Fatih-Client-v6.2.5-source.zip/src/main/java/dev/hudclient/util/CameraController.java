package dev.hudclient.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.phys.Vec3;

/**
 * Shared native Minecraft camera state for Fatih Client's Freecam and Free Look.
 * Camera rotation is applied by CameraMixin; mouse input is routed by EntityLookMixin.
 */
public final class CameraController {
    private static Entity freecamCamera;
    private static LocalPlayer anchoredPlayer;
    private static boolean freeLookActive;

    private static Vec3 playerAnchor;
    private static Vec3 playerVelocity;
    private static float playerAnchorYaw;
    private static float playerAnchorPitch;

    private static float freeLookYaw;
    private static float freeLookPitch;

    private CameraController() {}

    public static boolean startFreecam() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || freecamCamera != null) return false;

        // Do not carry an old hold-to-look rotation into the detached camera.
        stopFreeLook();

        Entity camera = EntityType.MARKER.create(mc.level, EntitySpawnReason.COMMAND);
        if (camera == null) return false;

        LocalPlayer player = mc.player;
        anchoredPlayer = player;
        playerAnchor = player.position();
        playerVelocity = player.getDeltaMovement();
        playerAnchorYaw = player.getYRot();
        playerAnchorPitch = player.getXRot();

        camera.setNoGravity(true);
        camera.setPos(player.getX(), player.getY() + player.getEyeHeight(), player.getZ());
        camera.setYRot(player.getYRot());
        camera.setXRot(player.getXRot());
        syncOld(camera);

        freecamCamera = camera;
        mc.setCameraEntity(camera);
        return true;
    }

    /** Start first-person Free Look without changing the player's body rotation. */
    public static boolean startFreeLook() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || freecamCamera != null) return false;
        if (freeLookActive) return true;

        freeLookYaw = mc.player.getYRot();
        freeLookPitch = mc.player.getXRot();
        freeLookActive = true;
        mc.setCameraEntity(mc.player);
        return true;
    }

    /** Called once per client tick while the Freecam module is enabled. */
    public static void tickFreecam(double speed) {
        Minecraft mc = Minecraft.getInstance();
        if (freecamCamera == null) return;
        if (mc.player == null || mc.level == null || mc.player != anchoredPlayer) {
            stopFreecam();
            return;
        }

        freezePlayer(mc.player);
        if (freecamCamera == null) return;
        syncOld(freecamCamera);
        if (mc.screen != null) return;

        double multiplier = mc.options.keySprint.isDown() ? 2.0 : 1.0;
        double step = Math.max(0.025, Math.min(3.0, speed)) * multiplier;
        float yaw = freecamCamera.getYRot();
        Vec3 forward = Vec3.directionFromRotation(0.0F, yaw);
        Vec3 right = Vec3.directionFromRotation(0.0F, yaw + 90.0F);
        double dx = 0.0;
        double dy = 0.0;
        double dz = 0.0;

        if (mc.options.keyUp.isDown()) {
            dx += forward.x * step;
            dz += forward.z * step;
        }
        if (mc.options.keyDown.isDown()) {
            dx -= forward.x * step;
            dz -= forward.z * step;
        }
        if (mc.options.keyRight.isDown()) {
            dx += right.x * step;
            dz += right.z * step;
        }
        if (mc.options.keyLeft.isDown()) {
            dx -= right.x * step;
            dz -= right.z * step;
        }
        if (mc.options.keyJump.isDown()) dy += step;
        if (mc.options.keyShift.isDown()) dy -= step;

        // Keep diagonal movement from being faster than straight movement.
        double horizontalLength = Math.sqrt(dx * dx + dz * dz);
        if (horizontalLength > step && horizontalLength > 0.0) {
            dx = dx / horizontalLength * step;
            dz = dz / horizontalLength * step;
        }

        freecamCamera.setPos(freecamCamera.getX() + dx,
                freecamCamera.getY() + dy,
                freecamCamera.getZ() + dz);
        syncOld(freecamCamera);
    }

    /** Keep render interpolation in sync with the entity's current transform. */
    private static void syncOld(Entity entity) {
        entity.xo = entity.getX();
        entity.yo = entity.getY();
        entity.zo = entity.getZ();
        entity.yRotO = entity.getYRot();
        entity.xRotO = entity.getXRot();
    }

    /** Route mouse look to the detached camera or independent Free Look angles. */
    public static boolean handlePlayerTurn(Entity turningEntity, double deltaYaw, double deltaPitch) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || turningEntity != mc.player) return false;

        if (freecamCamera != null) {
            float yaw = freecamCamera.getYRot() + (float) (deltaYaw * 0.15);
            float pitch = clamp(freecamCamera.getXRot() + (float) (deltaPitch * 0.15), -90.0F, 90.0F);
            freecamCamera.setYRot(yaw);
            freecamCamera.setXRot(pitch);
            freecamCamera.yRotO = yaw;
            freecamCamera.xRotO = pitch;
            return true;
        }
        if (freeLookActive) {
            freeLookYaw += (float) (deltaYaw * 0.15);
            freeLookPitch = clamp(freeLookPitch + (float) (deltaPitch * 0.15), -90.0F, 90.0F);
            return true;
        }
        return false;
    }

    public static float getFreeLookYaw() {
        return freeLookYaw;
    }

    public static float getFreeLookPitch() {
        return freeLookPitch;
    }

    /** Keep the real local player at its saved position during Freecam. */
    public static void freezePlayer(LocalPlayer player) {
        if (freecamCamera == null || playerAnchor == null || player == null) return;
        if (player != anchoredPlayer) {
            // Respawn replaces LocalPlayer; never pull a new life back to an old anchor.
            stopFreecam();
            return;
        }
        player.setPos(playerAnchor.x, playerAnchor.y, playerAnchor.z);
        player.setDeltaMovement(Vec3.ZERO);
        player.setYRot(playerAnchorYaw);
        player.setXRot(playerAnchorPitch);
        syncOld(player);
    }

    public static void stopFreecam() {
        Minecraft mc = Minecraft.getInstance();
        Entity oldCamera = freecamCamera;
        LocalPlayer oldPlayer = anchoredPlayer;
        freecamCamera = null;
        anchoredPlayer = null;

        if (mc.player != null && oldCamera != null && mc.getCameraEntity() == oldCamera) {
            mc.setCameraEntity(mc.player);
        }
        if (mc.player != null && mc.player == oldPlayer && playerAnchor != null) {
            mc.player.setPos(playerAnchor.x, playerAnchor.y, playerAnchor.z);
            mc.player.setDeltaMovement(playerVelocity == null ? Vec3.ZERO : playerVelocity);
            mc.player.setYRot(playerAnchorYaw);
            mc.player.setXRot(playerAnchorPitch);
            syncOld(mc.player);
        }
        clearAnchor();
    }

    public static void stopFreeLook() {
        boolean wasFreeLooking = freeLookActive;
        freeLookActive = false;
        Minecraft mc = Minecraft.getInstance();
        if (wasFreeLooking && freecamCamera == null && mc.player != null
                && mc.getCameraEntity() != mc.player) {
            mc.setCameraEntity(mc.player);
        }
    }

    public static void stopAll() {
        stopFreecam();
        stopFreeLook();
    }

    private static void clearAnchor() {
        playerAnchor = null;
        playerVelocity = null;
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    public static boolean isActive() {
        return freecamCamera != null || freeLookActive;
    }

    public static boolean isFreecam() {
        return freecamCamera != null;
    }

    public static boolean isFreeLook() {
        return freeLookActive;
    }
}
