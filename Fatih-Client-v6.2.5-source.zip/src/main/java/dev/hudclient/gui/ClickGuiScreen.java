package dev.hudclient.gui;

import dev.hudclient.config.Config;
import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.module.ModuleManager;
import dev.hudclient.module.hud.HudModule;
import dev.hudclient.setting.BoolSetting;
import dev.hudclient.setting.ModeSetting;
import dev.hudclient.setting.NumberSetting;
import dev.hudclient.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Fatih Client's resizable, touch-friendly purple/black ClickGUI. */
public final class ClickGuiScreen extends Screen {
    private static final int HEAD = 48;
    private static final int FOOT = 25;
    private static final int SETTINGS_ROW = 30;
    private static final int MODULE_ROW = 32;

    private final int[] moduleScroll = new int[Category.values().length + 1];
    private final int[] settingScroll = new int[Category.values().length + 1];
    private Category selected = Category.COMBAT;
    private Module open;
    private Module binding;
    private NumberSetting draggingNumber;
    private int numberX, numberW;
    private boolean draggingWindow;
    private boolean draggingScrollbar;
    private Module dragCandidate;
    private boolean reorderingModule;
    private int dragStartX, dragStartY;
    private int reorderTargetIndex;
    private int dragOffsetX, dragOffsetY;
    private int scrollbarGrabY;
    private int panelX = Integer.MIN_VALUE;
    private int panelY;
    private int panelW;
    private int panelH;
    private int navW;
    private boolean globalSettings;
    private String searchQuery = "";
    private boolean searchFocused;

    private static final int ACCENT = 0xFFB45CFF;
    private static final int ACCENT_DARK = 0xFF7036B8;
    private static final int TEXT = 0xFFF2F0F8;
    private static final int MUTED = 0xFF9B96A9;
    private static final int PANEL = 0xF20A0912;
    private static final int PANEL_3 = 0xFF191426;
    private static final int BORDER = 0xFF4E286F;

    public ClickGuiScreen() {
        super(Component.literal("Fatih Client"));
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void onClose() {
        Config.save();
        super.onClose();
    }

    private void layout() {
        panelW = Math.max(220, Math.min(680, width - 12));
        panelH = Math.max(190, Math.min(470, height - 12));
        navW = panelW < 470
                ? Math.max(90, Math.min(124, (int) (panelW * 0.34)))
                : Math.max(160, Math.min(210, (int) (panelW * 0.30)));
        if (panelX == Integer.MIN_VALUE) {
            panelX = Math.max(8, width - panelW - 18);
            panelY = Math.max(8, (height - panelH) / 2 - 8);
        }
        panelX = Math.max(4, Math.min(panelX, Math.max(4, width - panelW - 4)));
        panelY = Math.max(4, Math.min(panelY, Math.max(4, height - panelH - 4)));
    }

    private int contentTop() { return panelY + HEAD + 5; }
    private int contentBottom() { return panelY + panelH - FOOT - SETTINGS_ROW; }
    private int contentHeight() { return Math.max(1, contentBottom() - contentTop()); }
    private int moduleX() { return panelX + navW + 1; }
    private int moduleRight() { return panelX + panelW - 1; }
    private int moduleRowHeight() { return Math.min(MODULE_ROW, Math.max(24, contentHeight() / 8)); }
    private int categoryTabHeight() { return Math.min(34, Math.max(14, contentHeight() / Category.values().length)); }
    private int searchScrollIndex() { return Category.values().length; }

    private static List<Module> modulesOf(Category category) {
        List<Module> result = new ArrayList<>();
        for (Module module : ModuleManager.all()) {
            if (module.category == category) result.add(module);
        }
        return result;
    }

    private List<Module> modulesToDisplay() {
        List<Module> source = searchQuery.isBlank() ? modulesOf(selected) : new ArrayList<>(ModuleManager.all());
        if (searchQuery.isBlank()) return source;
        String query = searchQuery.toLowerCase(Locale.ROOT);
        List<Module> filtered = new ArrayList<>();
        for (Module module : source) {
            if (module.getName().toLowerCase(Locale.ROOT).contains(query)
                    || module.getDescription().toLowerCase(Locale.ROOT).contains(query)
                    || module.category.label.toLowerCase(Locale.ROOT).contains(query)) {
                filtered.add(module);
            }
        }
        return filtered;
    }

    private int scrollIndex() {
        return searchQuery.isBlank() ? selected.ordinal() : searchScrollIndex();
    }

    private static String keyName(int key) {
        if (key <= -100) return "MOUSE " + (-key - 99);
        if (key < 0) return "NONE";
        if (key == GLFW.GLFW_KEY_RIGHT_SHIFT) return "RSHIFT";
        if (key == GLFW.GLFW_KEY_LEFT_SHIFT) return "LSHIFT";
        if (key == GLFW.GLFW_KEY_RIGHT_CONTROL) return "RCTRL";
        if (key == GLFW.GLFW_KEY_LEFT_CONTROL) return "LCTRL";
        if (key == GLFW.GLFW_KEY_SPACE) return "SPACE";
        String name = GLFW.glfwGetKeyName(key, 0);
        return name == null ? "KEY " + key : name.toUpperCase(Locale.ROOT);
    }

    private static String trim(Minecraft mc, String value, int maxWidth) {
        if (maxWidth <= 0) return "";
        if (mc.font.width(value) <= maxWidth) return value;
        String result = value;
        while (!result.isEmpty() && mc.font.width(result + "…") > maxWidth) {
            result = result.substring(0, result.length() - 1);
        }
        return result + "…";
    }

    private int searchLeft() { return panelX + Math.max(navW + 14, (int) (panelW * 0.46)); }
    private int searchRight() { return panelX + panelW - 14; }

    private static String shortCategoryLabel(Category category) {
        return switch (category) {
            case MOVEMENT -> "Move";
            case COMBAT -> "Combat";
            case RENDER -> "Render";
            case PLAYER -> "Player";
            case WORLD -> "World";
            case MISC -> "Misc";
            case HUD -> "HUD";
            case CLIENT -> "Client";
        };
    }
    private int searchTop() { return panelY + 10; }
    private int searchBottom() { return searchTop() + 24; }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        layout();
        super.render(g, mouseX, mouseY, delta);
        drawBackdrop(g);
        drawWindow(g, mouseX, mouseY);
        if (binding != null) {
            String prompt = "BIR TUS VEYA FARE TUSU SEC...  (ESC: IPTAL)";
            g.fill(0, 0, width, height, 0x77000000);
            int w = Math.min(panelW - 20, font.width(prompt) + 28);
            int x = (width - w) / 2;
            int y = height / 2 - 18;
            rounded(g, x, y, w, 38, 0xFF120D1D, ACCENT);
            g.drawCenteredString(font, trim(Minecraft.getInstance(), prompt, w - 20), x + w / 2, y + 14, TEXT);
        }
    }

    private void drawBackdrop(GuiGraphics g) {
        // Use Minecraft's built-in blur pipeline so the screen remains compatible
        // with mobile OpenGL launchers; no NanoVG or desktop-only renderer.
        try {
            renderBlurredBackground(g);
        } catch (RuntimeException ignored) {
            // Keep a readable dimmed overlay if a launcher cannot run the blur shader.
        }
        g.fill(0, 0, width, height, 0x42000000);
    }

    private void drawWindow(GuiGraphics g, int mouseX, int mouseY) {
        int right = panelX + panelW;
        int bottom = panelY + panelH;
        rounded(g, panelX - 3, panelY - 3, panelW + 6, panelH + 6, 0x553F1C5D, ACCENT_DARK);
        rounded(g, panelX, panelY, panelW, panelH, PANEL, BORDER);
        rounded(g, panelX + 1, panelY + 1, panelW - 2, HEAD, PANEL_3, BORDER);

        // Header: compact brand mark, title/version and a separate module search field.
        g.fill(panelX + 13, panelY + 10, panelX + 39, panelY + 36, 0xFF26123A);
        g.drawCenteredString(font, "♛", panelX + 26, panelY + 18, ACCENT);
        g.drawString(font, panelW < 300 ? "FATIH" : "Fatih Client", panelX + 47, panelY + 11, TEXT, true);
        if (panelW >= 300) g.drawString(font, "v6.2.5", panelX + 47, panelY + 26, MUTED, false);

        int sLeft = searchLeft();
        int sRight = Math.max(sLeft + 56, searchRight());
        rounded(g, sLeft, searchTop(), sRight - sLeft, 24,
                searchFocused ? 0xFF21152D : 0xCC100D19,
                searchFocused ? ACCENT : 0xFF47305C);
        g.drawString(font, "⌕", sLeft + 7, searchTop() + 6, ACCENT, true);
        String searchLabel = searchQuery.isEmpty() ? "Modül ara..." : searchQuery;
        g.drawString(font, trim(Minecraft.getInstance(), searchLabel, sRight - sLeft - 28), sLeft + 25, searchTop() + 7,
                searchQuery.isEmpty() ? MUTED : TEXT, false);
        if (searchFocused && (System.currentTimeMillis() / 500L) % 2L == 0L) {
            int caretX = sLeft + 25 + font.width(trim(Minecraft.getInstance(), searchLabel, sRight - sLeft - 32));
            g.fill(caretX + 2, searchTop() + 6, caretX + 3, searchTop() + 18, ACCENT);
        }

        g.fill(panelX + 1, panelY + HEAD, right - 1, panelY + HEAD + 1, BORDER);

        // Eight-tab category rail.
        int left = panelX + 1;
        int navRight = panelX + navW;
        g.fill(left, panelY + HEAD + 1, navRight, bottom - FOOT - 1, 0xCC0D0A16);
        g.fill(navRight, panelY + HEAD + 1, navRight + 1, bottom - FOOT - 1, 0xFF342044);
        int tabTop = contentTop() + 1;
        int tabH = categoryTabHeight();
        Category[] categories = Category.values();
        for (int i = 0; i < categories.length; i++) {
            Category category = categories[i];
            int y = tabTop + i * tabH;
            if (y + tabH > contentBottom()) break;
            boolean active = selected == category && !globalSettings && searchQuery.isBlank();
            if (active) {
                rounded(g, panelX + 8, y + 2, navW - 17, tabH - 4, 0xFF32164B, ACCENT_DARK);
                g.fill(panelX + 9, y + 3, panelX + 12, y + tabH - 3, ACCENT);
            }
            int iconColor = active ? ACCENT : 0xFFB2A9C2;
            int textY = y + Math.max(0, (tabH - font.lineHeight) / 2);
            int iconX = panelX + (navW < 120 ? 20 : 27);
            int labelX = panelX + (navW < 120 ? 35 : 46);
            g.drawCenteredString(font, category.icon, iconX, textY, iconColor);
            String label = navW < 120 ? shortCategoryLabel(category) : category.label;
            int labelWidth = navW < 120 ? navW - 43 : navW - 76;
            g.drawString(font, trim(Minecraft.getInstance(), label, labelWidth), labelX, textY,
                    active ? TEXT : 0xFFD0CADB, active);
            if (navW >= 120) {
                String count = Integer.toString(modulesOf(category).size());
                g.drawString(font, count, navRight - font.width(count) - 9,
                        textY, MUTED, false);
            }
        }

        if (open != null || globalSettings) drawSettings(g, mouseX, mouseY);
        else drawModules(g, mouseX, mouseY);

        // Global settings shortcut and draggable footer.
        int settingsY = bottom - FOOT - SETTINGS_ROW;
        g.fill(navRight + 1, settingsY, right - 1, settingsY + SETTINGS_ROW, 0xE3110D1A);
        g.fill(navRight + 1, settingsY, right - 1, settingsY + 1, 0xFF39224A);
        g.drawString(font, "⚙", navRight + 14, settingsY + 9, 0xFFD0C4E2);
        g.drawString(font, "Ayarlar", navRight + 36, settingsY + 9, TEXT, false);
        g.drawString(font, "›", right - 20, settingsY + 6, ACCENT, true);

        int footerY = bottom - FOOT;
        g.fill(panelX + 1, footerY, right - 1, bottom - 1, 0xF00D0916);
        g.fill(panelX + 1, footerY, right - 1, footerY + 1, 0xFF39224A);
        g.drawCenteredString(font, "✥  Sürükleyerek taşı", panelX + panelW / 2, footerY + 8, ACCENT);
    }

    private void drawModules(GuiGraphics g, int mouseX, int mouseY) {
        int x = moduleX() + 10;
        int right = moduleRight() - 10;
        int top = contentTop() + 3;
        int rowH = moduleRowHeight();
        List<Module> modules = modulesToDisplay();
        int visible = Math.max(1, (contentBottom() - top - 3) / rowH);
        int scrollKey = scrollIndex();
        int maxScroll = Math.max(0, modules.size() - visible);
        moduleScroll[scrollKey] = clamp(moduleScroll[scrollKey], 0, maxScroll);
        int start = moduleScroll[scrollKey];
        int shown = Math.min(visible, Math.max(0, modules.size() - start));

        if (modules.isEmpty()) {
            String message = searchQuery.isEmpty() ? "Bu kategoride modül yok." : "Eşleşen modül bulunamadı.";
            g.drawString(font, message, x + 5, top + 7, MUTED, false);
            return;
        }

        for (int i = 0; i < shown; i++) {
            Module module = modules.get(start + i);
            int y = top + i * rowH;
            if (y + rowH > contentBottom()) break;
            boolean hover = mouseX >= x && mouseX < right && mouseY >= y && mouseY < y + rowH;
            int cardFill = hover ? 0xCC302044 : 0xAA15111E;
            int cardBorder = hover ? 0xFF7445A0 : 0x553A2A4A;
            rounded(g, x, y + 1, right - x - 4, rowH - 3, cardFill, cardBorder);

            int iconY = y + rowH / 2;
            g.drawCenteredString(font, module.isEnabled() ? "●" : "○", x + 10, iconY - 4,
                    module.isEnabled() ? ACCENT : 0xFF8F879C);
            int textX = x + 21;
            int gearX = right - 40;
            int labelColor = !module.isImplemented() ? 0xFF817A8D : module.isEnabled() ? TEXT : 0xFFE0DCE8;
            g.drawString(font, trim(Minecraft.getInstance(), module.getName(), Math.max(40, gearX - textX - 34)),
                    textX, y + Math.max(2, (rowH - font.lineHeight) / 2), labelColor, module.isEnabled());
            g.drawCenteredString(font, "⚙", gearX + 5, iconY - 4,
                    module.isImplemented() ? 0xFFB9AFC8 : 0xFF5F5969);
            drawSwitch(g, right - 29, iconY - 7,
                    module.isImplemented() && module.isEnabled(), module.isImplemented());
        }

        if (reorderingModule && dragCandidate != null) {
            int markerY = top + clamp(reorderTargetIndex - start, 0, Math.max(0, shown)) * rowH;
            g.fill(x - 2, markerY - 1, right - 2, markerY + 1, ACCENT);
        }
        if (modules.size() > visible) drawScrollbar(g, top, contentBottom() - top - 3, visible, modules.size(), start, maxScroll);
    }

    private void drawSettings(GuiGraphics g, int mouseX, int mouseY) {
        int x = moduleX() + 13;
        int right = moduleRight() - 13;
        int top = contentTop() + 3;
        int rowH = Math.min(34, Math.max(24, contentHeight() / 8));
        Module target = globalSettings ? ModuleManager.get(HudModule.class) : open;
        if (target == null) return;

        g.drawString(font, "‹", x, top - 1, ACCENT, true);
        g.drawString(font, globalSettings ? "GENEL AYARLAR" : target.getName().toUpperCase(Locale.ROOT), x + 20, top, TEXT, true);
        int bindY = top + rowH + 3;
        rounded(g, x, bindY, right - x, rowH - 3, 0xFF20172C, 0xFF4B2C68);
        g.drawString(font, "Bind", x + 9, bindY + 8, TEXT, false);
        String bindText = binding == target ? "TUS BEKLENIYOR..." : keyName(target.getKey());
        g.drawString(font, bindText, right - font.width(bindText) - 9, bindY + 8, ACCENT, false);

        List<Setting<?>> settings = target.getSettings();
        int scrollKey = globalSettings ? Category.values().length : selected.ordinal();
        int start = settingScroll[scrollKey];
        int firstY = bindY + rowH + 5;
        int rows = Math.max(1, (contentBottom() - firstY - 3) / rowH);
        int maxScroll = Math.max(0, settings.size() - rows);
        start = clamp(start, 0, maxScroll);
        settingScroll[scrollKey] = start;
        for (int i = start; i < Math.min(settings.size(), start + rows); i++) {
            Setting<?> setting = settings.get(i);
            int y = firstY + (i - start) * rowH;
            rounded(g, x, y, right - x, rowH - 3, 0xB91A1424, 0x552F2441);
            if (setting instanceof BoolSetting bool) {
                g.drawString(font, trim(Minecraft.getInstance(), bool.name, right - x - 58), x + 9, y + 8, TEXT, false);
                g.drawString(font, bool.get() ? "ON" : "OFF", right - 37, y + 8, bool.get() ? ACCENT : MUTED, true);
            } else if (setting instanceof NumberSetting number) {
                g.drawString(font, trim(Minecraft.getInstance(), number.name + ": " + number.display(), right - x - 10), x + 9, y + 7, TEXT, false);
                int barX = x + 9;
                int barW = right - x - 18;
                g.fill(barX, y + rowH - 7, barX + barW, y + rowH - 4, 0xFF352B44);
                g.fill(barX, y + rowH - 7, barX + (int) (barW * number.fraction()), y + rowH - 4, ACCENT);
            } else if (setting instanceof ModeSetting mode) {
                g.drawString(font, trim(Minecraft.getInstance(), mode.name, right - x - 100), x + 9, y + 8, TEXT, false);
                String value = "‹ " + mode.get() + " ›";
                g.drawString(font, value, right - font.width(value) - 8, y + 8, ACCENT, false);
            } else {
                g.drawString(font, setting.name, x + 9, y + 8, TEXT, false);
            }
        }
        if (settings.size() > rows) drawScrollbar(g, firstY, contentBottom() - firstY - 5, rows, settings.size(), start, maxScroll);
    }

    private void drawScrollbar(GuiGraphics g, int y, int h, int visible, int total, int offset, int maxScroll) {
        int x = moduleRight() - 5;
        int thumbH = Math.max(18, h * visible / Math.max(1, total));
        int travel = Math.max(1, h - thumbH);
        int thumbY = y + (int) Math.round(travel * (offset / (double) Math.max(1, maxScroll)));
        g.fill(x, y, x + 2, y + h, 0xFF372B44);
        rounded(g, x - 1, thumbY, 4, thumbH, ACCENT, ACCENT_DARK);
    }

    private static void drawSwitch(GuiGraphics g, int x, int y, boolean enabled, boolean implemented) {
        int track = !implemented ? 0xFF28242F : enabled ? ACCENT_DARK : 0xFF3A3444;
        rounded(g, x, y, 27, 14, track, implemented && enabled ? ACCENT : 0xFF51485B);
        int knobX = enabled ? x + 14 : x + 2;
        g.fill(knobX, y + 2, knobX + 10, y + 12, 0xFFF5F0FA);
    }

    private static void rounded(GuiGraphics g, int x, int y, int w, int h, int fill, int border) {
        if (w <= 0 || h <= 0) return;
        g.fill(x + 2, y, x + w - 2, y + h, fill);
        g.fill(x + 1, y + 1, x + w - 1, y + h - 1, fill);
        g.fill(x, y + 2, x + w, y + h - 2, fill);
        if (border != 0) {
            g.fill(x + 3, y, x + w - 3, y + 1, border);
            g.fill(x + 3, y + h - 1, x + w - 3, y + h, border);
            g.fill(x, y + 3, x + 1, y + h - 3, border);
            g.fill(x + w - 1, y + 3, x + w, y + h - 3, border);
        }
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        int key = event.key();
        if (binding != null) {
            binding.setKey(key == GLFW.GLFW_KEY_ESCAPE ? -1 : key);
            binding = null;
            Config.save();
            return true;
        }
        if (searchFocused) {
            if (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) {
                searchFocused = false;
                return true;
            }
            if (key == GLFW.GLFW_KEY_BACKSPACE && !searchQuery.isEmpty()) {
                searchQuery = searchQuery.substring(0, searchQuery.length() - 1);
                moduleScroll[searchScrollIndex()] = 0;
                return true;
            }
            if (key == GLFW.GLFW_KEY_DELETE) {
                searchQuery = "";
                moduleScroll[searchScrollIndex()] = 0;
                return true;
            }
            return true;
        }
        if (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            onClose();
            return true;
        }
        return super.keyPressed(event);
    }

    @Override
    public boolean charTyped(CharacterEvent event) {
        if (binding != null) return true;
        if (searchFocused && event.isAllowedChatCharacter() && searchQuery.length() < 48) {
            searchQuery += event.codepointAsString();
            moduleScroll[searchScrollIndex()] = 0;
            return true;
        }
        return super.charTyped(event);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        layout();
        int mx = (int) event.x();
        int my = (int) event.y();
        int button = event.button();
        int right = panelX + panelW;
        int bottom = panelY + panelH;

        if (binding != null) {
            binding.setKey(-100 - button);
            binding = null;
            Config.save();
            return true;
        }

        // The header search input is tap/click focused; all other header area drags the window.
        if (my >= searchTop() && my < searchBottom() && mx >= searchLeft() && mx < searchRight()) {
            searchFocused = true;
            return true;
        }
        searchFocused = false;

        if (my >= panelY && my < panelY + HEAD) {
            draggingWindow = true;
            dragOffsetX = mx - panelX;
            dragOffsetY = my - panelY;
            return true;
        }

        if (my >= bottom - FOOT) {
            draggingWindow = true;
            dragOffsetX = mx - panelX;
            dragOffsetY = my - panelY;
            return true;
        }

        int settingsY = bottom - FOOT - SETTINGS_ROW;
        if (my >= settingsY && my < settingsY + SETTINGS_ROW && mx >= panelX + navW) {
            globalSettings = true;
            open = null;
            settingScroll[Category.values().length] = 0;
            return true;
        }

        if (mx >= panelX && mx < panelX + navW && my >= contentTop() + 1) {
            int tabTop = contentTop() + 1;
            int tabH = categoryTabHeight();
            int index = (my - tabTop) / tabH;
            if (index >= 0 && index < Category.values().length && my < tabTop + Category.values().length * tabH) {
                selected = Category.values()[index];
                globalSettings = false;
                open = null;
                searchQuery = "";
                searchFocused = false;
                return true;
            }
        }

        int listTop = contentTop() + 3;
        if (mx >= moduleX() && mx < moduleRight() && my >= listTop && my < contentBottom()) {
            if (open != null || globalSettings) {
                Module target = globalSettings ? ModuleManager.get(HudModule.class) : open;
                if (target == null) return true;
                int rowH = Math.min(34, Math.max(24, contentHeight() / 8));
                int top = listTop;
                if (mx < moduleX() + 37 && my < top + rowH) {
                    open = null;
                    globalSettings = false;
                    return true;
                }
                int bindY = top + rowH + 3;
                if (my >= bindY && my < bindY + rowH) {
                    binding = target;
                    return true;
                }
                List<Setting<?>> settings = target.getSettings();
                int firstY = bindY + rowH + 5;
                int scrollKey = globalSettings ? Category.values().length : selected.ordinal();
                int startIndex = settingScroll[scrollKey];
                int rows = Math.max(1, (contentBottom() - firstY - 3) / rowH);
                for (int i = startIndex; i < Math.min(settings.size(), startIndex + rows); i++) {
                    int y = firstY + (i - startIndex) * rowH;
                    if (my < y || my >= y + rowH - 3) continue;
                    Setting<?> setting = settings.get(i);
                    if (setting instanceof BoolSetting bool) {
                        bool.toggle();
                        Config.save();
                    } else if (setting instanceof NumberSetting number) {
                        draggingNumber = number;
                        numberX = moduleX() + 12;
                        numberW = moduleRight() - 24;
                        number.setFromFraction((mx - numberX) / (double) numberW);
                    } else if (setting instanceof ModeSetting mode) {
                        if (button == 1 || mx < moduleX() + 40) mode.prev(); else mode.next();
                        Config.save();
                    }
                    return true;
                }
                return true;
            }

            List<Module> modules = modulesToDisplay();
            int rowH = moduleRowHeight();
            int top = listTop;
            int visible = Math.max(1, (contentBottom() - top - 3) / rowH);
            int index = moduleScroll[scrollIndex()] + Math.max(0, (my - top) / rowH);
            if (index < modules.size() && my < top + visible * rowH) {
                Module module = modules.get(index);
                int gearX = moduleRight() - 50;
                if (button == 1 || mx >= gearX && mx < gearX + 16) {
                    if (module.isImplemented()) {
                        open = module;
                        globalSettings = false;
                        searchFocused = false;
                        int scrollKey = searchQuery.isBlank() ? selected.ordinal() : searchScrollIndex();
                        settingScroll[scrollKey] = 0;
                    }
                } else if (searchQuery.isBlank() && mx < moduleX() + 29) {
                    dragCandidate = module;
                    dragStartX = mx;
                    dragStartY = my;
                    reorderTargetIndex = index;
                    reorderingModule = false;
                } else {
                    module.toggle();
                    Config.save();
                }
                return true;
            }

            if (mx >= moduleRight() - 9) {
                draggingScrollbar = true;
                scrollbarGrabY = my;
                return true;
            }
        }
        return true;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        layout();
        int step = verticalAmount < 0 ? 2 : -2;
        if (open != null || globalSettings) {
            int key = globalSettings ? Category.values().length : selected.ordinal();
            Module target = globalSettings ? ModuleManager.get(HudModule.class) : open;
            if (target != null) {
                int rowH = Math.min(34, Math.max(24, contentHeight() / 8));
                int firstSettingY = contentTop() + 3 + rowH * 2 + 8;
                int rows = Math.max(1, (contentBottom() - firstSettingY - 3) / rowH);
                settingScroll[key] = clamp(settingScroll[key] + step, 0, Math.max(0, target.getSettings().size() - rows));
            }
            return true;
        }
        List<Module> modules = modulesToDisplay();
        int rowH = moduleRowHeight();
        int visible = Math.max(1, (contentBottom() - (contentTop() + 3) - 3) / rowH);
        int key = scrollIndex();
        moduleScroll[key] = clamp(moduleScroll[key] + step, 0, Math.max(0, modules.size() - visible));
        return true;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dragXAmount, double dragYAmount) {
        layout();
        int mx = (int) event.x();
        int my = (int) event.y();
        if (draggingWindow) {
            panelX = mx - dragOffsetX;
            panelY = my - dragOffsetY;
            layout();
            return true;
        }
        if (dragCandidate != null) {
            if (!reorderingModule && Math.abs(mx - dragStartX) + Math.abs(my - dragStartY) >= 5) {
                reorderingModule = true;
            }
            if (reorderingModule) {
                int rowH = moduleRowHeight();
                int top = contentTop() + 3;
                int visible = Math.max(1, (contentBottom() - top - 3) / rowH);
                int relative = clamp((my - top) / rowH, 0, visible);
                reorderTargetIndex = moduleScroll[scrollIndex()] + relative;
                reorderTargetIndex = clamp(reorderTargetIndex, 0, modulesOf(selected).size() - 1);
            }
            return true;
        }
        if (draggingNumber != null) {
            draggingNumber.setFromFraction((mx - numberX) / (double) Math.max(1, numberW));
            return true;
        }
        if (draggingScrollbar) {
            int rowH = moduleRowHeight();
            List<Module> modules = modulesToDisplay();
            int visible = Math.max(1, (contentBottom() - (contentTop() + 3) - 3) / rowH);
            int maxScroll = Math.max(0, modules.size() - visible);
            int movement = my - scrollbarGrabY;
            int key = scrollIndex();
            moduleScroll[key] = clamp(moduleScroll[key] + (movement > 0 ? 1 : movement < 0 ? -1 : 0), 0, maxScroll);
            scrollbarGrabY = my;
            return true;
        }
        return super.mouseDragged(event, dragXAmount, dragYAmount);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        boolean handled = draggingWindow || draggingScrollbar || draggingNumber != null || dragCandidate != null;
        if (dragCandidate != null) {
            if (reorderingModule && searchQuery.isBlank()) {
                ModuleManager.moveWithinCategory(dragCandidate, reorderTargetIndex);
            } else if (!reorderingModule) {
                dragCandidate.toggle();
            }
            Config.save();
        }
        draggingWindow = false;
        draggingScrollbar = false;
        draggingNumber = null;
        dragCandidate = null;
        reorderingModule = false;
        if (handled) return true;
        return super.mouseReleased(event);
    }
}
