package dev.hudclient.module.hud;

import dev.hudclient.HudClient;
import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.module.ModuleManager;
import dev.hudclient.setting.BoolSetting;
import dev.hudclient.setting.ColorSetting;
import dev.hudclient.setting.ModeSetting;
import dev.hudclient.setting.NumberSetting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FontDescription;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.scores.DisplaySlot;
import net.minecraft.world.scores.Objective;
import net.minecraft.world.scores.PlayerScoreEntry;
import org.lwjgl.glfw.GLFW;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** Compact Fatih Client HUD, designed to stay readable at desktop and phone GUI scales. */
public class HudModule extends Module {
    public final ColorSetting color = color("Accent", 178, 91, 255);
    private final ModeSetting font = mode("Font", "Default", "Default", "Uniform", "Alt", "Illager");
    private final NumberSetting uiScale = num("HUD Scale", 0.76, 0.55, 1.00, 0.05);
    private final BoolSetting watermark = bool("Watermark", true);
    private final BoolSetting metrics = bool("FPS / Ping", true);
    private final BoolSetting coords = bool("Coordinates", true);
    private final BoolSetting speed = bool("Speed", true);
    private final BoolSetting moduleList = bool("Active Modules", true);
    private final BoolSetting radar = bool("Circular Radar", true);
    private final NumberSetting radarSize = num("Radar Size", 72, 54, 112, 2);
    private final NumberSetting radarRange = num("Radar Range", 40, 10, 128, 2);
    private final BoolSetting radarMobs = bool("Radar Mobs", false);
    private final BoolSetting compass = bool("Compass", true);
    private final BoolSetting potionEffects = bool("Potion Effects", true);
    private final BoolSetting scoreboard = bool("Scoreboard", true);
    private final BoolSetting clock = bool("Clock", true);
    private final BoolSetting keystrokes = bool("WASD / Space", true);
    private final BoolSetting cps = bool("LMB / RMB / CPS", true);
    private final BoolSetting crosshair = bool("Custom Crosshair", false);

    private int frames;
    private int fpsValue;
    private long fpsStamp = System.currentTimeMillis();
    private boolean wasLeft;
    private boolean wasRight;
    private final ArrayDeque<Long> leftClicks = new ArrayDeque<>();
    private final ArrayDeque<Long> rightClicks = new ArrayDeque<>();

    private static final int PANEL = 0xD90A0D16;
    private static final int PANEL_SOFT = 0xB90A0D16;
    private static final int TEXT = 0xFFF0F1F7;
    private static final int MUTED = 0xFF9CA4B5;
    private static final int FAINT = 0x665F687B;

    public HudModule() {
        super("HUD", Category.HUD);
        setDescription("Compact Fatih Client HUD with a circular radar, compact stats, scoreboard and input display.");
        setEnabled(true);
    }

    private int accent() {
        return 0xFF000000 | color.rgb();
    }

    private Style textStyle() {
        String f = font.get();
        String path = switch (f) {
            case "Uniform" -> "uniform";
            case "Alt" -> "alt";
            case "Illager" -> "illageralt";
            default -> null;
        };
        return path == null ? Style.EMPTY : Style.EMPTY.withFont(new FontDescription.Resource(Identifier.withDefaultNamespace(path)));
    }

    private Component styled(String value, Style style) {
        return Component.literal(value).withStyle(style);
    }

    private int currentFps() {
        frames++;
        long now = System.currentTimeMillis();
        if (now - fpsStamp >= 1000L) {
            fpsValue = frames;
            frames = 0;
            fpsStamp = now;
        }
        return fpsValue;
    }

    private int ping(LocalPlayer player) {
        try {
            var connection = mc.getConnection();
            var info = connection == null ? null : connection.getPlayerInfo(player.getUUID());
            return info == null ? -1 : info.getLatency();
        } catch (RuntimeException ignored) {
            return -1;
        }
    }

    @Override
    public void onRenderHud(GuiGraphics g) {
        LocalPlayer player = mc.player;
        if (player == null || mc.level == null) return;

        float scale = (float) uiScale.getD();
        g.pose().pushMatrix();
        g.pose().scale(scale, scale);
        int sw = (int) Math.ceil(mc.getWindow().getGuiScaledWidth() / scale);
        int sh = (int) Math.ceil(mc.getWindow().getGuiScaledHeight() / scale);
        int accent = accent();
        Style style = textStyle();

        // Approved Fatih Client layout: brand and stats upper-left, circular radar below,
        // Sultan emblem and clock top-centre, active modules upper-right, effects left.
        if (watermark.get()) drawWatermark(g, style, accent, 6, 5, sw);
        if (metrics.get()) drawMetrics(g, style, accent, player, 6, 21);
        if (radar.get()) drawCircularRadar(g, player, accent, sh);
        if (potionEffects.get()) drawEffects(g, style, accent, player, sh);
        int infoY = radar.get() ? 49 + radarSize.getInt() + 8 : 49;
        if (potionEffects.get() && !player.getActiveEffects().isEmpty()) {
            infoY += 16 + Math.min(4, player.getActiveEffects().size()) * 14 + 6;
        }
        if (coords.get()) drawCoordinates(g, style, accent, player, 7, infoY);
        if (speed.get()) drawSpeed(g, style, accent, player, 7, infoY + 22);
        if (moduleList.get()) drawModuleList(g, style, accent, sw);
        if (scoreboard.get()) drawScoreboard(g, style, accent, sw, sh);
        if (keystrokes.get() || cps.get()) drawInputPanel(g, accent, sw, sh);
        if (clock.get()) drawClock(g, accent, sw, sh);
        if (crosshair.get()) drawCrosshair(g, sw, sh, accent);

        g.pose().popMatrix();
    }

    private void panel(GuiGraphics g, int x, int y, int w, int h, int accent) {
        // Pixel-rounded corners keep the cards soft without a native rendering dependency.
        g.fill(x + 2, y, x + w - 2, y + h, PANEL);
        g.fill(x + 1, y + 1, x + w - 1, y + h - 1, PANEL);
        g.fill(x, y + 2, x + w, y + h - 2, PANEL);
        g.fill(x + 3, y, x + w - 3, y + 1, accent);
        g.fill(x + 3, y + h - 1, x + w - 3, y + h, 0x554B5262);
    }

    private void drawWatermark(GuiGraphics g, Style style, int accent, int x, int y, int sw) {
        // Small crown mark keeps the watermark lightweight, like the approved screenshot.
        g.fill(x + 1, y + 3, x + 4, y + 12, accent);
        g.fill(x + 4, y + 3, x + 7, y + 8, accent);
        g.fill(x + 7, y + 1, x + 10, y + 12, accent);
        g.fill(x + 10, y + 4, x + 13, y + 12, accent);
        g.fill(x + 13, y + 3, x + 16, y + 12, accent);
        g.fill(x + 2, y + 12, x + 16, y + 15, accent);
        String brand = sw < 520 ? "Fatih Client" : "Fatih Client " + HudClient.VERSION;
        g.drawString(mc.font, styled(brand, style), x + 22, y + 4, TEXT, true);
    }

    private void drawMetrics(GuiGraphics g, Style style, int accent, LocalPlayer player, int x, int y) {
        int currentPing = ping(player);
        String line = "FPS: " + currentFps() + "   Ping: " + (currentPing < 0 ? "--" : currentPing + "ms");
        g.drawString(mc.font, styled(line, style), x, y, TEXT, false);
    }

    private void drawCoordinates(GuiGraphics g, Style style, int accent, LocalPlayer p, int x, int y) {
        String xyz = String.format(Locale.ROOT, "XYZ  %.1f  /  %.1f  /  %.1f", p.getX(), p.getY(), p.getZ());
        int w = Math.max(128, mc.font.width(xyz) + 12);
        panel(g, x, y, w, 18, accent);
        g.drawString(mc.font, styled("⌖", style), x + 5, y + 5, accent, false);
        g.drawString(mc.font, styled(xyz, style), x + 17, y + 5, TEXT, false);
    }

    private void drawSpeed(GuiGraphics g, Style style, int accent, LocalPlayer p, int x, int y) {
        double dx = p.getX() - p.xo;
        double dz = p.getZ() - p.zo;
        String value = String.format(Locale.ROOT, "SPEED  %.2f blocks/s", Math.sqrt(dx * dx + dz * dz) * 20.0);
        int w = mc.font.width(value) + 12;
        panel(g, x, y, w, 18, accent);
        g.drawString(mc.font, styled(value, style), x + 6, y + 5, TEXT, false);
    }

    private void drawCompass(GuiGraphics g, Style style, int accent, LocalPlayer p, int sw) {
        int w = Math.min(142, Math.max(92, sw / 3));
        int x = Math.max(7, (sw - w) / 2);
        int y = 6;
        panel(g, x, y, w, 20, accent);
        String[] dirs = {"S", "SW", "W", "NW", "N", "NE", "E", "SE"};
        int index = Math.floorMod(Math.round(p.getYRot() / 45.0f), 8);
        String heading = dirs[index];
        g.drawCenteredString(mc.font, styled("◂", style), x + 13, y + 6, MUTED);
        g.drawCenteredString(mc.font, styled(heading, style), x + w / 2, y + 6, accent);
        g.drawCenteredString(mc.font, styled("▸", style), x + w - 13, y + 6, MUTED);
        g.fill(x + w / 2 - 17, y + 17, x + w / 2 + 17, y + 18, 0x997C8292);
        g.fill(x + w / 2 - 1, y + 15, x + w / 2 + 1, y + 19, accent);
    }

    private void drawModuleList(GuiGraphics g, Style style, int accent, int sw) {
        List<Module> active = new ArrayList<>();
        for (Module module : ModuleManager.all()) {
            if (module != this && module.isEnabled() && module.isImplemented()) active.add(module);
        }
        active.sort(Comparator.comparing(Module::getName, String.CASE_INSENSITIVE_ORDER));
        int visible = Math.min(6, active.size());
        int widest = mc.font.width("Modüller " + active.size()) + 18;
        for (int i = 0; i < visible; i++) widest = Math.max(widest, mc.font.width(active.get(i).getName()) + 22);
        int w = Math.min(sw < 520 ? 122 : 132, Math.max(100, widest + 8));
        int h = 16 + visible * 14 + (active.size() > visible ? 10 : 0);
        int x = sw - w - 7;
        int y = 6;
        panel(g, x, y, w, h, accent);
        String title = "Modüller " + active.size();
        g.drawString(mc.font, styled(title, style), x + 5, y + 3, TEXT, true);
        g.drawString(mc.font, "⌄", x + w - 12, y + 2, accent, true);
        for (int i = 0; i < visible; i++) {
            Module module = active.get(i);
            int rowY = y + 16 + i * 14;
            g.fill(x + 6, rowY + 5, x + 10, rowY + 9, 0xFF42E46F);
            String name = trim(module.getName(), w - 24);
            g.drawString(mc.font, styled(name, style), x + 15, rowY + 2, TEXT, false);
        }
        if (active.size() > visible) {
            String more = "+" + (active.size() - visible) + " daha";
            g.drawString(mc.font, styled(more, style), x + 15, y + h - 9, MUTED, false);
        }
    }

        private void drawScoreboard(GuiGraphics g, Style style, int accent, int sw, int sh) {
        try {
            var scoreboardData = mc.level.getScoreboard();
            Objective objective = scoreboardData.getDisplayObjective(DisplaySlot.SIDEBAR);
            if (objective == null) return;
            List<PlayerScoreEntry> rows = scoreboardData.listPlayerScores(objective).stream()
                    .filter(entry -> !entry.isHidden())
                    .sorted(Comparator.comparingInt(PlayerScoreEntry::value).reversed())
                    .limit(7).toList();
            int w = 138;
            int rowLimit = Math.max(0, Math.min(7, (sh - 154) / 12));
            if (rowLimit == 0) return;
            List<PlayerScoreEntry> visibleRows = rows.stream().limit(rowLimit).toList();
            int h = 19 + visibleRows.size() * 12;
            int x = sw - w - 7;
            int y = Math.max(42, sh - 91 - h - 7);
            panel(g, x, y, w, h, accent);
            String title = trim(objective.getDisplayName().getString(), w - 12);
            g.drawString(mc.font, styled(title, style), x + 6, y + 4, accent, false);
            for (int i = 0; i < visibleRows.size(); i++) {
                PlayerScoreEntry entry = visibleRows.get(i);
                int rowY = y + 17 + i * 12;
                String name = trim(entry.owner(), w - 42);
                String score = Integer.toString(entry.value());
                g.drawString(mc.font, styled(name, style), x + 6, rowY, TEXT, false);
                g.drawString(mc.font, score, x + w - mc.font.width(score) - 6, rowY, MUTED, false);
            }
        } catch (RuntimeException ignored) {
            // Some servers send incomplete scoreboard entries while updating; skip one frame.
        }
    }

    private void drawEffects(GuiGraphics g, Style style, int accent, LocalPlayer p, int sh) {
        var effects = p.getActiveEffects();
        if (effects.isEmpty()) return;
        int rows = Math.min(4, effects.size());
        int w = 120;
        int h = 16 + rows * 14;
        int x = 7;
        int y = radar.get() ? 49 + radarSize.getInt() + 8 : 49;
        if (y + h > sh - 38) y = Math.max(66, sh - h - 40);
        panel(g, x, y, w, h, accent);
        g.drawString(mc.font, styled("İksirler " + effects.size(), style), x + 5, y + 3, accent, true);
        int index = 0;
        for (var effect : effects) {
            if (index++ >= rows) break;
            int rowY = y + 16 + (index - 1) * 14;
            String name = trim(effect.getEffect().value().getDisplayName().getString(), 92);
            int ticks = effect.getDuration();
            String time = ticks < 0 ? "∞" : String.format(Locale.ROOT, "%d:%02d", (ticks / 20) / 60, (ticks / 20) % 60);
            g.drawString(mc.font, styled(name, style), x + 5, rowY + 2, TEXT, false);
            g.drawString(mc.font, time, x + w - mc.font.width(time) - 5, rowY + 2, MUTED, false);
        }
    }

        /** Draws a true circular radar using clipped scanlines, so it stays round on every GUI scale. */
    private void drawCircularRadar(GuiGraphics g, LocalPlayer player, int accent, int sh) {
        int diameter = radarSize.getInt();
        int radius = diameter / 2 - 2;
        int x = 14;
        int y = 49;
        int cx = x + diameter / 2;
        int cy = y + diameter / 2;

        for (int dy = -radius; dy <= radius; dy++) {
            int half = (int) Math.floor(Math.sqrt(radius * radius - dy * dy));
            g.fill(cx - half, cy + dy, cx + half + 1, cy + dy + 1, PANEL_SOFT);
            int innerRadius = radius - 1;
            if (Math.abs(dy) <= innerRadius) {
                int inner = (int) Math.floor(Math.sqrt(innerRadius * innerRadius - dy * dy));
                g.fill(cx - half, cy + dy, cx - inner, cy + dy + 1, accent);
                g.fill(cx + inner + 1, cy + dy, cx + half + 1, cy + dy + 1, accent);
            }
        }

        g.fill(cx - 1, cy - radius + 3, cx + 1, cy + radius - 2, 0x557F8798);
        g.fill(cx - radius + 3, cy - 1, cx + radius - 2, cy + 1, 0x557F8798);
        drawRadarRing(g, cx, cy, radius * 2 / 3, 0x557F8798);
        drawRadarRing(g, cx, cy, radius / 3, 0x557F8798);

        // Heading-up display: nearby visible entities rotate around the fixed player arrow.
        double yaw = Math.toRadians(player.getYRot());
        double sin = Math.sin(yaw);
        double cos = Math.cos(yaw);
        double maxRadius = radius - 7;
        double scale = maxRadius / radarRange.getD();
        for (Entity entity : mc.level.entitiesForRendering()) {
            if (entity == player) continue;
            int dot;
            if (entity instanceof Player) dot = 0xFF47E46D;
            else if (radarMobs.get() && entity instanceof Mob) dot = entity instanceof Enemy ? 0xFFFFB45E : 0xFF67D89A;
            else continue;
            double dx = entity.getX() - player.getX();
            double dz = entity.getZ() - player.getZ();
            double forward = dx * -sin + dz * cos;
            double right = dx * -cos + dz * -sin;
            double pxOffset = right * scale;
            double pyOffset = -forward * scale;
            if (pxOffset * pxOffset + pyOffset * pyOffset > maxRadius * maxRadius) continue;
            int px = (int) Math.round(cx + pxOffset);
            int py = (int) Math.round(cy + pyOffset);
            g.fill(px - 2, py - 2, px + 3, py + 3, dot);
            g.fill(px - 1, py - 1, px + 2, py + 2, 0xDDFFFFFF);
        }

        // The cardinal letters travel around the rim as the player rotates.
        if (compass.get()) {
            String[] labels = {"N", "E", "S", "W"};
            for (int i = 0; i < 4; i++) {
                double angle = Math.toRadians(90 - player.getYRot() - i * 90.0);
                int lx = cx + (int) Math.round(Math.cos(angle) * (radius + 8));
                int ly = cy + (int) Math.round(Math.sin(angle) * (radius + 8));
                g.drawCenteredString(mc.font, labels[i], lx, ly - 4, i == 0 ? accent : TEXT);
            }
        }
        // Small directional pointer in the centre.
        g.fill(cx - 2, cy - 4, cx + 3, cy + 2, 0xFFF5F1FF);
        g.fill(cx - 1, cy + 1, cx + 2, cy + 6, 0xFFF5F1FF);
    }

        private void drawRadarRing(GuiGraphics g, int cx, int cy, int radius, int color) {
        if (radius < 2) return;
        for (int dy = -radius; dy <= radius; dy++) {
            int half = (int) Math.round(Math.sqrt(Math.max(0, radius * radius - dy * dy)));
            g.fill(cx - half, cy + dy, cx - half + 1, cy + dy + 1, color);
            g.fill(cx + half, cy + dy, cx + half + 1, cy + dy + 1, color);
        }
    }

    private void updateClicks() {
        long now = System.currentTimeMillis();
        boolean left = false;
        boolean right = false;
        try {
            long window = mc.getWindow().handle();
            left = GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_1) == GLFW.GLFW_PRESS;
            right = GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_2) == GLFW.GLFW_PRESS;
        } catch (Throwable ignored) {
            // Touch-only launchers may not expose GLFW mouse-button state. WASD remains usable.
        }
        if (left && !wasLeft) leftClicks.addLast(now);
        if (right && !wasRight) rightClicks.addLast(now);
        wasLeft = left;
        wasRight = right;
        while (!leftClicks.isEmpty() && now - leftClicks.peekFirst() > 1000L) leftClicks.removeFirst();
        while (!rightClicks.isEmpty() && now - rightClicks.peekFirst() > 1000L) rightClicks.removeFirst();
    }

    private void drawInputPanel(GuiGraphics g, int accent, int sw, int sh) {
        updateClicks();
        int x = sw - 91;
        int y = sh - 91;
        if (keystrokes.get()) {
            panel(g, x - 4, y - 4, 78, 68, accent);
            drawKey(g, x + 24, y, 20, 17, "W", mc.options.keyUp.isDown(), accent);
            drawKey(g, x, y + 19, 20, 17, "A", mc.options.keyLeft.isDown(), accent);
            drawKey(g, x + 24, y + 19, 20, 17, "S", mc.options.keyDown.isDown(), accent);
            drawKey(g, x + 48, y + 19, 20, 17, "D", mc.options.keyRight.isDown(), accent);
            drawKey(g, x, y + 38, 68, 14, "SPACE", mc.options.keyJump.isDown(), accent);
        }
        if (cps.get()) {
            int base = keystrokes.get() ? y + 68 : y;
            panel(g, x - 4, base, 78, 23, accent);
            drawKey(g, x, base + 3, 32, 17, "L " + leftClicks.size(), wasLeft, accent);
            drawKey(g, x + 36, base + 3, 32, 17, "R " + rightClicks.size(), wasRight, accent);
        }
    }

    private void drawKey(GuiGraphics g, int x, int y, int w, int h, String label, boolean pressed, int accent) {
        g.fill(x, y, x + w, y + h, pressed ? 0xEE39265A : 0xCC111521);
        g.fill(x, y, x + w, y + 1, pressed ? accent : FAINT);
        g.drawCenteredString(mc.font, label, x + w / 2, y + (h - mc.font.lineHeight) / 2, pressed ? 0xFFFFFFFF : MUTED);
    }

    private void drawClock(GuiGraphics g, int accent, int sw, int sh) {
        String time = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"));
        String date = java.time.LocalDate.now().format(DateTimeFormatter.ofPattern("d MMMM yyyy", Locale.forLanguageTag("tr-TR")));
        int centre = sw / 2;
        if (sw < 520) {
            int emblemX = centre - 66;
            int emblemY = 6;
            drawSmallSultanEmblem(g, emblemX, emblemY, accent);
            int timeX = centre - 26;
            g.drawString(mc.font, time, timeX, 6, TEXT, true);
            g.drawString(mc.font, date, timeX, 27, MUTED, false);
            return;
        }
        int emblemX = centre - 105;
        int emblemY = 4;
        drawSultanEmblem(g, emblemX, emblemY, accent);
        int timeX = centre - 35;
        g.fill(centre - 43, 5, centre - 42, 40, 0xAA9A63C4);
        g.drawString(mc.font, time, timeX, 6, TEXT, true);
        g.drawString(mc.font, date, timeX + 1, 27, MUTED, false);
        g.fill(centre + 72, 20, centre + 111, 22, accent);
        g.fill(centre + 90, 15, centre + 94, 27, accent);
    }

    private void drawSmallSultanEmblem(GuiGraphics g, int x, int y, int accent) {
        g.fill(x + 5, y + 1, x + 18, y + 5, 0xFFD7D2E1);
        g.fill(x + 2, y + 5, x + 20, y + 9, 0xFFD7D2E1);
        g.fill(x + 8, y + 9, x + 17, y + 17, 0xFF484052);
        g.fill(x + 5, y + 15, x + 18, y + 21, 0xFF292331);
        g.fill(x + 1, y + 22, x + 22, y + 30, 0xFF484052);
        g.fill(x + 9, y + 21, x + 13, y + 30, accent);
    }

    /** A small original, pixel-drawn Ottoman bust mark; no third-party art is bundled. */
    private void drawSultanEmblem(GuiGraphics g, int x, int y, int accent) {
        int cloth = 0xFFD7D2E1;
        int shadow = 0xFF484052;
        // Turban and head silhouette.
        g.fill(x + 12, y + 1, x + 29, y + 6, cloth);
        g.fill(x + 7, y + 5, x + 31, y + 10, cloth);
        g.fill(x + 9, y + 9, x + 29, y + 13, 0xFFB7B0C5);
        g.fill(x + 14, y + 12, x + 27, y + 24, shadow);
        g.fill(x + 10, y + 19, x + 25, y + 25, 0xFF292331);
        // Nose / beard profile details.
        g.fill(x + 23, y + 15, x + 31, y + 18, cloth);
        g.fill(x + 19, y + 21, x + 28, y + 29, 0xFF201B29);
        // Robe and collar.
        g.fill(x + 3, y + 30, x + 36, y + 44, shadow);
        g.fill(x + 9, y + 27, x + 30, y + 33, cloth);
        g.fill(x + 17, y + 30, x + 22, y + 44, accent);
        g.fill(x + 2, y + 42, x + 37, y + 45, 0xFF17131E);
    }

        private void drawCrosshair(GuiGraphics g, int sw, int sh, int accent) {
        int cx = sw / 2;
        int cy = sh / 2;
        // Small four-piece reticle; the center is left open to keep targets visible.
        g.fill(cx - 7, cy, cx - 3, cy + 1, 0xCCFFFFFF);
        g.fill(cx + 4, cy, cx + 8, cy + 1, 0xCCFFFFFF);
        g.fill(cx, cy - 7, cx + 1, cy - 3, 0xCCFFFFFF);
        g.fill(cx, cy + 4, cx + 1, cy + 8, 0xCCFFFFFF);
        g.fill(cx - 1, cy - 1, cx + 2, cy + 2, accent);
    }

    private String trim(String text, int maxWidth) {
        if (mc.font.width(text) <= maxWidth) return text;
        String shortened = text;
        while (!shortened.isEmpty() && mc.font.width(shortened + "…") > maxWidth) {
            shortened = shortened.substring(0, shortened.length() - 1);
        }
        return shortened + "…";
    }
}
